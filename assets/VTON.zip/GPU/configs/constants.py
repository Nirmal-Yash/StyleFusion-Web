"""
Constants for Virtual Try-On System v7.1 FINAL
Contains UNIFIED-25 label space, LIP-20 mapping, and OpenPose flip pairs.
"""

# ═══════════════════════════════════════════════════════════════════════════════════
# UNIFIED-25 LABEL SPACE (MANDATORY — NEVER SIMPLIFY)
# ═══════════════════════════════════════════════════════════════════════════════════

UNIFIED25_CLASSES = {
    0:  "Background",
    1:  "Hat",
    2:  "Hair",
    3:  "Face",
    4:  "Neck-Scarf",
    5:  "Upper-Cloth",         # ← Phase 1 PRIMARY ACTIVE CLASS
    6:  "Kurta",               # Reserved (future Indian textiles)
    7:  "Dress",               # Reserved (future womenswear)
    8:  "Dupatta",             # Reserved (future Indian textiles)
    9:  "Pants-Salwar",        # Reserved (future lower-body)
    10: "Torso-Skin",
    11: "Coat",
    12: "Left-Arm",
    13: "Right-Arm",
    14: "Left-Leg",
    15: "Right-Leg",
    16: "Left-Shoe",
    17: "Right-Shoe",
    18: "Socks",
    19: "Skirt",               # Reserved
    20: "Sunglasses",
    21: "Gloves",
    22: "Left-Bag",
    23: "Right-Bag",
    24: "Belt",
}

GARMENT_CLASSES_UPPER = [5]    # Extend by config, never by code change

# ═══════════════════════════════════════════════════════════════════════════════════
# LIP-20 → UNIFIED-25 MAPPING (EXACT — Applied to MOD-2 Only)
# ═══════════════════════════════════════════════════════════════════════════════════

LIP20_TO_UNIFIED25 = {
    0:  0,   # Background  → Background
    1:  1,   # Hat         → Hat
    2:  2,   # Hair        → Hair
    3:  21,  # Glove       → Gloves
    4:  20,  # Sunglasses  → Sunglasses
    5:  5,   # Upper-cloth → Upper-Cloth  ← CRITICAL: pixel count MUST be preserved
    6:  7,   # Dress       → Dress
    7:  11,  # Coat        → Coat
    8:  18,  # Socks       → Socks
    9:  9,   # Pants       → Pants-Salwar
    10: 10,  # Torso-skin  → Torso-Skin
    11: 4,   # Scarf       → Neck-Scarf
    12: 19,  # Skirt       → Skirt
    13: 3,   # Face        → Face
    14: 12,  # Left-arm    → Left-Arm
    15: 13,  # Right-arm   → Right-Arm
    16: 14,  # Left-leg    → Left-Leg
    17: 15,  # Right-leg   → Right-Leg
    18: 16,  # Left-shoe   → Left-Shoe
    19: 17,  # Right-shoe  → Right-Shoe
}
# Classes 6, 8, 22, 23, 24 in UNIFIED-25 are unused in Phase 1.
# They receive zero gradient — zero cost.

# ═══════════════════════════════════════════════════════════════════════════════════
# OPENPOSE FLIP PAIRS (18-joint model, left↔right symmetric pairs)
# ═══════════════════════════════════════════════════════════════════════════════════

OPENPOSE_FLIP_PAIRS = [
    (1, 2),   # left_eye ↔ right_eye
    (3, 4),   # left_ear ↔ right_ear
    (5, 6),   # left_shoulder ↔ right_shoulder
    (7, 8),   # left_elbow ↔ right_elbow
    (9, 10),  # left_wrist ↔ right_wrist
    (11, 12), # left_hip ↔ right_hip
    (13, 14), # left_knee ↔ right_knee
    (15, 16), # left_ankle ↔ right_ankle
]
# Joint 0 = nose (no pair), 17 = neck (no pair)

# ═══════════════════════════════════════════════════════════════════════════════════
# DENSEPOSE CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════════

DENSEPOSE_MIN_COVERAGE = 0.15  # Threshold for full confidence weight

# ═══════════════════════════════════════════════════════════════════════════════════
# IMAGE DIMENSIONS
# ═══════════════════════════════════════════════════════════════════════════════════

IMAGE_HEIGHT = 1024
IMAGE_WIDTH = 768
LATENT_HEIGHT = 128
LATENT_WIDTH = 96

# ═══════════════════════════════════════════════════════════════════════════════════
# PART SEGMENTATION LABELS (5 parts for warping)
# ═══════════════════════════════════════════════════════════════════════════════════

PART_LABELS = {
    0: "Torso-front",
    1: "Left-sleeve",
    2: "Right-sleeve",
    3: "Lower-front",
    4: "Lower-back",
}

NUM_PARTS = 5
