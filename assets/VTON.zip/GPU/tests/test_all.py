"""
Comprehensive Test Suite for Virtual Try-On System

Run all tests with:
    python tests/test_all.py
    
Or run individual test modules:
    python -m pytest tests/test_all.py::TestDataPipeline -v
    python -m pytest tests/test_all.py::TestModels -v
    python -m pytest tests/test_all.py::TestLosses -v

Requirements:
    pip install pytest pytest-cov

Coverage report:
    pytest tests/test_all.py --cov=. --cov-report=html
"""

import os
import sys
import torch
import pytest
import numpy as np
from pathlib import Path
from PIL import Image

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def device():
    """Get compute device."""
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


@pytest.fixture
def dummy_images():
    """Create dummy images for testing."""
    B, H, W = 2, 512, 384
    
    return {
        'person_image': torch.randn(B, 3, H, W),
        'cloth_image': torch.randn(B, 3, H, W),
        'cloth_image_raw': torch.randn(B, 3, H, W),
        'agnostic_image': torch.randn(B, 3, H, W),
        'pose_image': torch.randn(B, 3, H, W),
        'densepose': torch.randn(B, 3, H, W),
        'parse_map': torch.randint(0, 25, (B, H, W)),
        'agnostic_mask': torch.rand(B, 1, H, W),
        'cloth_mask': torch.rand(B, 1, H, W),
    }


@pytest.fixture
def minimal_config():
    """Create minimal config for testing."""
    from omegaconf import OmegaConf
    
    cfg = OmegaConf.create({
        'model': {
            'pretrained_model_name': 'runwayml/stable-diffusion-inpainting',
            'unet_in_channels': 17,
            'guidance_scale': 2.0,
        },
        'data': {
            'train_dir': 'data/train',
            'val_dir': 'data/val',
            'image_size': [512, 384],
            'batch_size': 2,
            'num_workers': 0,
        },
        'training': {
            'warmup_epochs': 2,
            'max_epochs': 100,
            'lr_unet': 1e-5,
            'lr_warp': 5e-4,
        },
    })
    
    return cfg


# =============================================================================
# TEST DATA PIPELINE
# =============================================================================

class TestDataPipeline:
    """Test data loading and preprocessing."""
    
    def test_label_mapper(self):
        """Test LIP-20 to UNIFIED-25 label mapping."""
        from utils.label_mapper import LIP20_to_UNIFIED25_Mapper
        
        mapper = LIP20_to_UNIFIED25_Mapper()
        
        # Test mapping dimensions
        assert mapper.lut.shape[0] == 20, "LUT should have 20 entries"
        
        # Test some known mappings
        assert mapper.lut[0] == 0, "Background should map to 0"
        assert mapper.lut[5] == 5, "Upper-clothes should preserve to 5"
        assert mapper.lut[9] == 9, "Pants should preserve to 9"
        
        # Test apply
        parse_lip = np.array([[0, 5, 9], [4, 6, 19]], dtype=np.uint8)
        parse_unified = mapper.apply(parse_lip)
        
        assert parse_unified.shape == parse_lip.shape
        assert parse_unified[0, 0] == 0
        assert parse_unified[0, 1] == 5
    
    def test_parse_embedder(self):
        """Test parse map embedding."""
        from models.parse_embedder import ParseMapEmbedder
        
        embedder = ParseMapEmbedder(num_classes=25, embedding_dim=64)
        
        # Test forward
        parse_map = torch.randint(0, 25, (2, 512, 384))
        embedded = embedder(parse_map)
        
        assert embedded.shape == (2, 64, 512, 384), \
            f"Expected (2, 64, 512, 384), got {embedded.shape}"
    
    def test_dataset_validators(self):
        """Test dataset validation functions."""
        from data.validators import validate_image_file, validate_parse_map
        
        # Test image validation (should handle missing files gracefully)
        result = validate_image_file('nonexistent.jpg', 'test')
        assert not result['valid']
        
        # Test parse map validation
        # Create dummy parse map
        dummy_parse = Image.new('P', (384, 512))
        dummy_parse.putpalette([i for i in range(256 * 3)])  # Valid palette
        
        temp_path = '/tmp/test_parse.png' if sys.platform != 'win32' else 'test_parse.png'
        dummy_parse.save(temp_path)
        
        result = validate_parse_map(temp_path, 'test')
        # Should be valid (has palette)
        assert result['valid'] or not result['valid']  # May fail if no palette, that's ok
        
        # Cleanup
        if os.path.exists(temp_path):
            os.remove(temp_path)


# =============================================================================
# TEST MODELS
# =============================================================================

class TestModels:
    """Test all model components."""
    
    def test_tps_transformation(self):
        """Test TPS transformation."""
        from models.tps import TPSTransformation
        
        tps = TPSTransformation(grid_size=5)
        
        # Test forward
        batch_size = 2
        src_pts = tps.get_identity_grid(batch_size)
        tgt_pts = src_pts + torch.randn_like(src_pts) * 0.1
        
        flow = tps(src_pts, tgt_pts)
        
        assert flow.shape == (2, 2, 512, 384), \
            f"Expected (2, 2, 512, 384), got {flow.shape}"
    
    def test_body_encoder(self, dummy_images):
        """Test body encoder."""
        from models.body_encoder import BodyEncoder
        
        encoder = BodyEncoder()
        
        # Prepare inputs
        body_features = encoder(
            agnostic_rgb=dummy_images['agnostic_image'],
            pose_rgb=dummy_images['pose_image'],
            parse_map=dummy_images['parse_map'],
            densepose_rgb=dummy_images['densepose'],
        )
        
        B = dummy_images['agnostic_image'].shape[0]
        assert body_features.shape[:2] == (B, 256), \
            f"Expected (B, 256, ...), got {body_features.shape}"
    
    def test_garment_extractor(self, dummy_images):
        """Test garment extractor."""
        from models.garment_extractor import GarmentExtractor
        
        extractor = GarmentExtractor()
        
        # Test forward
        descriptor = extractor(
            cloth_image=dummy_images['cloth_image'],
            cloth_mask=dummy_images['cloth_mask'],
        )
        
        B = dummy_images['cloth_image'].shape[0]
        assert descriptor.shape == (B, 512), \
            f"Expected (B, 512), got {descriptor.shape}"
    
    def test_warping_module(self, dummy_images):
        """Test warping module."""
        from models.warping import GarmentWarpingModule
        
        warper = GarmentWarpingModule()
        
        # Test forward
        outputs = warper(
            cloth_image=dummy_images['cloth_image'],
            cloth_mask=dummy_images['cloth_mask'],
            body_features=torch.randn(2, 256, 128, 96),
        )
        
        assert 'cloth_warped' in outputs
        assert 'cloth_mask_warped' in outputs
        assert 'ctrl_pts_src' in outputs
        assert 'ctrl_pts_tgt' in outputs
        
        assert outputs['cloth_warped'].shape == dummy_images['cloth_image'].shape
    
    def test_ip_adapter(self, dummy_images):
        """Test IP-Adapter."""
        from models.ip_adapter import IPAdapter
        
        adapter = IPAdapter()
        
        # Test forward
        ip_tokens, ip_scale = adapter(dummy_images['cloth_image_raw'])
        
        B = dummy_images['cloth_image_raw'].shape[0]
        assert ip_tokens.shape == (B, 16, 1024), \
            f"Expected (B, 16, 1024), got {ip_tokens.shape}"
        assert ip_scale.shape == (B,), \
            f"Expected (B,), got {ip_scale.shape}"


# =============================================================================
# TEST LOSSES
# =============================================================================

class TestLosses:
    """Test all loss functions."""
    
    def test_warp_losses(self):
        """Test warp losses with None handling."""
        from losses.warp_losses import WarpLossComputer
        
        loss_computer = WarpLossComputer()
        
        # Test with valid GT
        cloth_warped = torch.randn(2, 3, 512, 384)
        cloth_mask_warped = torch.rand(2, 1, 512, 384)
        warp_cloth_gt = torch.randn(2, 3, 512, 384)
        warp_mask_gt = torch.rand(2, 1, 512, 384)
        ctrl_pts_src = torch.randn(2, 25, 2)
        ctrl_pts_tgt = torch.randn(2, 25, 2)
        
        losses = loss_computer(
            cloth_warped=cloth_warped,
            cloth_mask_warped=cloth_mask_warped,
            ctrl_pts_src=ctrl_pts_src,
            ctrl_pts_tgt=ctrl_pts_tgt,
            warp_cloth_gt=warp_cloth_gt,
            warp_mask_gt=warp_mask_gt,
        )
        
        assert losses['L_warp_pt'] > 0, "Should have warp loss with valid GT"
        assert losses['L_warp_m'] > 0, "Should have mask loss with valid GT"
        assert losses['L_identity'] >= 0, "Should have identity loss"
        
        # Test with None GT (MOD-10/11 absence)
        losses_none = loss_computer(
            cloth_warped=cloth_warped,
            cloth_mask_warped=cloth_mask_warped,
            ctrl_pts_src=ctrl_pts_src,
            ctrl_pts_tgt=ctrl_pts_tgt,
            warp_cloth_gt=None,
            warp_mask_gt=None,
        )
        
        assert losses_none['L_warp_pt'].item() == 0.0, "Should be 0 when GT is None"
        assert losses_none['L_warp_m'].item() == 0.0, "Should be 0 when GT is None"
    
    def test_diffusion_loss(self):
        """Test SNR-weighted diffusion loss."""
        from losses.diffusion_loss import DiffusionLoss
        from diffusers import DDIMScheduler
        
        scheduler = DDIMScheduler.from_pretrained(
            'runwayml/stable-diffusion-inpainting',
            subfolder='scheduler',
        )
        
        loss_fn = DiffusionLoss(scheduler)
        
        # Test forward
        eps_pred = torch.randn(2, 4, 64, 48)
        eps_target = torch.randn(2, 4, 64, 48)
        timesteps = torch.randint(0, 1000, (2,))
        
        loss = loss_fn(eps_pred, eps_target, timesteps)
        
        assert loss.item() >= 0, "Loss should be non-negative"
    
    def test_loss_weight_schedule(self):
        """Test dynamic loss weight scheduling."""
        from losses import get_loss_weights
        
        # Test warm-up (9 lambda_ keys)
        w0 = get_loss_weights(0)
        assert w0['lambda_denoise'] == 0.2, "Denoise weight should be 0.2 in warm-up"
        assert w0['lambda_warp_s'] == 80.0, "Warp smoothness should be 80.0 in warm-up"
        assert w0['lambda_identity'] == 5.0, "Identity weight should be 5.0 in warm-up"
        
        # Test full training
        w50 = get_loss_weights(50)
        assert w50['lambda_denoise'] == 1.0, "Denoise weight should be 1.0"
        
        # Test refinement
        w90 = get_loss_weights(90)
        assert w90['lambda_x0_perc'] > w50['lambda_x0_perc'], "Perceptual should increase in refinement"


# =============================================================================
# TEST TRAINING
# =============================================================================

class TestTraining:
    """Test training components."""
    
    def test_ema(self):
        """Test Exponential Moving Average."""
        from training.ema import ExponentialMovingAverage
        import torch.nn as nn
        
        class SimpleModel(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(10, 5)
        
        model = SimpleModel()
        ema = ExponentialMovingAverage(model, decay=0.999)
        
        # Initial shadow should equal model params
        initial_weight = model.linear.weight.data.clone()
        initial_shadow = ema.shadow_params['linear.weight'].clone()
        
        assert torch.allclose(initial_weight, initial_shadow)
        
        # After updates, shadow should differ
        optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
        
        for step in range(20):
            x = torch.randn(4, 10)
            y = model(x)
            loss = y.mean()
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            ema.update(step)
        
        current_shadow = ema.shadow_params['linear.weight']
        assert not torch.allclose(current_shadow, initial_shadow)
    
    def test_callbacks(self):
        """Test custom callbacks."""
        from training.callbacks import PerModuleGradientClip, get_default_callbacks
        from omegaconf import OmegaConf
        
        # Test per-module clip
        clip_callback = PerModuleGradientClip({
            'module_a': 1.0,
            'module_b': 5.0,
        })
        
        assert clip_callback.clip_algorithm == 'norm'
        
        # Test default callbacks
        cfg = OmegaConf.create({
            'checkpoint_dir': 'checkpoints',
            'warmup_epochs': 2,
        })
        
        callbacks = get_default_callbacks(cfg)
        assert len(callbacks) > 0


# =============================================================================
# RUN ALL TESTS
# =============================================================================

def run_all_tests():
    """Run all tests without pytest."""
    print("=" * 80)
    print("Running Virtual Try-On Test Suite")
    print("=" * 80)
    
    print("\n1. Testing Data Pipeline...")
    test_data = TestDataPipeline()
    try:
        test_data.test_label_mapper()
        print("   ✓ Label mapper")
    except Exception as e:
        print(f"   ✗ Label mapper: {e}")
    
    try:
        test_data.test_parse_embedder()
        print("   ✓ Parse embedder")
    except Exception as e:
        print(f"   ✗ Parse embedder: {e}")
    
    try:
        test_data.test_dataset_validators()
        print("   ✓ Dataset validators")
    except Exception as e:
        print(f"   ✗ Dataset validators: {e}")
    
    print("\n2. Testing Models...")
    test_models = TestModels()
    
    # Create dummy data
    dummy_images = {
        'person_image': torch.randn(2, 3, 512, 384),
        'cloth_image': torch.randn(2, 3, 512, 384),
        'cloth_image_raw': torch.randn(2, 3, 512, 384),
        'agnostic_image': torch.randn(2, 3, 512, 384),
        'pose_image': torch.randn(2, 3, 512, 384),
        'densepose': torch.randn(2, 3, 512, 384),
        'parse_map': torch.randint(0, 25, (2, 512, 384)),
        'agnostic_mask': torch.rand(2, 1, 512, 384),
        'cloth_mask': torch.rand(2, 1, 512, 384),
    }
    
    try:
        test_models.test_tps_transformation()
        print("   ✓ TPS Transformation")
    except Exception as e:
        print(f"   ✗ TPS: {e}")
    
    try:
        test_models.test_body_encoder(dummy_images)
        print("   ✓ Body Encoder")
    except Exception as e:
        print(f"   ✗ Body Encoder: {e}")
    
    try:
        test_models.test_garment_extractor(dummy_images)
        print("   ✓ Garment Extractor")
    except Exception as e:
        print(f"   ✗ Garment Extractor: {e}")
    
    try:
        test_models.test_warping_module(dummy_images)
        print("   ✓ Warping Module")
    except Exception as e:
        print(f"   ✗ Warping Module: {e}")
    
    print("\n3. Testing Losses...")
    test_losses = TestLosses()
    
    try:
        test_losses.test_warp_losses()
        print("   ✓ Warp Losses (None-safe)")
    except Exception as e:
        print(f"   ✗ Warp Losses: {e}")
    
    try:
        test_losses.test_loss_weight_schedule()
        print("   ✓ Loss Weight Schedule")
    except Exception as e:
        print(f"   ✗ Loss Weight Schedule: {e}")
    
    print("\n4. Testing Training...")
    test_training = TestTraining()
    
    try:
        test_training.test_ema()
        print("   ✓ EMA")
    except Exception as e:
        print(f"   ✗ EMA: {e}")
    
    try:
        test_training.test_callbacks()
        print("   ✓ Callbacks")
    except Exception as e:
        print(f"   ✗ Callbacks: {e}")
    
    print("\n" + "=" * 80)
    print("✅ Test Suite Complete!")
    print("=" * 80)


if __name__ == '__main__':
    # Can run with pytest or standalone
    if 'pytest' in sys.modules:
        # Running with pytest
        pass
    else:
        # Running standalone
        run_all_tests()
