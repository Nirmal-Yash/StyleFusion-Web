"""
PyTorch Lightning DataModule for Virtual Try-On System.
CRITICAL: Includes custom_collate_fn to handle None values (MOD-10/11 absent).
"""

import torch
from torch.utils.data import DataLoader
from pytorch_lightning import LightningDataModule
from typing import Optional, Dict, List, Any
import logging

from .dataset_vitonhd import VITONHDDataset

logger = logging.getLogger(__name__)


def custom_collate_fn(batch: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Custom collate function to handle None values for absent optional modalities (MOD-10, MOD-11).
    
    The default DataLoader collate_fn will CRASH if batch items are None.
    This function safely handles None values by preserving them in the collated batch.
    
    Args:
        batch: List of sample dictionaries from dataset __getitem__
    
    Returns:
        Collated batch dictionary with proper handling of None values
    
    Behavior:
        - If all samples have None for a key → output[key] = None
        - If some samples have None → output[key] = None (partial optional modality)
        - If all samples have tensors → stack normally
        - String values (person_id, cloth_id) → keep as list
    """
    out = {}
    
    for key in batch[0].keys():
        vals = [b[key] for b in batch]
        
        if all(v is None for v in vals):
            # All None → keep None
            out[key] = None
        elif any(v is None for v in vals):
            # Partial None — treat all as None (optional modality partially missing)
            logger.warning(
                f"Key '{key}' has partial None values in batch. "
                f"Treating all as None to maintain consistency."
            )
            out[key] = None
        elif isinstance(vals[0], torch.Tensor):
            # Normal stack
            out[key] = torch.stack(vals, dim=0)
        elif isinstance(vals[0], str):
            # Keep as list of strings
            out[key] = vals
        elif isinstance(vals[0], (int, float)):
            # Convert to tensor
            out[key] = torch.tensor(vals)
        else:
            # Fallback: keep as list
            out[key] = vals
    
    return out


class VITONDataModule(LightningDataModule):
    """
    PyTorch Lightning DataModule for VITON-HD dataset.
    
    Features:
    - Automatic train/val split
    - Custom collate function for None handling
    - Configurable number of workers and batch size
    - Pin memory for faster GPU transfer
    """
    
    def __init__(self, cfg):
        """
        Args:
            cfg: OmegaConf configuration object
        """
        super().__init__()
        self.cfg = cfg
        self.batch_size = cfg.data.batch_size
        self.num_workers = cfg.data.num_workers
        self.pin_memory = cfg.data.get('pin_memory', True)
        
        self.train_dataset = None
        self.val_dataset = None
    
    def setup(self, stage: Optional[str] = None):
        """
        Setup datasets for training and validation.
        
        Args:
            stage: 'fit', 'validate', 'test', or 'predict'
        """
        if stage == 'fit' or stage is None:
            # Training dataset
            self.train_dataset = VITONHDDataset(self.cfg, split='train')
            logger.info(f"Training dataset: {len(self.train_dataset)} samples")
            
            # Validation dataset (use test split)
            self.val_dataset = VITONHDDataset(self.cfg, split='test')
            logger.info(f"Validation dataset: {len(self.val_dataset)} samples")
        
        if stage == 'test':
            self.val_dataset = VITONHDDataset(self.cfg, split='test')
            logger.info(f"Test dataset: {len(self.val_dataset)} samples")
    
    def train_dataloader(self) -> DataLoader:
        """
        Create training DataLoader.
        
        CRITICAL: Uses custom_collate_fn to handle None values.
        """
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=custom_collate_fn,  # ← CRITICAL: prevents crash on None
            drop_last=True,  # Drop incomplete batches for stable training
            persistent_workers=True if self.num_workers > 0 else False,
        )
    
    def val_dataloader(self) -> DataLoader:
        """
        Create validation DataLoader.
        
        CRITICAL: Uses custom_collate_fn to handle None values.
        """
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=custom_collate_fn,  # ← CRITICAL: prevents crash on None
            drop_last=False,
        )
    
    def test_dataloader(self) -> DataLoader:
        """
        Create test DataLoader.
        
        CRITICAL: Uses custom_collate_fn to handle None values.
        """
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=custom_collate_fn,  # ← CRITICAL: prevents crash on None
            drop_last=False,
        )
