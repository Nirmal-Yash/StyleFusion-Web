"""
VITON-HD Dataset loader with all 11 modalities.
Critical: Uses cfg.data.paths for all folder names (no hardcoded paths).
Handles MOD-10/11 absence gracefully (returns None).
MOD-8 is binarized from palette PNG (not direct binary mask).
"""

import json
import torch
import numpy as np
from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
from typing import Dict, Optional
import torchvision.transforms as T
import torchvision.transforms.functional as TF
import logging

from configs.constants import LIP20_TO_UNIFIED25, OPENPOSE_FLIP_PAIRS
from utils.label_mapper import remap_labels, binarize_agnostic_parse

logger = logging.getLogger(__name__)


class VITONHDDataset(Dataset):
    """
    VITON-HD dataset loader for virtual try-on.
    
    Loads 9 active modalities from disk (MOD-1 through MOD-9)
    MOD-10 and MOD-11 are absent and return None.
    
    Critical implementation details:
    - All paths sourced from cfg.data.paths — NEVER hardcoded
    - MOD-2: LIP-20 palette PNG → remap to UNIFIED-25
    - MOD-8: image-parse-agnostic-v3.2 palette PNG → binarize to {0.0, 1.0}
    - MOD-3/MOD-4: openpose_img and openpose_json (underscore folder names)
    - cloth_image_raw stored separately (unaugmented for CLIP)
    - cloth_image is augmented version
    - Joint horizontal flip with proper keypoint swapping
    - Menswear filtering based on parse class distribution
    """
    
    def __init__(self, cfg, split='train'):
        """
        Args:
            cfg: OmegaConf configuration object
            split: 'train' or 'test'
        """
        self.root = Path(cfg.data.data_root) / split
        self.split = split
        self.cfg = cfg
        
        # Path map sourced entirely from cfg — NO hardcoded strings
        paths = cfg.data.paths  # OmegaConf DictConfig
        self.dir_person = self.root / paths.image
        self.dir_parse = self.root / paths.parse
        self.dir_openpose_img = self.root / paths.openpose_img    # underscore folder
        self.dir_openpose_json = self.root / paths.openpose_json  # underscore folder
        self.dir_cloth = self.root / paths.cloth
        self.dir_cloth_mask = self.root / paths.cloth_mask
        self.dir_agnostic = self.root / paths.agnostic
        self.dir_agn_parse = self.root / paths.agnostic_mask  # palette parse file
        self.dir_densepose = self.root / paths.densepose
        
        # Optional paths — may be None in config (MOD-10/11 absent)
        wc = getattr(paths, 'warp_cloth', None)
        wcm = getattr(paths, 'warp_cloth_mask', None)
        self.dir_warp_cloth = (self.root / wc) if wc else None  # → None
        self.dir_warp_cloth_mask = (self.root / wcm) if wcm else None  # → None
        
        # Load pair list
        pair_file = Path(cfg.data.data_root) / f"{split}_pairs.txt"
        self.samples = []
        
        if not pair_file.exists():
            raise FileNotFoundError(
                f"Pair list not found: {pair_file}\n"
                f"Expected format: person_id cloth_id (one pair per line)"
            )
        
        with open(pair_file) as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) == 2:
                    self.samples.append({'person_id': parts[0], 'cloth_id': parts[1]})
        
        logger.info(f"Loaded {len(self.samples)} pairs from {pair_file}")
        
        # Menswear filter
        if cfg.data.get('apply_menswear_filter', True) and split == 'train':
            self.samples = self._apply_menswear_filter(self.samples)
        
        # Define transforms
        self._setup_transforms()
    
    def _setup_transforms(self):
        """Setup image transforms for training and validation."""
        # Normalization for RGB images (person, cloth, agnostic, openpose)
        self.normalize = T.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        
        # Cloth augmentations (training only)
        self.cloth_affine_prob = 0.5 if self.split == 'train' else 0.0
        self.cloth_color_jitter = T.ColorJitter(
            brightness=0.15, contrast=0.15, saturation=0.10, hue=0.05
        ) if self.split == 'train' else None
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx) -> Dict[str, torch.Tensor]:
        s = self.samples[idx]
        pid, cid = s['person_id'], s['cloth_id']
        
        # ══════════════════════════════════════════════════════════════
        # Load all modalities
        # ══════════════════════════════════════════════════════════════
        
        # MOD-1: Person image
        person_img = self._load_rgb(self.dir_person / f"{pid}.jpg")
        
        # MOD-2: LIP-20 parse → remap to UNIFIED-25
        parse_lip20 = self._load_palette_png(self.dir_parse / f"{pid}.png")  # [H,W] int
        parse_lip20_t = torch.from_numpy(parse_lip20).long()  # [H,W] tensor
        parse_u25 = remap_labels(
            parse_lip20_t,
            LIP20_TO_UNIFIED25,
            target_vocab_size=25
        )  # [H,W] int64
        
        # MOD-3: OpenPose skeleton heatmap (from openpose_img/ — underscore)
        # Note: filename pattern may vary — try common patterns
        openpose_path = self._find_openpose_image(pid)
        openpose_img = self._load_rgb(openpose_path) if openpose_path else torch.zeros(3, 1024, 768)
        
        # MOD-4: OpenPose JSON (from openpose_json/ — underscore)
        kp_coords = self._load_keypoints(self.dir_openpose_json / f"{pid}_keypoints.json")
        
        # MOD-5: Cloth image (augmented version + raw version for CLIP)
        cloth_img_pil = Image.open(self.dir_cloth / f"{cid}.jpg").convert("RGB")
        cloth_img_raw = self._pil_to_tensor_norm(cloth_img_pil)  # unaugmented [3,H,W]
        
        # MOD-6: Cloth mask
        cloth_mask_pil = Image.open(self.dir_cloth_mask / f"{cid}.png").convert("L")
        
        # Apply cloth augmentations (jointly to MOD-5 + MOD-6)
        cloth_img_aug, cloth_mask_aug = self._augment_cloth(cloth_img_pil, cloth_mask_pil)
        
        # MOD-7: Agnostic image
        agnostic_img = self._load_rgb(self.dir_agnostic / f"{pid}.png")
        
        # MOD-8: Agnostic mask — BINARIZE from palette parse file
        agn_parse_array = self._load_palette_png(self.dir_agn_parse / f"{pid}.png")
        agnostic_mask_np = binarize_agnostic_parse(agn_parse_array)  # [H,W] float32
        agnostic_mask = torch.from_numpy(agnostic_mask_np).unsqueeze(0)  # [1,H,W]
        
        # MOD-9: DensePose IUV
        densepose_iuv = self._load_densepose(self.dir_densepose / f"{pid}_iuv.png")
        coverage = self._compute_densepose_coverage(densepose_iuv)
        
        # MOD-10/11: ABSENT — always None
        warp_cloth = None
        warp_cloth_mask = None
        
        # ══════════════════════════════════════════════════════════════
        # Apply joint horizontal flip
        # ══════════════════════════════════════════════════════════════
        if self.split == 'train' and torch.rand(1).item() < 0.5:
            # Flip ALL spatial tensors with same state
            person_img = TF.hflip(person_img)
            parse_u25 = torch.flip(parse_u25, dims=[-1])  # flip W dimension
            parse_lip20_t = torch.flip(parse_lip20_t, dims=[-1])  # keep in sync
            openpose_img = TF.hflip(openpose_img)
            agnostic_img = TF.hflip(agnostic_img)
            agnostic_mask = TF.hflip(agnostic_mask)
            densepose_iuv = TF.hflip(densepose_iuv)
            cloth_img_aug = TF.hflip(cloth_img_aug)
            cloth_mask_aug = TF.hflip(cloth_mask_aug)
            kp_coords = self._flip_keypoints(kp_coords)  # x=1-x, swap L/R pairs
        
        # ══════════════════════════════════════════════════════════════
        # Apply agnostic cutout augmentation
        # ══════════════════════════════════════════════════════════════
        if self.split == 'train':
            cutout_prob = self.cfg.model.body_encoder.get('agnostic_cutout_prob', 0.3)
            num_patches = self.cfg.model.body_encoder.get('agnostic_cutout_num_patches', 2)
            agnostic_img = self._random_cutout(agnostic_img, n_patches=num_patches, p=cutout_prob)
        
        # ══════════════════════════════════════════════════════════════
        # Build output dict
        # ══════════════════════════════════════════════════════════════
        return {
            'person_image': person_img,  # [3,1024,768] f32 [-1,1]
            'parse_lip20': parse_lip20_t.unsqueeze(0),
            'parse_unified25': parse_u25.unsqueeze(0),  # [1,1024,768] i64 [0,24]
            'openpose_img': openpose_img,  # [3,1024,768] f32 [-1,1]
            'keypoint_coords': kp_coords,  # [36] f32 [0,1]
            'cloth_image': cloth_img_aug,  # [3,1024,768] f32 [-1,1]
            'cloth_image_raw': cloth_img_raw,  # [3,1024,768] f32 [-1,1]
            'cloth_mask': cloth_mask_aug,  # [1,1024,768] f32 [0,1]
            'agnostic_image': agnostic_img,  # [3,1024,768] f32 [-1,1]
            'agnostic_mask': agnostic_mask,  # [1,1024,768] f32 {0,1}
            'densepose_iuv': densepose_iuv,  # [3,1024,768] f32 [0,1]
            'densepose_coverage': torch.tensor(coverage, dtype=torch.float32),  # scalar
            'warp_cloth': warp_cloth,  # None (MOD-10 absent)
            'warp_cloth_mask': warp_cloth_mask,  # None (MOD-11 absent)
            'person_id': pid,
            'cloth_id': cid,
        }
    
    def _find_openpose_image(self, person_id: str) -> Optional[Path]:
        """Find openpose image with common filename patterns."""
        patterns = [
            f"{person_id}_rendered.png",
            f"{person_id}_keypoints.png",
            f"{person_id}.png",
        ]
        for pattern in patterns:
            path = self.dir_openpose_img / pattern
            if path.exists():
                return path
        logger.warning(f"OpenPose image not found for {person_id}, using zeros")
        return None
    
    def _load_rgb(self, path: Path) -> torch.Tensor:
        """Load RGB image and convert to normalized tensor [-1, 1]."""
        img = Image.open(path).convert("RGB")
        return self._pil_to_tensor_norm(img)
    
    def _pil_to_tensor_norm(self, img: Image.Image) -> torch.Tensor:
        """Convert PIL image to normalized tensor [-1, 1]."""
        tensor = TF.to_tensor(img)  # [0, 1]
        tensor = self.normalize(tensor)  # [-1, 1]
        return tensor
    
    def _load_palette_png(self, path: Path) -> np.ndarray:
        """Load palette PNG as integer array. Returns [H,W] int values."""
        img = Image.open(path)
        if img.mode != "P":
            img = img.convert("P")
        return np.array(img, dtype=np.int64)
    
    def _load_keypoints(self, path: Path) -> torch.Tensor:
        """
        Load OpenPose JSON, extract 18-joint normalized coordinates.
        Returns [36] float32 tensor. Returns zeros if no person detected.
        """
        if not path.exists():
            return torch.zeros(36, dtype=torch.float32)
        
        with open(path) as f:
            data = json.load(f)
        
        if not data.get('people'):
            return torch.zeros(36, dtype=torch.float32)
        
        raw = data['people'][0]['pose_keypoints_2d']  # length 54: x,y,c per joint
        W, H = 768, 1024
        coords = []
        
        for i in range(18):
            x_norm = float(raw[i * 3 + 0]) / W
            y_norm = float(raw[i * 3 + 1]) / H
            coords.extend([x_norm, y_norm])
        
        return torch.tensor(coords, dtype=torch.float32).clamp(0.0, 1.0)
    
    def _load_densepose(self, path: Path) -> torch.Tensor:
        """
        Load DensePose IUV PNG.
        Returns [3,H,W] float32 tensor [0,1].
        R=part_id, G=U_coord, B=V_coord (all normalized to [0,1])
        """
        if not path.exists():
            logger.warning(f"DensePose not found: {path}, using zeros")
            return torch.zeros(3, 1024, 768, dtype=torch.float32)
        
        img = Image.open(path).convert("RGB")
        tensor = TF.to_tensor(img)  # [3,H,W] in [0,1]
        return tensor
    
    def _augment_cloth(self, cloth_img: Image.Image, cloth_mask: Image.Image):
        """
        Apply joint augmentations to cloth image and mask.
        
        Augmentations (training only):
        1. Random affine (rotation, scale, shear)
        2. Color jitter on cloth_image ONLY (not mask, not cloth_image_raw)
        
        Args:
            cloth_img: PIL Image RGB
            cloth_mask: PIL Image grayscale
        
        Returns:
            cloth_tensor: [3,H,W] float32 [-1,1]
            mask_tensor: [1,H,W] float32 [0,1]
        """
        if self.split == 'train' and torch.rand(1).item() < self.cloth_affine_prob:
            # Random affine parameters
            angle = torch.FloatTensor(1).uniform_(-5, 5).item()
            scale = torch.FloatTensor(1).uniform_(0.95, 1.05).item()
            shear_x = torch.FloatTensor(1).uniform_(-3, 3).item()
            shear_y = torch.FloatTensor(1).uniform_(-3, 3).item()
            
            # Apply same affine to both
            cloth_img = TF.affine(cloth_img, angle=angle, translate=[0, 0],
                                 scale=scale, shear=[shear_x, shear_y],
                                 interpolation=T.InterpolationMode.BILINEAR)
            cloth_mask = TF.affine(cloth_mask, angle=angle, translate=[0, 0],
                                  scale=scale, shear=[shear_x, shear_y],
                                  interpolation=T.InterpolationMode.NEAREST)
        
        # Color jitter on cloth_image ONLY (not applied to cloth_image_raw)
        if self.cloth_color_jitter and self.split == 'train':
            cloth_img = self.cloth_color_jitter(cloth_img)
        
        # Convert to tensors
        cloth_tensor = self._pil_to_tensor_norm(cloth_img)  # [3,H,W] [-1,1]
        mask_tensor = TF.to_tensor(cloth_mask)  # [1,H,W] [0,1]
        
        return cloth_tensor, mask_tensor
    
    def _flip_keypoints(self, kp: torch.Tensor) -> torch.Tensor:
        """Flip keypoint x-coordinates and swap L/R symmetric joint pairs."""
        kp = kp.clone()
        # Flip x: x_new = 1 - x_old (y unchanged)
        kp[0::2] = 1.0 - kp[0::2]
        
        # Swap L/R pairs
        for l, r in OPENPOSE_FLIP_PAIRS:
            kp[[l * 2, l * 2 + 1]], kp[[r * 2, r * 2 + 1]] = \
                kp[[r * 2, r * 2 + 1]].clone(), kp[[l * 2, l * 2 + 1]].clone()
        
        return kp
    
    def _compute_densepose_coverage(self, densepose_iuv: torch.Tensor) -> float:
        """
        Compute fraction of pixels with a detected DensePose body part.
        DensePose PNG stores part_id in R channel, normalized to [0,1].
        Part ID 0 = background. Raw ID > 0 = body surface.
        """
        raw_part = (densepose_iuv[0] * 255.0).round().long()  # R channel → [0,24]
        return (raw_part > 0).float().mean().item()
    
    def _random_cutout(self, img: torch.Tensor, n_patches: int, p: float) -> torch.Tensor:
        """
        Apply random cutout augmentation (zero out rectangular patches).
        
        Args:
            img: Image tensor [C,H,W]
            n_patches: Number of patches to cut out
            p: Probability of applying cutout
        
        Returns:
            Augmented image tensor [C,H,W]
        """
        if torch.rand(1).item() > p:
            return img
        
        img = img.clone()
        C, H, W = img.shape
        
        for _ in range(n_patches):
            # Random patch size (5-15% of image)
            patch_h = int(H * torch.FloatTensor(1).uniform_(0.05, 0.15).item())
            patch_w = int(W * torch.FloatTensor(1).uniform_(0.05, 0.15).item())
            
            # Random position
            y = torch.randint(0, H - patch_h + 1, (1,)).item()
            x = torch.randint(0, W - patch_w + 1, (1,)).item()
            
            # Zero out patch
            img[:, y:y + patch_h, x:x + patch_w] = 0.0
        
        return img
    
    def _is_menswear_candidate(self, parse_lip20: np.ndarray) -> bool:
        """
        Check if a sample is a menswear candidate based on parse distribution.
        Criteria: upper-cloth > 20%, dress < 5%
        """
        upper_freq = (parse_lip20 == 5).mean()
        dress_freq = (parse_lip20 == 6).mean()
        return bool(upper_freq > 0.20 and dress_freq < 0.05)
    
    def _apply_menswear_filter(self, samples: list) -> list:
        """Filter samples to keep only menswear candidates."""
        kept = []
        for s in samples:
            parse_path = self.dir_parse / f"{s['person_id']}.png"
            if parse_path.exists():
                parse_arr = self._load_palette_png(parse_path)
                if self._is_menswear_candidate(parse_arr):
                    kept.append(s)
            else:
                kept.append(s)  # keep if parse missing to avoid data loss
        
        logger.info(
            f"Menswear filter: {len(kept)}/{len(samples)} kept "
            f"({len(kept) / max(1, len(samples)):.1%})"
        )
        return kept
