"""
Dataset validation for VITON-HD before training starts.
Critical: All directory checks use cfg.data.paths (no hardcoded folder names).
"""

import json
import numpy as np
import torch
from pathlib import Path
from PIL import Image
from typing import Dict, List, Optional
from dataclasses import dataclass
import logging

from configs.constants import LIP20_TO_UNIFIED25
from utils.label_mapper import remap_labels, binarize_agnostic_parse, verify_class5_preservation

logger = logging.getLogger(__name__)


@dataclass
class CheckResult:
    """Result of a single validation check."""
    status: str  # 'PASS', 'FAIL', 'WARN', 'INFO'
    message: str
    details: Optional[Dict] = None


class VITONHDValidator:
    """
    Validates the actual VITON-HD dataset structure before training.
    Uses cfg.data.paths for all directory names — no hardcoded strings.
    
    Performs 10 comprehensive checks:
    1. Directory structure (all required folders exist)
    2. Pair lists (properly formatted, files referenced exist)
    3. Image dimensions (1024×768 for all images)
    4. Parse class distribution (valid LIP-20 classes)
    5. Label mapping correctness (LIP-20→UNIFIED-25 + MOD-8 binarization)
    6. DensePose coverage statistics
    7. OpenPose quality (keypoint detection rate)
    8. Agnostic mask coverage
    9. Warp-cloth availability (documents MOD-10/11 absence)
    10. Cloth mask quality
    """
    
    def __init__(self):
        self.failures = []
        self.warnings = []
        self.info = []
    
    def validate(self, cfg, split='train') -> Dict:
        """
        Run all validation checks.
        
        Args:
            cfg: OmegaConf configuration object
            split: 'train' or 'test'
        
        Returns:
            Validation report dictionary with all check results
        """
        self.cfg = cfg
        self.root = Path(cfg.data.data_root) / split
        self.paths = cfg.data.paths
        self.split = split
        
        logger.info(f"Validating VITON-HD dataset at: {self.root}")
        
        checks = []
        checks.append(('Directory Structure', self._check_directory_structure()))
        checks.append(('Pair Lists', self._check_pair_lists()))
        checks.append(('Image Dimensions', self._check_image_dimensions()))
        checks.append(('Parse Class Distribution', self._check_parse_class_distribution()))
        checks.append(('Label Mapping Correctness', self._check_label_mapping_correctness()))
        checks.append(('DensePose Coverage', self._check_densepose_coverage()))
        checks.append(('OpenPose Quality', self._check_openpose_quality()))
        checks.append(('Agnostic Mask Coverage', self._check_agnostic_mask_coverage()))
        checks.append(('Warp Cloth Availability', self._check_warp_cloth_availability()))
        checks.append(('Cloth Mask Quality', self._check_cloth_mask_quality()))
        
        return self._build_report(checks)
    
    def _check_directory_structure(self) -> CheckResult:
        """
        Check #1 [CRITICAL]: All required folders exist under split root.
        Uses cfg.data.paths — no hardcoded names.
        """
        required = [
            self.paths.image,
            self.paths.parse,
            self.paths.openpose_img,  # "openpose_img" — underscore
            self.paths.openpose_json,  # "openpose_json" — underscore
            self.paths.cloth,
            self.paths.cloth_mask,
            self.paths.agnostic,
            self.paths.agnostic_mask,  # "image-parse-agnostic-v3.2"
            self.paths.densepose,
        ]
        
        optional = []
        # MOD-10/11 paths are None in config — expected absent, do NOT add to required
        wc = getattr(self.paths, 'warp_cloth', None)
        wcm = getattr(self.paths, 'warp_cloth_mask', None)
        if wc:
            optional.append(wc)
        if wcm:
            optional.append(wcm)
        
        missing_required = [d for d in required if not (self.root / d).exists()]
        missing_optional = [d for d in optional if not (self.root / d).exists()]
        
        if missing_optional:
            self.info.append(f"Optional folders absent (OK): {missing_optional}")
        
        if missing_required:
            return CheckResult('FAIL', f"Missing required folders: {missing_required}")
        
        return CheckResult('PASS', f"All {len(required)} required folders present")
    
    def _check_pair_lists(self) -> CheckResult:
        """Check #2: Pair lists exist and are properly formatted."""
        pair_file = Path(self.cfg.data.data_root) / f"{self.split}_pairs.txt"
        
        if not pair_file.exists():
            return CheckResult('FAIL', f"Pair list not found: {pair_file}")
        
        try:
            with open(pair_file) as f:
                lines = f.readlines()
            
            num_pairs = 0
            for line in lines:
                parts = line.strip().split()
                if len(parts) == 2:
                    num_pairs += 1
            
            if num_pairs == 0:
                return CheckResult('FAIL', "Pair list is empty or malformed")
            
            return CheckResult('PASS', f"Found {num_pairs} valid pairs in {pair_file.name}")
        
        except Exception as e:
            return CheckResult('FAIL', f"Error reading pair list: {e}")
    
    def _check_image_dimensions(self) -> CheckResult:
        """Check #3: Sample images have correct dimensions (1024×768)."""
        try:
            # Sample 10 random person images
            person_dir = self.root / self.paths.image
            person_files = list(person_dir.glob("*.jpg"))[:10]
            
            if not person_files:
                return CheckResult('FAIL', f"No images found in {person_dir}")
            
            wrong_dims = []
            for img_path in person_files:
                img = Image.open(img_path)
                if img.size != (768, 1024):  # PIL: (width, height)
                    wrong_dims.append((img_path.name, img.size))
            
            if wrong_dims:
                return CheckResult('WARN', f"Some images have wrong dimensions: {wrong_dims[:3]}")
            
            return CheckResult('PASS', f"Sampled {len(person_files)} images, all 768×1024")
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking dimensions: {e}")
    
    def _check_parse_class_distribution(self) -> CheckResult:
        """
        Check #4 [CRITICAL]: MOD-2 parse maps have valid LIP-20 class distribution.
        Also checks MOD-8 (agnostic parse) for valid binarization input.
        """
        try:
            parse_dir = self.root / self.paths.parse
            parse_files = list(parse_dir.glob("*.png"))[:500]
            
            if not parse_files:
                return CheckResult('FAIL', f"No parse maps found in {parse_dir}")
            
            class_counts = np.zeros(25, dtype=np.int64)
            has_class5 = 0
            
            for parse_path in parse_files:
                img = Image.open(parse_path)
                if img.mode != 'P':
                    img = img.convert('P')
                arr = np.array(img, dtype=np.int64)
                
                # Check for invalid class IDs
                if arr.max() >= 20:
                    return CheckResult('FAIL', f"Invalid class ID {arr.max()} in {parse_path.name}")
                
                # Count classes
                for c in range(20):
                    class_counts[c] += (arr == c).sum()
                
                # Check for class 5 (upper-cloth)
                if (arr == 5).any():
                    has_class5 += 1
            
            class5_pct = (has_class5 / len(parse_files)) * 100
            
            if class5_pct < 50:
                return CheckResult('WARN', 
                    f"Only {class5_pct:.1f}% of samples have class-5 (upper-cloth). "
                    f"Expected >80% for menswear dataset.")
            
            details = {
                'num_samples': len(parse_files),
                'class5_percentage': class5_pct,
                'class_counts': class_counts[:20].tolist(),
            }
            
            return CheckResult('PASS', 
                f"Parse maps valid. Class-5 present in {class5_pct:.1f}% of samples.",
                details=details)
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking parse distribution: {e}")
    
    def _check_label_mapping_correctness(self) -> CheckResult:
        """
        Check #5 [CRITICAL]: LIP20→UNIFIED25 mapping preserves class-5 pixel count.
        Also verifies MOD-8 binarization produces valid binary output.
        """
        try:
            parse_dir = self.root / self.paths.parse
            agn_parse_dir = self.root / self.paths.agnostic_mask
            
            parse_files = list(parse_dir.glob("*.png"))[:100]
            
            mapping_errors = []
            binary_errors = []
            
            for parse_path in parse_files:
                # Check MOD-2 mapping
                img = Image.open(parse_path)
                if img.mode != 'P':
                    img = img.convert('P')
                parse_lip20 = np.array(img, dtype=np.int64)
                
                parse_u25 = remap_labels(
                    torch.from_numpy(parse_lip20).long(),
                    LIP20_TO_UNIFIED25,
                    target_vocab_size=25
                )
                
                if not verify_class5_preservation(parse_lip20, parse_u25):
                    mapping_errors.append(parse_path.name)
                
                # Check MOD-8 binarization
                agn_parse_path = agn_parse_dir / parse_path.name
                if agn_parse_path.exists():
                    agn_img = Image.open(agn_parse_path)
                    if agn_img.mode != 'P':
                        agn_img = agn_img.convert('P')
                    agn_parse = np.array(agn_img, dtype=np.int64)
                    
                    binary_mask = binarize_agnostic_parse(agn_parse)
                    
                    # Verify binary output
                    unique_vals = np.unique(binary_mask)
                    if not np.all((unique_vals == 0.0) | (unique_vals == 1.0)):
                        binary_errors.append(parse_path.name)
                    
                    # Verify garment region is visible
                    if binary_mask.mean() < 0.01:
                        binary_errors.append(f"{parse_path.name} (too small)")
            
            if mapping_errors:
                return CheckResult('FAIL', 
                    f"Class-5 pixel count NOT preserved in {len(mapping_errors)} samples: "
                    f"{mapping_errors[:5]}")
            
            if binary_errors:
                return CheckResult('FAIL', 
                    f"MOD-8 binarization errors in {len(binary_errors)} samples: "
                    f"{binary_errors[:5]}")
            
            return CheckResult('PASS', 
                f"Checked {len(parse_files)} samples. "
                f"LIP-20→UNIFIED-25 mapping correct. MOD-8 binarization valid.")
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking label mapping: {e}")
    
    def _check_densepose_coverage(self) -> CheckResult:
        """Check #6: DensePose coverage statistics."""
        try:
            densepose_dir = self.root / self.paths.densepose
            densepose_files = list(densepose_dir.glob("*.png"))[:200]
            
            if not densepose_files:
                return CheckResult('WARN', f"No DensePose files found in {densepose_dir}")
            
            coverages = []
            for dp_path in densepose_files:
                img = Image.open(dp_path).convert("RGB")
                arr = np.array(img, dtype=np.float32) / 255.0
                part_id = (arr[:, :, 0] * 255).astype(np.int64)
                coverage = (part_id > 0).mean()
                coverages.append(coverage)
            
            coverages = np.array(coverages)
            mean_cov = coverages.mean()
            below_threshold = (coverages < self.cfg.data.densepose_min_coverage).sum()
            
            details = {
                'mean_coverage': float(mean_cov),
                'min_coverage': float(coverages.min()),
                'max_coverage': float(coverages.max()),
                'below_threshold': int(below_threshold),
                'threshold': self.cfg.data.densepose_min_coverage,
            }
            
            if mean_cov < 0.10:
                return CheckResult('WARN', 
                    f"Low DensePose coverage (mean={mean_cov:.2%}). "
                    f"{below_threshold}/{len(coverages)} below threshold.",
                    details=details)
            
            return CheckResult('PASS', 
                f"DensePose coverage OK (mean={mean_cov:.2%}). "
                f"{below_threshold}/{len(coverages)} below threshold.",
                details=details)
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking DensePose: {e}")
    
    def _check_openpose_quality(self) -> CheckResult:
        """Check #7: OpenPose keypoint detection rate."""
        try:
            openpose_json_dir = self.root / self.paths.openpose_json
            json_files = list(openpose_json_dir.glob("*.json"))[:200]
            
            if not json_files:
                return CheckResult('WARN', 
                    f"No OpenPose JSON files found in {openpose_json_dir}")
            
            detected = 0
            for json_path in json_files:
                with open(json_path) as f:
                    data = json.load(f)
                if data.get('people'):
                    detected += 1
            
            detection_rate = (detected / len(json_files)) * 100
            
            if detection_rate < 90:
                return CheckResult('WARN', 
                    f"OpenPose detection rate: {detection_rate:.1f}% "
                    f"({detected}/{len(json_files)})")
            
            return CheckResult('PASS', 
                f"OpenPose detection rate: {detection_rate:.1f}% "
                f"({detected}/{len(json_files)})")
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking OpenPose: {e}")
    
    def _check_agnostic_mask_coverage(self) -> CheckResult:
        """Check #8: Agnostic mask (MOD-8) coverage after binarization."""
        try:
            agn_parse_dir = self.root / self.paths.agnostic_mask
            agn_files = list(agn_parse_dir.glob("*.png"))[:100]
            
            if not agn_files:
                return CheckResult('FAIL', 
                    f"No agnostic parse files found in {agn_parse_dir}")
            
            coverages = []
            for agn_path in agn_files:
                img = Image.open(agn_path)
                if img.mode != 'P':
                    img = img.convert('P')
                arr = np.array(img, dtype=np.int64)
                binary_mask = binarize_agnostic_parse(arr)
                coverages.append(binary_mask.mean())
            
            coverages = np.array(coverages)
            mean_cov = coverages.mean()
            
            if mean_cov < 0.05:
                return CheckResult('WARN', 
                    f"Low agnostic mask coverage (mean={mean_cov:.2%})")
            
            return CheckResult('PASS', 
                f"Agnostic mask coverage OK (mean={mean_cov:.2%})")
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking agnostic masks: {e}")
    
    def _check_warp_cloth_availability(self) -> CheckResult:
        """
        Check #9 [INFO]: Documents that MOD-10/11 are absent (expected for your data).
        Training continues normally — L_warp_pt and L_warp_m return 0.0.
        """
        wc_path = getattr(self.paths, 'warp_cloth', None)
        wcm_path = getattr(self.paths, 'warp_cloth_mask', None)
        
        if wc_path is None and wcm_path is None:
            msg = (
                "MOD-10 (warp-cloth) and MOD-11 (warp-cloth-mask) are absent "
                "(paths.warp_cloth=null in config). L_warp_pt and L_warp_m will "
                "return 0.0 tensors. Training proceeds normally."
            )
            self.info.append(msg)
            return CheckResult('INFO', msg)
        
        # If paths configured but folders don't exist
        if wc_path and not (self.root / wc_path).exists():
            return CheckResult('INFO', 
                f"warp_cloth configured but folder not found: {wc_path}")
        
        if wcm_path and not (self.root / wcm_path).exists():
            return CheckResult('INFO', 
                f"warp_cloth_mask configured but folder not found: {wcm_path}")
        
        return CheckResult('PASS', "Warp cloth folders present")
    
    def _check_cloth_mask_quality(self) -> CheckResult:
        """Check #10: Cloth masks are properly binary."""
        try:
            cloth_mask_dir = self.root / self.paths.cloth_mask
            mask_files = list(cloth_mask_dir.glob("*.png"))[:100]
            
            if not mask_files:
                return CheckResult('FAIL', 
                    f"No cloth masks found in {cloth_mask_dir}")
            
            non_binary = []
            for mask_path in mask_files:
                img = Image.open(mask_path).convert("L")
                arr = np.array(img, dtype=np.uint8)
                unique_vals = np.unique(arr)
                
                # Allow small variations due to compression, but check it's mostly binary
                if len(unique_vals) > 5:
                    non_binary.append(mask_path.name)
            
            if non_binary:
                return CheckResult('WARN', 
                    f"Some cloth masks not binary: {non_binary[:5]}")
            
            return CheckResult('PASS', 
                f"Checked {len(mask_files)} cloth masks, all appear binary")
        
        except Exception as e:
            return CheckResult('FAIL', f"Error checking cloth masks: {e}")
    
    def _build_report(self, checks: List[tuple]) -> Dict:
        """Build final validation report."""
        report = {
            'split': self.split,
            'root': str(self.root),
            'checks': [],
            'summary': {
                'total': len(checks),
                'passed': 0,
                'failed': 0,
                'warnings': 0,
                'info': 0,
            }
        }
        
        for name, result in checks:
            report['checks'].append({
                'name': name,
                'status': result.status,
                'message': result.message,
                'details': result.details,
            })
            
            if result.status == 'PASS':
                report['summary']['passed'] += 1
            elif result.status == 'FAIL':
                report['summary']['failed'] += 1
            elif result.status == 'WARN':
                report['summary']['warnings'] += 1
            elif result.status == 'INFO':
                report['summary']['info'] += 1
        
        # Print colored summary
        self._print_summary(report)
        
        return report
    
    def _print_summary(self, report: Dict):
        """Print colored validation summary."""
        print("\n" + "=" * 80)
        print(f"VITON-HD VALIDATION REPORT — {report['split'].upper()} SPLIT")
        print("=" * 80)
        
        for check in report['checks']:
            status_color = {
                'PASS': '\033[92m',  # Green
                'FAIL': '\033[91m',  # Red
                'WARN': '\033[93m',  # Yellow
                'INFO': '\033[94m',  # Blue
            }.get(check['status'], '')
            reset_color = '\033[0m'
            
            print(f"{status_color}[{check['status']:^6}]{reset_color} {check['name']:<30} {check['message']}")
        
        print("=" * 80)
        summary = report['summary']
        print(f"Summary: {summary['passed']} Passed | {summary['failed']} Failed | "
              f"{summary['warnings']} Warnings | {summary['info']} Info")
        print("=" * 80 + "\n")
        
        if summary['failed'] > 0:
            logger.error(f"{summary['failed']} critical checks failed. "
                        f"Fix these issues before training.")
        elif summary['warnings'] > 0:
            logger.warning(f"{summary['warnings']} warnings found. "
                          f"Training can proceed but review these issues.")
        else:
            logger.info("All validation checks passed!")
