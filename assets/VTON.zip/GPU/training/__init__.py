"""
Training Package

Exports all training components:
- EMA (Exponential Moving Average)
- Callbacks (gradient clipping, checkpointing, logging)
- LightningModule (main training logic)
- Trainer setup
"""

from .ema import ExponentialMovingAverage
from .callbacks import (
    PerModuleGradientClip,
    GradientNormLogger,
    LossWeightLogger,
    WarmupPhaseLogger,
    get_default_callbacks,
)
from .lightning_module import VirtualTryOnLightningModule
from .trainer_setup import setup_trainer, setup_logger

__all__ = [
    # EMA
    'ExponentialMovingAverage',
    
    # Callbacks
    'PerModuleGradientClip',
    'GradientNormLogger',
    'LossWeightLogger',
    'WarmupPhaseLogger',
    'get_default_callbacks',
    
    # Lightning Module
    'VirtualTryOnLightningModule',
    
    # Trainer Setup
    'setup_trainer',
    'setup_logger',
]
