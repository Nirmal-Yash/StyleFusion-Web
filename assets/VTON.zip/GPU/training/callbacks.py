"""
PyTorch Lightning Callbacks for Virtual Try-On Training

Custom callbacks for:
1. Per-module gradient clipping
2. Best model checkpointing
3. Loss-specific monitoring
4. EMA updates (handled in LightningModule)

Key features:
- PerModuleGradientClip: Different gradient norms for different modules
- Better than global gradient clipping for multi-module systems
"""

import torch
import torch.nn as nn
from pytorch_lightning.callbacks import Callback, ModelCheckpoint
from typing import Dict, Optional, List
import numpy as np


class PerModuleGradientClip(Callback):
    """
    Apply different gradient clipping norms to different modules.
    
    This is crucial for systems with multiple sub-modules that have
    different gradient scales (e.g., pretrained UNet vs. custom warper).
    
    Args:
        module_clip_norms: dict mapping module names to max gradient norms
            e.g., {
                'diffusion_unet': 1.0,
                'warping_module': 5.0,
                'compositor': 2.0,
            }
        clip_algorithm: 'norm' or 'value' (default: 'norm')
    
    Example:
        >>> callback = PerModuleGradientClip({
        >>>     'diffusion_unet': 1.0,
        >>>     'warping_module': 5.0,
        >>> })
    """
    
    def __init__(
        self,
        module_clip_norms: Dict[str, float],
        clip_algorithm: str = 'norm',
    ):
        super().__init__()
        self.module_clip_norms = module_clip_norms
        self.clip_algorithm = clip_algorithm
        
        assert clip_algorithm in ['norm', 'value'], \
            f"clip_algorithm must be 'norm' or 'value', got {clip_algorithm}"
    
    def on_before_optimizer_step(self, trainer, pl_module, optimizer):
        """
        Clip gradients before optimizer step.
        
        Called by Lightning before optimizer.step().
        """
        # Clip each module separately
        for module_name, max_norm in self.module_clip_norms.items():
            # Get module
            if hasattr(pl_module.model, module_name):
                module = getattr(pl_module.model, module_name)
            else:
                # Try nested access (e.g., 'model.diffusion_unet')
                parts = module_name.split('.')
                module = pl_module
                for part in parts:
                    module = getattr(module, part)
            
            # Collect parameters with gradients
            params = [p for p in module.parameters() if p.grad is not None]
            
            if len(params) == 0:
                continue
            
            # Clip gradients
            if self.clip_algorithm == 'norm':
                torch.nn.utils.clip_grad_norm_(params, max_norm)
            else:  # 'value'
                torch.nn.utils.clip_grad_value_(params, max_norm)


class GradientNormLogger(Callback):
    """
    Log gradient norms for each module.
    
    Helps monitor gradient flow and identify vanishing/exploding gradients.
    
    Args:
        module_names: list of module names to monitor
        log_every_n_steps: logging frequency (default: 100)
    """
    
    def __init__(
        self,
        module_names: List[str],
        log_every_n_steps: int = 100,
    ):
        super().__init__()
        self.module_names = module_names
        self.log_every_n_steps = log_every_n_steps
    
    def on_before_optimizer_step(self, trainer, pl_module, optimizer):
        """Log gradient norms."""
        if trainer.global_step % self.log_every_n_steps != 0:
            return
        
        for module_name in self.module_names:
            # Get module
            if hasattr(pl_module.model, module_name):
                module = getattr(pl_module.model, module_name)
            else:
                parts = module_name.split('.')
                module = pl_module
                for part in parts:
                    module = getattr(module, part)
            
            # Compute gradient norm
            total_norm = 0.0
            for p in module.parameters():
                if p.grad is not None:
                    param_norm = p.grad.data.norm(2)
                    total_norm += param_norm.item() ** 2
            total_norm = total_norm ** 0.5
            
            # Log
            pl_module.log(
                f'grad_norm/{module_name}',
                total_norm,
                on_step=True,
                on_epoch=False,
                prog_bar=False,
            )


class LossWeightLogger(Callback):
    """
    Log current loss weights from dynamic schedule.
    
    Helps track how loss balancing changes over epochs.
    
    Args:
        log_every_n_epochs: logging frequency (default: 1)
    """
    
    def __init__(self, log_every_n_epochs: int = 1):
        super().__init__()
        self.log_every_n_epochs = log_every_n_epochs
    
    def on_train_epoch_start(self, trainer, pl_module):
        """Log loss weights at epoch start."""
        if trainer.current_epoch % self.log_every_n_epochs != 0:
            return
        
        # Get current weights from loss computer
        if hasattr(pl_module, 'loss_computer'):
            from losses import get_loss_weights
            weights = get_loss_weights(trainer.current_epoch)
            
            for name, value in weights.items():
                pl_module.log(
                    f'loss_weights/{name}',
                    value,
                    on_step=False,
                    on_epoch=True,
                    prog_bar=False,
                )


class WarmupPhaseLogger(Callback):
    """
    Log when warm-up phase transitions occur.
    
    Indicates when warp warm-up ends and full training begins.
    
    Args:
        warmup_epochs: number of warm-up epochs (default: 2)
    """
    
    def __init__(self, warmup_epochs: int = 2):
        super().__init__()
        self.warmup_epochs = warmup_epochs
        self.logged_transition = False
    
    def on_train_epoch_start(self, trainer, pl_module):
        """Log phase transitions."""
        epoch = trainer.current_epoch
        
        if epoch == 0:
            print("\n" + "=" * 80)
            print("🔥 WARP WARM-UP PHASE (Epochs 0-1)")
            print("   - Only training warping module + new UNet input channels")
            print("   - Diffusion UNet, IP-Adapter, and other modules FROZEN")
            print("=" * 80 + "\n")
        
        elif epoch == self.warmup_epochs and not self.logged_transition:
            print("\n" + "=" * 80)
            print("🚀 FULL TRAINING PHASE (Epochs 2+)")
            print("   - All modules now trainable")
            print("   - Joint optimization of warping + diffusion + composition")
            print("=" * 80 + "\n")
            self.logged_transition = True


def get_default_callbacks(cfg) -> List[Callback]:
    """
    Get default callbacks for Virtual Try-On training.
    
    Args:
        cfg: config object with training parameters
    
    Returns:
        list of Lightning callbacks
    """
    callbacks = []
    
    # 1. Per-module gradient clipping
    module_clip_norms = {
        'diffusion_unet': 1.0,    # Pretrained, needs small gradients
        'warping_module': 5.0,    # Custom module, can handle larger gradients
        'body_encoder': 2.0,
        'garment_extractor': 2.0,
        'compositor': 2.0,
        'ip_adapter': 1.0,        # CLIP-based, needs stability
    }
    
    callbacks.append(PerModuleGradientClip(module_clip_norms))
    
    # 2. Best model checkpoint (based on validation loss)
    checkpoint_callback = ModelCheckpoint(
        dirpath=cfg.logging.get('checkpoint_dir', 'checkpoints'),
        filename='best-{epoch:02d}-{val_loss:.4f}',
        monitor='val/loss',
        mode='min',
        save_top_k=3,
        save_last=True,
        verbose=True,
    )
    callbacks.append(checkpoint_callback)
    
    # 3. Epoch-based checkpoint (every 10 epochs)
    epoch_checkpoint = ModelCheckpoint(
        dirpath=cfg.logging.get('checkpoint_dir', 'checkpoints'),
        filename='epoch-{epoch:02d}',
        every_n_epochs=10,
        save_top_k=-1,  # Keep all
        verbose=False,
    )
    callbacks.append(epoch_checkpoint)
    
    # 4. Gradient norm logger
    module_names = [
        'diffusion_unet',
        'warping_module',
        'body_encoder',
        'compositor',
    ]
    callbacks.append(GradientNormLogger(module_names, log_every_n_steps=100))
    
    # 5. Loss weight logger
    callbacks.append(LossWeightLogger(log_every_n_epochs=1))
    
    # 6. Warm-up phase logger
    warmup_epochs = cfg.model.diffusion.get('warp_warmup_epochs', cfg.training.get('warmup_epochs', 2))
    callbacks.append(WarmupPhaseLogger(warmup_epochs))
    
    return callbacks


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_callbacks():
    """Test callback functionality."""
    print("Testing custom callbacks...")
    
    # Test PerModuleGradientClip
    print("\n1. Testing PerModuleGradientClip...")
    
    class DummyModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.module_a = nn.Linear(10, 5)
            self.module_b = nn.Linear(5, 2)
    
    model = DummyModel()
    
    # Create large gradients
    for p in model.module_a.parameters():
        if p.requires_grad:
            p.grad = torch.randn_like(p) * 100  # Large gradients
    
    for p in model.module_b.parameters():
        if p.requires_grad:
            p.grad = torch.randn_like(p) * 100
    
    # Compute initial norm
    norm_a_before = torch.nn.utils.clip_grad_norm_(
        model.module_a.parameters(), float('inf')
    )
    norm_b_before = torch.nn.utils.clip_grad_norm_(
        model.module_b.parameters(), float('inf')
    )
    
    print(f"   Norm before clipping - module_a: {norm_a_before:.2f}, module_b: {norm_b_before:.2f}")
    
    # Test gradient clipping (manual simulation)
    torch.nn.utils.clip_grad_norm_(model.module_a.parameters(), 1.0)
    torch.nn.utils.clip_grad_norm_(model.module_b.parameters(), 5.0)
    
    norm_a_after = torch.nn.utils.clip_grad_norm_(
        model.module_a.parameters(), float('inf')
    )
    norm_b_after = torch.nn.utils.clip_grad_norm_(
        model.module_b.parameters(), float('inf')
    )
    
    print(f"   Norm after clipping  - module_a: {norm_a_after:.2f}, module_b: {norm_b_after:.2f}")
    
    assert norm_a_after <= 1.0 + 1e-5, "module_a should be clipped to 1.0"
    assert norm_b_after <= 5.0 + 1e-5, "module_b should be clipped to 5.0"
    print("   ✓ Per-module clipping works correctly")
    
    # Test get_default_callbacks
    print("\n2. Testing get_default_callbacks...")
    
    class DummyConfig:
        checkpoint_dir = 'checkpoints'
        warmup_epochs = 2
    
    cfg = DummyConfig()
    callbacks = get_default_callbacks(cfg)
    
    assert len(callbacks) > 0, "Should return callbacks"
    
    # Check callback types
    has_clip = any(isinstance(cb, PerModuleGradientClip) for cb in callbacks)
    has_checkpoint = any(isinstance(cb, ModelCheckpoint) for cb in callbacks)
    has_grad_logger = any(isinstance(cb, GradientNormLogger) for cb in callbacks)
    has_weight_logger = any(isinstance(cb, LossWeightLogger) for cb in callbacks)
    has_warmup = any(isinstance(cb, WarmupPhaseLogger) for cb in callbacks)
    
    assert has_clip, "Should include PerModuleGradientClip"
    assert has_checkpoint, "Should include ModelCheckpoint"
    assert has_grad_logger, "Should include GradientNormLogger"
    assert has_weight_logger, "Should include LossWeightLogger"
    assert has_warmup, "Should include WarmupPhaseLogger"
    
    print(f"   ✓ get_default_callbacks returns {len(callbacks)} callbacks")
    
    print("\n✅ All callback tests passed!")


if __name__ == '__main__':
    test_callbacks()
