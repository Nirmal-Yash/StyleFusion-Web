"""
Exponential Moving Average (EMA) for Model Parameters

Maintains shadow copies of model parameters that are updated with exponential decay.
EMA weights are used during validation/inference for improved stability.

Update rule:
    shadow_param = decay * shadow_param + (1 - decay) * current_param

Key features:
- Updates every N steps (default: 10)
- Separate shadow parameters on same device as model
- Load/store/apply methods for checkpointing and inference
- Automatic device handling
"""

import torch
import torch.nn as nn
from copy import deepcopy
from typing import Optional


class ExponentialMovingAverage:
    """
    Exponential Moving Average for model parameters.
    
    Args:
        model: nn.Module to track
        decay: EMA decay rate (default: 0.9999)
        update_every: update EMA every N steps (default: 10)
        device: device for shadow params (default: same as model)
    
    Example:
        >>> model = MyModel()
        >>> ema = ExponentialMovingAverage(model, decay=0.9999)
        >>> 
        >>> for step, batch in enumerate(dataloader):
        >>>     loss = model(batch)
        >>>     loss.backward()
        >>>     optimizer.step()
        >>>     
        >>>     # Update EMA every 10 steps
        >>>     ema.update(step)
        >>> 
        >>> # Use EMA weights for validation
        >>> ema.apply_shadow()
        >>> val_loss = validate(model, val_loader)
        >>> ema.restore()
    """
    
    def __init__(
        self,
        model: nn.Module,
        decay: float = 0.9999,
        update_every: int = 10,
        device: Optional[torch.device] = None,
    ):
        self.model = model
        self.decay = decay
        self.update_every = update_every
        self.device = device
        
        # Store shadow parameters
        self.shadow_params = {}
        self._register_shadow_params()
        
        # Store backup of original params (for restore)
        self.backup_params = {}
        
        # Step counter
        self.step = 0
    
    def _register_shadow_params(self):
        """Initialize shadow parameters from current model state."""
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                device = self.device if self.device is not None else param.device
                # Clone to shadow params
                self.shadow_params[name] = param.data.clone().to(device)
    
    def update(self, step: Optional[int] = None):
        """
        Update EMA shadow parameters.
        
        Args:
            step: current training step (auto-increments if None)
        """
        if step is not None:
            self.step = step
        else:
            self.step += 1
        
        # Only update every N steps
        if self.step % self.update_every != 0:
            return
        
        # Update shadow parameters
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if param.requires_grad and name in self.shadow_params:
                    # shadow = decay * shadow + (1 - decay) * param
                    self.shadow_params[name].mul_(self.decay).add_(
                        param.data.to(self.shadow_params[name].device),
                        alpha=1.0 - self.decay
                    )
    
    def apply_shadow(self):
        """
        Replace model parameters with EMA shadow parameters.
        
        Original parameters are backed up and can be restored with restore().
        Use this before validation/inference.
        """
        self.backup_params = {}
        
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if param.requires_grad and name in self.shadow_params:
                    # Backup original
                    self.backup_params[name] = param.data.clone()
                    
                    # Replace with shadow
                    param.data.copy_(
                        self.shadow_params[name].to(param.device)
                    )
    
    def restore(self):
        """
        Restore original model parameters after apply_shadow().
        
        Use this after validation to resume training.
        """
        if not self.backup_params:
            return  # Nothing to restore
        
        with torch.no_grad():
            for name, param in self.model.named_parameters():
                if name in self.backup_params:
                    param.data.copy_(self.backup_params[name])
        
        # Clear backup
        self.backup_params = {}
    
    def state_dict(self) -> dict:
        """
        Get state dict for checkpointing.
        
        Returns:
            dict with shadow params + metadata
        """
        return {
            'shadow_params': {k: v.cpu() for k, v in self.shadow_params.items()},
            'decay': self.decay,
            'update_every': self.update_every,
            'step': self.step,
        }
    
    def load_state_dict(self, state_dict: dict):
        """
        Load EMA state from checkpoint.
        
        Args:
            state_dict: dict from state_dict()
        """
        self.decay = state_dict['decay']
        self.update_every = state_dict['update_every']
        self.step = state_dict['step']
        
        # Load shadow params
        for name, shadow_param in state_dict['shadow_params'].items():
            if name in self.shadow_params:
                device = self.shadow_params[name].device
                self.shadow_params[name].copy_(shadow_param.to(device))
    
    def to(self, device: torch.device):
        """Move shadow parameters to device."""
        self.device = device
        for name in self.shadow_params:
            self.shadow_params[name] = self.shadow_params[name].to(device)
        return self


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_ema():
    """Test EMA functionality."""
    print("Testing ExponentialMovingAverage...")
    
    # Create simple model
    class SimpleModel(nn.Module):
        def __init__(self):
            super().__init__()
            self.linear = nn.Linear(10, 5)
        
        def forward(self, x):
            return self.linear(x)
    
    model = SimpleModel()
    
    # Initialize EMA
    ema = ExponentialMovingAverage(model, decay=0.999, update_every=10)
    
    print(f"✓ EMA initialized with {len(ema.shadow_params)} parameters")
    
    # Get initial param values
    initial_weight = model.linear.weight.data.clone()
    initial_shadow = ema.shadow_params['linear.weight'].clone()
    
    # Verify initial shadow == model params
    assert torch.allclose(initial_weight, initial_shadow), "Initial shadow should equal model params"
    print("✓ Initial shadow params equal model params")
    
    # Simulate training steps
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    
    for step in range(25):
        # Forward + backward
        x = torch.randn(4, 10)
        y_target = torch.randn(4, 5)
        
        y_pred = model(x)
        loss = ((y_pred - y_target) ** 2).mean()
        
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        
        # Update EMA
        ema.update(step)
    
    # After 25 steps, model params should have changed
    current_weight = model.linear.weight.data.clone()
    assert not torch.allclose(current_weight, initial_weight), "Model params should change"
    print("✓ Model parameters updated during training")
    
    # Shadow params should be different from current (smoothed)
    current_shadow = ema.shadow_params['linear.weight'].clone()
    assert not torch.allclose(current_shadow, current_weight), "Shadow should differ from current"
    print("✓ Shadow parameters are smoothed")
    
    # Test apply_shadow / restore
    ema.apply_shadow()
    shadow_weight = model.linear.weight.data.clone()
    assert torch.allclose(shadow_weight, current_shadow), "Model params should equal shadow"
    print("✓ apply_shadow() replaces model params")
    
    ema.restore()
    restored_weight = model.linear.weight.data.clone()
    assert torch.allclose(restored_weight, current_weight), "Restored params should equal original"
    print("✓ restore() recovers original params")
    
    # Test state_dict / load_state_dict
    state = ema.state_dict()
    assert 'shadow_params' in state
    assert 'decay' in state
    assert state['step'] == 25
    print("✓ state_dict() contains all metadata")
    
    # Create new EMA and load state
    model2 = SimpleModel()
    ema2 = ExponentialMovingAverage(model2, decay=0.999)
    ema2.load_state_dict(state)
    
    assert ema2.step == 25
    assert torch.allclose(
        ema2.shadow_params['linear.weight'],
        ema.shadow_params['linear.weight']
    ), "Loaded shadow params should match"
    print("✓ load_state_dict() restores EMA state")
    
    # Test device movement
    if torch.cuda.is_available():
        ema.to(torch.device('cuda'))
        assert ema.shadow_params['linear.weight'].device.type == 'cuda'
        print("✓ to(device) moves shadow params")
    
    print("\n✅ All EMA tests passed!")


if __name__ == '__main__':
    test_ema()
