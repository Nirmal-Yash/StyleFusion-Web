"""
PyTorch Lightning Trainer Setup

Configure Trainer with:
- Mixed precision (bf16-mixed)
- Gradient accumulation
- Callbacks
- Logger
- Distributed training settings
- Profiling
"""

import pytorch_lightning as pl
from pytorch_lightning.loggers import TensorBoardLogger, WandbLogger
from pytorch_lightning.strategies import DDPStrategy
from omegaconf import DictConfig
from typing import Optional, List

from .callbacks import get_default_callbacks


def setup_logger(cfg: DictConfig):
    """
    Setup logger (TensorBoard or W&B).
    
    Args:
        cfg: config object
    
    Returns:
        Lightning logger
    """
    logger_type = cfg.logging.get('logger', 'tensorboard')
    
    if logger_type == 'wandb':
        logger = WandbLogger(
            project=cfg.logging.get('project_name', 'virtual-tryon'),
            name=cfg.logging.get('run_name', None),
            save_dir=cfg.logging.get('log_dir', 'logs'),
            log_model=cfg.logging.get('log_model', False),
        )
        print(f"✓ Using WandB logger: project={cfg.logging.get('project_name')}")
    
    else:  # tensorboard
        logger = TensorBoardLogger(
            save_dir=cfg.logging.get('log_dir', 'logs'),
            name=cfg.logging.get('run_name', 'tryon'),
            version=None,  # Auto-increment
        )
        print(f"✓ Using TensorBoard logger: {logger.log_dir}")
    
    return logger


def setup_trainer(
    cfg: DictConfig,
    callbacks: Optional[List] = None,
) -> pl.Trainer:
    """
    Setup PyTorch Lightning Trainer.
    
    Args:
        cfg: config object with training parameters
        callbacks: optional list of callbacks (uses defaults if None)
    
    Returns:
        configured Trainer
    """
    # Get callbacks
    if callbacks is None:
        callbacks = get_default_callbacks(cfg)
    
    # Setup logger
    logger = setup_logger(cfg)
    
    # Precision
    precision = cfg.training.get('precision', 'bf16-mixed')
    
    # Gradient accumulation
    accumulate_grad_batches = cfg.training.get('accumulate_grad_batches', 1)
    
    # Max epochs/steps
    max_epochs = cfg.training.get('max_epochs', 100)
    max_steps = cfg.training.get('max_steps', -1)  # -1 = use max_epochs
    
    # Validation
    val_check_interval = cfg.training.get('val_check_interval', 1.0)  # 1.0 = once per epoch
    limit_val_batches = cfg.training.get('limit_val_batches', 1.0)  # 1.0 = full validation
    
    # Distributed strategy
    if cfg.training.get('num_gpus', 1) > 1:
        strategy = DDPStrategy(
            find_unused_parameters=False,  # Set to True if needed
            gradient_as_bucket_view=True,
        )
        print(f"✓ Using DDP strategy with {cfg.training.num_gpus} GPUs")
    else:
        strategy = 'auto'
    
    # Gradient clipping (handled by PerModuleGradientClip callback)
    gradient_clip_val = None
    gradient_clip_algorithm = None
    
    # Profiling
    profiler = None
    if cfg.training.get('profile', False):
        profiler = 'simple'  # or 'advanced' or 'pytorch'
        print("✓ Profiling enabled")
    
    # Create trainer
    trainer = pl.Trainer(
        # Hardware
        accelerator='gpu' if cfg.training.get('num_gpus', 1) > 0 else 'cpu',
        devices=cfg.training.get('num_gpus', 1),
        strategy=strategy,
        
        # Precision
        precision=precision,
        
        # Epochs/Steps
        max_epochs=max_epochs,
        max_steps=max_steps,
        
        # Gradient accumulation
        accumulate_grad_batches=accumulate_grad_batches,
        
        # Gradient clipping (handled by callbacks)
        gradient_clip_val=gradient_clip_val,
        gradient_clip_algorithm=gradient_clip_algorithm,
        
        # Validation
        val_check_interval=val_check_interval,
        limit_val_batches=limit_val_batches,
        check_val_every_n_epoch=cfg.training.get('check_val_every_n_epoch', 1),
        
        # Logging
        logger=logger,
        log_every_n_steps=cfg.logging.get('log_every_n_steps', 50),
        
        # Callbacks
        callbacks=callbacks,
        
        # Checkpointing
        enable_checkpointing=True,
        
        # Performance
        benchmark=cfg.training.get('benchmark', True),  # cudnn.benchmark
        deterministic=cfg.training.get('deterministic', False),
        
        # Debugging
        profiler=profiler,
        detect_anomaly=cfg.training.get('detect_anomaly', False),
        
        # Other
        enable_progress_bar=True,
        enable_model_summary=True,
        num_sanity_val_steps=cfg.training.get('num_sanity_val_steps', 2),
    )
    
    print(f"\n{'='*80}")
    print("Trainer Configuration:")
    print(f"  Accelerator: {trainer.accelerator.__class__.__name__}")
    print(f"  Devices: {trainer.num_devices}")
    print(f"  Precision: {precision}")
    print(f"  Max Epochs: {max_epochs}")
    print(f"  Gradient Accumulation: {accumulate_grad_batches} batches")
    print(f"  Validation: every {val_check_interval} epoch(s)")
    print(f"  Callbacks: {len(callbacks)}")
    print(f"{'='*80}\n")
    
    return trainer


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_trainer_setup():
    """Test Trainer setup."""
    print("Testing Trainer setup...")
    
    from omegaconf import OmegaConf
    
    # Create minimal config
    cfg = OmegaConf.create({
        'training': {
            'num_gpus': 1,
            'precision': 'bf16-mixed',
            'max_epochs': 100,
            'max_steps': -1,
            'accumulate_grad_batches': 4,
            'val_check_interval': 1.0,
            'limit_val_batches': 1.0,
            'check_val_every_n_epoch': 1,
            'benchmark': True,
            'deterministic': False,
            'profile': False,
            'detect_anomaly': False,
            'num_sanity_val_steps': 2,
            'warmup_epochs': 2,
        },
        'logging': {
            'logger': 'tensorboard',
            'log_dir': 'logs',
            'run_name': 'test_run',
            'log_every_n_steps': 50,
        },
        'checkpoint_dir': 'checkpoints',
    })
    
    print("✓ Config created")
    
    # Setup logger
    logger = setup_logger(cfg)
    assert logger is not None, "Logger should be created"
    print(f"✓ Logger: {type(logger).__name__}")
    
    # Setup trainer
    trainer = setup_trainer(cfg)
    assert trainer is not None, "Trainer should be created"
    assert trainer.max_epochs == 100, "Max epochs should be 100"
    assert trainer.accumulate_grad_batches == 4, "Accumulate should be 4"
    print("✓ Trainer configured successfully")
    
    # Check callbacks
    assert len(trainer.callbacks) > 0, "Should have callbacks"
    print(f"✓ {len(trainer.callbacks)} callbacks registered")
    
    print("\n✅ Trainer setup test passed!")


if __name__ == '__main__':
    test_trainer_setup()
