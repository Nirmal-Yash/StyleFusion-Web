"""
Visualization utilities for training monitoring and results display.
"""

import torch
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, List, Optional
from pathlib import Path


def plot_training_curves(
    metrics: Dict[str, List[float]],
    save_path: Optional[Path] = None,
    figsize: tuple = (15, 10)
):
    """
    Plot training and validation curves for all metrics.
    
    Args:
        metrics: Dictionary with metric names as keys and lists of values
        save_path: Optional path to save the figure
        figsize: Figure size (width, height)
    """
    num_metrics = len(metrics)
    ncols = min(3, num_metrics)
    nrows = (num_metrics + ncols - 1) // ncols
    
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize)
    if num_metrics == 1:
        axes = [axes]
    else:
        axes = axes.flatten()
    
    for idx, (name, values) in enumerate(metrics.items()):
        ax = axes[idx]
        ax.plot(values)
        ax.set_title(name)
        ax.set_xlabel('Epoch' if 'epoch' in name.lower() else 'Step')
        ax.set_ylabel('Value')
        ax.grid(True, alpha=0.3)
    
    # Hide unused subplots
    for idx in range(num_metrics, len(axes)):
        axes[idx].axis('off')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    return fig


def plot_loss_components(
    loss_dict: Dict[str, float],
    save_path: Optional[Path] = None,
    figsize: tuple = (12, 6)
):
    """
    Plot bar chart of loss components for a single training step.
    
    Args:
        loss_dict: Dictionary with loss component names and values
        save_path: Optional path to save the figure
        figsize: Figure size (width, height)
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    names = list(loss_dict.keys())
    values = list(loss_dict.values())
    
    bars = ax.bar(names, values)
    ax.set_ylabel('Loss Value')
    ax.set_title('Loss Components')
    ax.tick_params(axis='x', rotation=45)
    
    # Color the total loss differently
    for i, name in enumerate(names):
        if 'total' in name.lower():
            bars[i].set_color('red')
            bars[i].set_alpha(0.7)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    return fig


def visualize_batch(
    batch: Dict[str, torch.Tensor],
    save_path: Optional[Path] = None,
    figsize: tuple = (20, 12)
):
    """
    Visualize all modalities in a batch sample.
    
    Args:
        batch: Batch dictionary with all modalities
        save_path: Optional path to save the figure
        figsize: Figure size (width, height)
    """
    fig, axes = plt.subplots(3, 4, figsize=figsize)
    axes = axes.flatten()
    
    def tensor_to_image(tensor: torch.Tensor) -> np.ndarray:
        """Convert tensor to displayable numpy array."""
        if tensor.ndim == 4:
            tensor = tensor[0]  # Take first batch item
        
        if tensor.shape[0] == 1:  # Single channel
            img = tensor[0].cpu().numpy()
        elif tensor.shape[0] == 3:  # RGB
            img = tensor.cpu().numpy().transpose(1, 2, 0)
            img = (img - img.min()) / (img.max() - img.min() + 1e-8)
        else:
            img = tensor[0].cpu().numpy()
        
        return img
    
    # Define visualization order and titles
    viz_items = [
        ('person_image', 'MOD-1: Person Image'),
        ('parse_unified25', 'MOD-2: Parse (UNIFIED-25)'),
        ('openpose_img', 'MOD-3: OpenPose Skeleton'),
        ('cloth_image', 'MOD-5: Cloth (Augmented)'),
        ('cloth_image_raw', 'MOD-5: Cloth (Raw for CLIP)'),
        ('cloth_mask', 'MOD-6: Cloth Mask'),
        ('agnostic_image', 'MOD-7: Agnostic Image'),
        ('agnostic_mask', 'MOD-8: Agnostic Mask (Binary)'),
        ('densepose_iuv', 'MOD-9: DensePose IUV'),
    ]
    
    for idx, (key, title) in enumerate(viz_items):
        if idx >= len(axes):
            break
        
        ax = axes[idx]
        
        if key in batch and batch[key] is not None:
            img = tensor_to_image(batch[key])
            
            if 'parse' in key:
                ax.imshow(img, cmap='tab20')
            elif 'mask' in key:
                ax.imshow(img, cmap='gray', vmin=0, vmax=1)
            else:
                ax.imshow(img)
            
            ax.set_title(title)
        else:
            ax.text(0.5, 0.5, f'{title}\n(ABSENT)', 
                   ha='center', va='center', fontsize=12)
        
        ax.axis('off')
    
    # Note MOD-10/11 absence
    axes[9].text(0.5, 0.5, 'MOD-10: warp_cloth\n(ABSENT - returns None)', 
                ha='center', va='center', fontsize=12, color='red')
    axes[9].axis('off')
    
    axes[10].text(0.5, 0.5, 'MOD-11: warp_cloth_mask\n(ABSENT - returns None)', 
                 ha='center', va='center', fontsize=12, color='red')
    axes[10].axis('off')
    
    # Hide last unused subplot
    axes[11].axis('off')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    return fig


def visualize_try_on_results(
    person_image: torch.Tensor,
    cloth_image: torch.Tensor,
    result_image: torch.Tensor,
    save_path: Optional[Path] = None,
    figsize: tuple = (15, 5)
):
    """
    Visualize try-on results in a 3-column layout.
    
    Args:
        person_image: Original person image [C, H, W] or [B, C, H, W]
        cloth_image: Clothing garment [C, H, W] or [B, C, H, W]
        result_image: Try-on result [C, H, W] or [B, C, H, W]
        save_path: Optional path to save the figure
        figsize: Figure size (width, height)
    """
    fig, axes = plt.subplots(1, 3, figsize=figsize)
    
    def prep_image(tensor):
        if tensor.ndim == 4:
            tensor = tensor[0]
        img = tensor.cpu().numpy().transpose(1, 2, 0)
        # Denormalize from [-1, 1] to [0, 1]
        img = (img + 1.0) / 2.0
        return np.clip(img, 0, 1)
    
    axes[0].imshow(prep_image(person_image))
    axes[0].set_title('Person')
    axes[0].axis('off')
    
    axes[1].imshow(prep_image(cloth_image))
    axes[1].set_title('Garment')
    axes[1].axis('off')
    
    axes[2].imshow(prep_image(result_image))
    axes[2].set_title('Try-On Result')
    axes[2].axis('off')
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
    
    return fig
