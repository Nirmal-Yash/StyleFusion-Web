"""
Label mapping utilities for semantic segmentation maps.
Critical functions: remap_labels (LIP-20 → UNIFIED-25) and binarize_agnostic_parse (MOD-8).
"""

import torch
import numpy as np
from typing import Dict


def remap_labels(
    parse_map: torch.Tensor,    # [H, W] int64, values [0, 19]
    mapping: Dict[int, int],    # LIP20_TO_UNIFIED25
    target_vocab_size: int = 25
) -> torch.Tensor:
    """
    Remap segmentation map from LIP-20 to UNIFIED-25 label space.
    
    Args:
        parse_map: Integer tensor [H, W] with LIP-20 class labels [0, 19]
        mapping: Dictionary mapping source class IDs to target class IDs
        target_vocab_size: Size of target vocabulary (25 for UNIFIED-25)
    
    Returns:
        Remapped tensor [H, W] int64 with values in [0, target_vocab_size)
    
    Guarantees:
      - Output dtype: torch.int64
      - Source class not in mapping → 0 (background)
      - All output values in [0, target_vocab_size)
      - Class 5 pixel count is IDENTICAL before and after mapping
        (enforced by DatasetValidator check #5)
    """
    max_src = max(mapping.keys()) + 1
    lut = torch.zeros(max_src, dtype=torch.int64, device=parse_map.device)
    
    for src, tgt in mapping.items():
        lut[src] = tgt
    
    # Clamp and remap
    remapped = lut[parse_map.clamp(0, max_src - 1)]
    
    # Validation
    assert remapped.max() < target_vocab_size, (
        f"Remapped value {remapped.max().item()} ≥ vocab_size={target_vocab_size}"
    )
    
    return remapped


def binarize_agnostic_parse(parse_array: np.ndarray) -> np.ndarray:
    """
    Convert LIP-20 agnostic parse map to binary garment-region mask.
    
    This is applied to MOD-8 (image-parse-agnostic-v3.2) which contains
    PALETTE PNG files in LIP-20 format, NOT binary masks.
    
    LIP-20 classes that constitute the try-on target region (upper body):
      5  = Upper-cloth
      10 = Torso-skin (exposed torso under garment, included for coverage)
    
    These classes define where the new garment will be placed.
    All other classes → 0 (background/preserve original).
    
    Args:
        parse_array: [H, W] int array, values in [0, 19] (LIP-20 classes)
    
    Returns:
        binary_mask: [H, W] float32 array, values in {0.0, 1.0}
    
    NOTE: Do NOT use class 7 (coat) or 6 (dress) — this is upper-cloth only.
    NOTE: Do NOT use class 14/15 (arms) — compositing handles arms separately.
    """
    binary = ((parse_array == 5) | (parse_array == 10)).astype(np.float32)
    return binary


def verify_class5_preservation(
    parse_lip20: np.ndarray,
    parse_unified25: torch.Tensor
) -> bool:
    """
    Verify that class-5 (Upper-cloth) pixel count is preserved after remapping.
    This is a critical validation check (DatasetValidator check #5).
    
    Args:
        parse_lip20: Original LIP-20 parse map [H, W] int
        parse_unified25: Remapped UNIFIED-25 parse map [H, W] int64 tensor
    
    Returns:
        True if pixel counts match exactly, False otherwise
    """
    raw5_count = (parse_lip20 == 5).sum()
    map5_count = (parse_unified25 == 5).sum().item()
    return raw5_count == map5_count
