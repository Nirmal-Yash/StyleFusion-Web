"""
Virtual Try-On Training Entry Point

Main script to train the Virtual Try-On system.

Usage:
    python train.py
    
    # With config overrides
    python train.py training.num_gpus=4 training.batch_size=8
    
    # Resume from checkpoint
    python train.py checkpoint_path=checkpoints/last.ckpt

Configuration:
    Uses configs/default.yaml
    Override with command-line arguments using Hydra syntax
    
Training Phases:
    1. Epochs 0-1: Warp warm-up
       - Only warping_module, conv_in[9:16], and compositor trainable
       - High warp loss weights, low diffusion weight
    
    2. Epochs 2+: Full training
       - All modules trainable
       - Joint optimization with balanced loss weights

Output:
    - Checkpoints: checkpoints/
    - Logs: logs/
    - Best model: checkpoints/best-*.ckpt
"""

import os
import sys
import torch
import pytorch_lightning as pl
from omegaconf import DictConfig, OmegaConf
import hydra
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from data import VITONDataModule, DatasetValidator
from training import VirtualTryOnLightningModule, setup_trainer


@hydra.main(version_base=None, config_path="configs", config_name="default")
def main(cfg: DictConfig):
    """
    Main training function.
    
    Args:
        cfg: Hydra configuration from configs/default.yaml
    """
    print("=" * 80)
    print("Virtual Try-On Training")
    print("=" * 80)
    
    # Print configuration
    print("\nConfiguration:")
    print(OmegaConf.to_yaml(cfg))
    print("=" * 80)
    
    # Set random seed for reproducibility
    seed = cfg.get('project', {}).get('seed', cfg.training.get('seed', None))
    if seed is not None:
        pl.seed_everything(seed, workers=True)
        print(f"✓ Random seed set to {seed}")
    
    # STEP 1: Validate dataset
    print("\n" + "=" * 80)
    print("STEP 1: Validating Dataset")
    print("=" * 80)
    
    validator = DatasetValidator(cfg)
    validation_results = validator.validate()
    
    if not validation_results['success']:
        print("\n❌ Dataset validation FAILED!")
        print("\nErrors found:")
        for error in validation_results['errors']:
            print(f"  - {error}")
        sys.exit(1)
    
    print(f"\n✅ Dataset validation passed!")
    print(f"   Train samples: {validation_results['train_count']}")
    print(f"   Val samples: {validation_results['val_count']}")
    
    # STEP 2: Initialize DataModule
    print("\n" + "=" * 80)
    print("STEP 2: Initializing DataModule")
    print("=" * 80)
    
    datamodule = VITONDataModule(cfg)
    datamodule.setup('fit')
    
    print(f"✓ DataModule initialized")
    print(f"   Train batches per epoch: {len(datamodule.train_dataloader())}")
    print(f"   Val batches: {len(datamodule.val_dataloader())}")
    print(f"   Batch size: {cfg.data.batch_size}")
    print(f"   Num workers: {cfg.data.num_workers}")
    
    # STEP 3: Initialize LightningModule
    print("\n" + "=" * 80)
    print("STEP 3: Initializing Model")
    print("=" * 80)
    
    # Check for checkpoint to resume from
    checkpoint_path = cfg.get('checkpoint_path', None)
    
    if checkpoint_path and os.path.exists(checkpoint_path):
        print(f"✓ Resuming from checkpoint: {checkpoint_path}")
        lightning_module = VirtualTryOnLightningModule.load_from_checkpoint(
            checkpoint_path,
            cfg=cfg,
        )
    else:
        print("✓ Initializing new model")
        lightning_module = VirtualTryOnLightningModule(cfg)
    
    # Print model summary
    total_params = sum(p.numel() for p in lightning_module.parameters())
    trainable_params = sum(p.numel() for p in lightning_module.parameters() if p.requires_grad)
    
    print(f"\nModel Summary:")
    print(f"   Total parameters: {total_params:,}")
    print(f"   Trainable parameters: {trainable_params:,}")
    print(f"   Non-trainable: {total_params - trainable_params:,}")
    
    # STEP 4: Setup Trainer
    print("\n" + "=" * 80)
    print("STEP 4: Setting up Trainer")
    print("=" * 80)
    
    trainer = setup_trainer(cfg)
    
    # STEP 5: Train!
    print("\n" + "=" * 80)
    print("STEP 5: Starting Training")
    print("=" * 80)
    
    print("\n🚀 Training starting...")
    print(f"   Max epochs: {cfg.training.max_epochs}")
    print(f"   Warm-up epochs: {cfg.training.get('warmup_epochs', 2)}")
    print(f"   Precision: {cfg.training.get('precision', 'bf16-mixed')}")
    print(f"   GPUs: {cfg.training.get('num_gpus', 1)}")
    print()
    
    trainer.fit(
        model=lightning_module,
        datamodule=datamodule,
        ckpt_path=checkpoint_path if checkpoint_path and os.path.exists(checkpoint_path) else None,
    )
    
    # Training complete
    print("\n" + "=" * 80)
    print("✅ Training Complete!")
    print("=" * 80)
    
    # Print best checkpoint path
    if hasattr(trainer, 'checkpoint_callback') and trainer.checkpoint_callback is not None:
        best_path = trainer.checkpoint_callback.best_model_path
        if best_path:
            print(f"\n🏆 Best model checkpoint: {best_path}")
    
    print("\n📊 Logs saved to:", cfg.logging.get('log_dir', 'logs'))
    print("💾 Checkpoints saved to:", cfg.get('checkpoint_dir', 'checkpoints'))
    
    return trainer


if __name__ == '__main__':
    # Run training
    main()
