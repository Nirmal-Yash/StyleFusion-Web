"""
Part-Aware Garment Warping Module

This module implements part-based geometric warping of garments to match body pose:

1. PartSegmenter: Segments body into 5 parts (head, torso, left/right arms, legs)
2. LocalCorrelationVolume: Computes part-local feature correlation (BF16 for memory)
3. WarpFlowPredictor: Predicts dense deformation field from correlation
4. TPS Warping: Applies differentiable thin-plate spline transformation
5. Soft Blending: Combines multiple part-specific warps with learned weights

Architecture Flow:
  body_feat [B,256,128,96] + cloth_feat [B,3,1024,768]
    → Part Segmentation (5 masks)
    → Local Correlation (D=8 displacement)
    → Flow Prediction (dense deformation field)
    → TPS Control Points (5×5 grid per part)
    → Warp Application (bilinear sampling)
    → Soft Blending (part-weighted fusion)
    → cloth_warped [B,3,1024,768], cloth_mask_warped [B,1,1024,768]

Key Features:
- Part-aware warping prevents cross-body distortion
- BF16 correlation for memory efficiency
- TPS provides smooth, realistic deformations
- Identity initialization for warm-up training
- Outputs full-resolution warped cloth + mask
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple, List, Optional

from .tps import DifferentiableTPS


class PartSegmenter(nn.Module):
    """
    Segments body features into 5 semantic parts for part-aware warping.
    
    Input: body_feat [B, 256, 128, 96] from BodyConditionEncoder
    Output: part_masks [B, 5, 128, 96] soft masks (sum to 1.0 across parts)
    
    Parts:
        0: Head (neck + head)
        1: Torso (upper body excluding arms)
        2: Left Arm
        3: Right Arm
        4: Legs (lower body)
    
    Uses lightweight CNN to predict part probabilities from body features.
    """
    
    def __init__(self, in_channels: int = 256, num_parts: int = 5):
        super().__init__()
        
        self.num_parts = num_parts
        
        # Lightweight segmentation head
        self.seg_head = nn.Sequential(
            nn.Conv2d(in_channels, 128, kernel_size=3, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            nn.Conv2d(64, num_parts, kernel_size=1),
        )
    
    def forward(self, body_feat: torch.Tensor) -> torch.Tensor:
        """
        Args:
            body_feat: [B, 256, 128, 96] encoded body features
        
        Returns:
            part_masks: [B, 5, 128, 96] soft part masks (softmax across parts)
        """
        B, C, H, W = body_feat.shape
        assert C == 256 and H == 128 and W == 96, \
            f"Expected [B,256,128,96], got {body_feat.shape}"
        
        # Predict part logits
        part_logits = self.seg_head(body_feat)  # [B, 5, 128, 96]
        
        # Softmax across parts (each pixel belongs to exactly one part)
        part_masks = F.softmax(part_logits, dim=1)  # [B, 5, 128, 96]
        
        assert part_masks.shape == (B, self.num_parts, H, W), \
            f"Expected [B,{self.num_parts},128,96], got {part_masks.shape}"
        
        return part_masks


class LocalCorrelationVolume(nn.Module):
    """
    Computes local correlation between body and garment features.
    
    For each body pixel, correlates with garment pixels in a D×D window.
    Uses BF16 precision to reduce memory footprint (correlation is memory-intensive).
    
    Input:
        - body_feat: [B, C, H, W] body features
        - cloth_feat: [B, C, H, W] garment features (same resolution)
    
    Output:
        - corr_volume: [B, D*D, H, W] correlation volume
    
    D=8 means each pixel looks at 8×8 = 64 displacement candidates.
    """
    
    def __init__(self, displacement: int = 8):
        super().__init__()
        self.D = displacement
    
    def forward(
        self,
        body_feat: torch.Tensor,
        cloth_feat: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            body_feat: [B, C, H, W] body features
            cloth_feat: [B, C, H, W] cloth features (same resolution)
        
        Returns:
            corr_volume: [B, D*D, H, W] local correlation
        """
        B, C, H, W = body_feat.shape
        assert cloth_feat.shape == body_feat.shape, \
            f"Feature shapes must match: {body_feat.shape} vs {cloth_feat.shape}"
        
        D = self.D
        
        # Use BF16 for memory efficiency
        body_feat_bf16 = body_feat.to(torch.bfloat16)
        cloth_feat_bf16 = cloth_feat.to(torch.bfloat16)
        
        # Normalize features
        body_feat_bf16 = F.normalize(body_feat_bf16, dim=1, p=2)
        cloth_feat_bf16 = F.normalize(cloth_feat_bf16, dim=1, p=2)
        
        # Compute correlation for each displacement
        corr_list = []
        
        for dy in range(-D // 2, D // 2):
            for dx in range(-D // 2, D // 2):
                # Shift cloth features by (dy, dx)
                cloth_shifted = self._shift_features(cloth_feat_bf16, dy, dx)
                
                # Compute correlation via dot product
                corr = (body_feat_bf16 * cloth_shifted).sum(dim=1, keepdim=True)  # [B, 1, H, W]
                corr_list.append(corr)
        
        # Stack all displacements
        corr_volume = torch.cat(corr_list, dim=1)  # [B, D*D, H, W]
        
        # Convert back to original dtype
        corr_volume = corr_volume.to(body_feat.dtype)
        
        assert corr_volume.shape == (B, D * D, H, W), \
            f"Expected [B,{D*D},{H},{W}], got {corr_volume.shape}"
        
        return corr_volume
    
    def _shift_features(self, feat: torch.Tensor, dy: int, dx: int) -> torch.Tensor:
        """
        Shift features by (dy, dx) with zero padding.
        
        Args:
            feat: [B, C, H, W]
            dy, dx: vertical and horizontal shift
        
        Returns:
            shifted: [B, C, H, W]
        """
        B, C, H, W = feat.shape
        
        if dy == 0 and dx == 0:
            return feat
        
        # Pad and crop to shift
        pad_top = max(0, dy)
        pad_bottom = max(0, -dy)
        pad_left = max(0, dx)
        pad_right = max(0, -dx)
        
        feat_padded = F.pad(feat, (pad_left, pad_right, pad_top, pad_bottom), mode='constant', value=0)
        
        # Crop to original size
        y_start = abs(min(0, dy))
        x_start = abs(min(0, dx))
        shifted = feat_padded[:, :, y_start:y_start + H, x_start:x_start + W]
        
        return shifted


class WarpFlowPredictor(nn.Module):
    """
    Predicts dense deformation field from correlation volume and body features.
    
    Input:
        - corr_volume: [B, D*D, H, W] correlation volume
        - body_feat: [B, 256, H, W] body features
        - part_masks: [B, 5, H, W] part segmentation
    
    Output:
        - flow_field: [B, 2, H, W] dense deformation (dy, dx) in pixel units
    
    Uses correlation + body features to predict how each pixel should move.
    """
    
    def __init__(self, corr_channels: int = 64, body_channels: int = 256, num_parts: int = 5):
        super().__init__()
        
        # Total input: corr (64) + body (256) + parts (5) = 325 channels
        total_in = corr_channels + body_channels + num_parts
        
        # Flow prediction network
        self.flow_net = nn.Sequential(
            nn.Conv2d(total_in, 256, kernel_size=3, padding=1),
            nn.GroupNorm(32, 256),
            nn.GELU(),
            
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            
            nn.Conv2d(64, 2, kernel_size=3, padding=1),  # Output: (dy, dx)
        )
    
    def forward(
        self,
        corr_volume: torch.Tensor,
        body_feat: torch.Tensor,
        part_masks: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            corr_volume: [B, D*D, H, W] correlation volume
            body_feat: [B, 256, H, W] body features
            part_masks: [B, 5, H, W] part masks
        
        Returns:
            flow_field: [B, 2, H, W] deformation field (dy, dx) in pixels
        """
        B = corr_volume.shape[0]
        
        # Concatenate all inputs
        concat_feat = torch.cat([corr_volume, body_feat, part_masks], dim=1)
        
        # Predict flow
        flow_field = self.flow_net(concat_feat)  # [B, 2, H, W]
        
        assert flow_field.shape == (B, 2, 128, 96), \
            f"Expected [B,2,128,96], got {flow_field.shape}"
        
        return flow_field


class TPSWarper(nn.Module):
    """
    Applies Thin-Plate Spline warping using learnable control points.
    
    Converts dense flow field to sparse TPS control points, then applies
    differentiable TPS transformation.
    
    Input:
        - cloth_image: [B, 3, 1024, 768] RGB garment
        - cloth_mask: [B, 1, 1024, 768] binary mask
        - flow_field: [B, 2, 128, 96] dense deformation
        - part_masks_full: [B, 5, 1024, 768] upsampled part masks
    
    Output:
        - cloth_warped: [B, 3, 1024, 768] warped cloth
        - cloth_mask_warped: [B, 1, 1024, 768] warped mask
        - ctrl_pts_src: [B, 25, 2] source control points
        - ctrl_pts_tgt: [B, 25, 2] target control points
    
    Uses 5×5 regular grid of control points (25 total).
    """
    
    def __init__(self, num_ctrl_pts: int = 5):
        super().__init__()
        
        self.num_ctrl_pts = num_ctrl_pts
        self.n_cp = num_ctrl_pts * num_ctrl_pts  # 5x5 = 25 control points
        self.tps = DifferentiableTPS(n_cp=self.n_cp)
        
        # Learnable offset predictor (converts flow to ctrl point offsets)
        # Adaptive pooling to reduce flow to num_ctrl_pts × num_ctrl_pts grid
        self.flow_to_ctrl = nn.Sequential(
            nn.AdaptiveAvgPool2d((num_ctrl_pts, num_ctrl_pts)),  # [B, 2, 5, 5]
            nn.Flatten(start_dim=1),  # [B, 50]
            nn.Linear(num_ctrl_pts * num_ctrl_pts * 2, self.n_cp * 2),
            nn.Tanh(),  # Bound offsets to [-1, 1]
        )
    
    def forward(
        self,
        cloth_image: torch.Tensor,
        cloth_mask: torch.Tensor,
        flow_field: torch.Tensor,
        part_masks_full: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            cloth_image: [B, 3, 1024, 768]
            cloth_mask: [B, 1, 1024, 768]
            flow_field: [B, 2, 128, 96] deformation field
            part_masks_full: [B, 5, 1024, 768] part masks (for visualization)
        
        Returns:
            cloth_warped: [B, 3, 1024, 768]
            cloth_mask_warped: [B, 1, 1024, 768]
            ctrl_pts_src: [B, 25, 2]
            ctrl_pts_tgt: [B, 25, 2]
        """
        B = cloth_image.shape[0]
        
        # Get source control points (identity grid from TPS)
        ctrl_pts_src = self.tps.identity_ctrl_pts.unsqueeze(0).expand(B, -1, -1)  # [B, 25, 2]
        
        # Predict control point offsets from flow field
        ctrl_offsets = self.flow_to_ctrl(flow_field)  # [B, 50]
        ctrl_offsets = ctrl_offsets.view(B, self.n_cp, 2)  # [B, 25, 2]
        
        # Scale offsets (during warm-up, offsets start near zero)
        ctrl_offsets = ctrl_offsets * 0.2  # Limit max displacement
        
        # Compute target control points
        ctrl_pts_tgt = ctrl_pts_src + ctrl_offsets  # [B, 25, 2]
        
        # Apply TPS transformation
        warp_grid = self.tps(ctrl_pts_src, ctrl_pts_tgt, output_size=(1024, 768))  # [B, H, W, 2] in [-1, 1]
        
        # Warp cloth image and mask
        cloth_warped = F.grid_sample(
            cloth_image,
            warp_grid,
            mode='bilinear',
            padding_mode='zeros',
            align_corners=False,
        )
        
        cloth_mask_warped = F.grid_sample(
            cloth_mask,
            warp_grid,
            mode='bilinear',
            padding_mode='zeros',
            align_corners=False,
        )
        
        assert cloth_warped.shape == (B, 3, 1024, 768)
        assert cloth_mask_warped.shape == (B, 1, 1024, 768)
        assert ctrl_pts_src.shape == (B, 25, 2)
        assert ctrl_pts_tgt.shape == (B, 25, 2)
        
        return cloth_warped, cloth_mask_warped, ctrl_pts_src, ctrl_pts_tgt


class GarmentWarpingModule(nn.Module):
    """
    Complete part-aware garment warping system.
    
    Inputs:
        - body_feat: [B, 256, 128, 96] from BodyConditionEncoder
        - cloth_image: [B, 3, 1024, 768] garment RGB
        - cloth_mask: [B, 1, 1024, 768] garment mask
    
    Outputs (dict):
        - 'cloth_warped': [B, 3, 1024, 768] warped garment
        - 'cloth_mask_warped': [B, 1, 1024, 768] warped mask
        - 'deformation_field': [B, 2, 128, 96] dense flow
        - 'part_masks_full': [B, 5, 1024, 768] upsampled part masks
        - 'ctrl_pts_src': [B, 25, 2] source control points
        - 'ctrl_pts_tgt': [B, 25, 2] target control points
    
    Pipeline:
        1. Segment body into 5 parts
        2. Downsample cloth to match body_feat resolution
        3. Compute local correlation between body and cloth
        4. Predict dense deformation field
        5. Convert to TPS control points and warp
        6. Return warped cloth + intermediate outputs
    """
    
    def __init__(
        self,
        body_channels: int = 256,
        cloth_channels: int = 3,
        num_parts: int = 5,
        correlation_displacement: int = 8,
        num_ctrl_pts: int = 5,
    ):
        super().__init__()
        
        self.body_channels = body_channels
        self.num_parts = num_parts
        
        # Part segmentation
        self.part_segmenter = PartSegmenter(
            in_channels=body_channels,
            num_parts=num_parts,
        )
        
        # Downsample cloth to match body_feat resolution (128×96)
        self.cloth_downsample = nn.Sequential(
            # 1024x768 -> 512x384
            nn.Conv2d(cloth_channels, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            
            # 512x384 -> 256x192
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            
            # 256x192 -> 128x96
            nn.Conv2d(128, body_channels, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(32, body_channels),
            nn.GELU(),
        )
        
        # Local correlation
        self.correlation = LocalCorrelationVolume(displacement=correlation_displacement)
        
        # Flow prediction
        self.flow_predictor = WarpFlowPredictor(
            corr_channels=correlation_displacement * correlation_displacement,
            body_channels=body_channels,
            num_parts=num_parts,
        )
        
        # TPS warping
        self.tps_warper = TPSWarper(num_ctrl_pts=num_ctrl_pts)
    
    def forward(
        self,
        body_feat: torch.Tensor,
        cloth_image: torch.Tensor,
        cloth_mask: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """
        Warp garment to match body pose.
        
        Args:
            body_feat: [B, 256, 128, 96] encoded body features
            cloth_image: [B, 3, 1024, 768] garment RGB
            cloth_mask: [B, 1, 1024, 768] garment mask
        
        Returns:
            output_dict with keys:
                - cloth_warped: [B, 3, 1024, 768]
                - cloth_mask_warped: [B, 1, 1024, 768]
                - deformation_field: [B, 2, 128, 96]
                - part_masks_full: [B, 5, 1024, 768]
                - ctrl_pts_src: [B, 25, 2]
                - ctrl_pts_tgt: [B, 25, 2]
        """
        B = body_feat.shape[0]
        assert body_feat.shape == (B, 256, 128, 96)
        assert cloth_image.shape == (B, 3, 1024, 768)
        assert cloth_mask.shape == (B, 1, 1024, 768)
        
        # 1. Segment body into parts
        part_masks = self.part_segmenter(body_feat)  # [B, 5, 128, 96]
        
        # 2. Downsample cloth to match body_feat resolution
        cloth_feat = self.cloth_downsample(cloth_image)  # [B, 256, 128, 96]
        
        # 3. Compute local correlation
        corr_volume = self.correlation(body_feat, cloth_feat)  # [B, 64, 128, 96]
        
        # 4. Predict dense deformation field
        deformation_field = self.flow_predictor(
            corr_volume,
            body_feat,
            part_masks,
        )  # [B, 2, 128, 96]
        
        # 5. Upsample part masks to full resolution for TPS
        part_masks_full = F.interpolate(
            part_masks,
            size=(1024, 768),
            mode='bilinear',
            align_corners=False,
        )  # [B, 5, 1024, 768]
        
        # 6. Apply TPS warping
        cloth_warped, cloth_mask_warped, ctrl_pts_src, ctrl_pts_tgt = self.tps_warper(
            cloth_image,
            cloth_mask,
            deformation_field,
            part_masks_full,
        )
        
        # Assemble output dictionary
        output = {
            'cloth_warped': cloth_warped,              # [B, 3, 1024, 768]
            'cloth_mask_warped': cloth_mask_warped,    # [B, 1, 1024, 768]
            'deformation_field': deformation_field,    # [B, 2, 128, 96]
            'part_masks_full': part_masks_full,        # [B, 5, 1024, 768]
            'ctrl_pts_src': ctrl_pts_src,              # [B, 25, 2]
            'ctrl_pts_tgt': ctrl_pts_tgt,              # [B, 25, 2]
        }
        
        return output


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_warping_module():
    """Test GarmentWarpingModule with synthetic inputs."""
    print("Testing GarmentWarpingModule...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create model
    model = GarmentWarpingModule(
        body_channels=256,
        cloth_channels=3,
        num_parts=5,
        correlation_displacement=8,
        num_ctrl_pts=5,
    ).to(device)
    
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
    
    # Create synthetic inputs
    body_feat = torch.randn(B, 256, 128, 96).to(device)
    cloth_image = torch.randn(B, 3, 1024, 768).to(device)
    cloth_mask = torch.rand(B, 1, 1024, 768).to(device)
    cloth_mask = (cloth_mask > 0.5).float()
    
    # Forward pass
    with torch.no_grad():
        output = model(body_feat, cloth_image, cloth_mask)
    
    print("\nOutput shapes:")
    for key, val in output.items():
        print(f"  {key}: {val.shape}")
    
    # Verify shapes
    assert output['cloth_warped'].shape == (B, 3, 1024, 768)
    assert output['cloth_mask_warped'].shape == (B, 1, 1024, 768)
    assert output['deformation_field'].shape == (B, 2, 128, 96)
    assert output['part_masks_full'].shape == (B, 5, 1024, 768)
    assert output['ctrl_pts_src'].shape == (B, 25, 2)
    assert output['ctrl_pts_tgt'].shape == (B, 25, 2)
    
    print("\n✓ All output shapes correct!")
    
    # Test individual components
    print("\nTesting individual components...")
    
    # Part segmenter
    part_seg = PartSegmenter().to(device)
    with torch.no_grad():
        part_masks = part_seg(body_feat)
    assert part_masks.shape == (B, 5, 128, 96)
    print(f"✓ Part segmentation: {part_masks.shape}")
    
    # Correlation
    corr = LocalCorrelationVolume(displacement=8).to(device)
    with torch.no_grad():
        cloth_feat = torch.randn(B, 256, 128, 96).to(device)
        corr_vol = corr(body_feat, cloth_feat)
    assert corr_vol.shape == (B, 64, 128, 96)
    print(f"✓ Correlation volume: {corr_vol.shape}")
    
    # Flow predictor
    flow_pred = WarpFlowPredictor().to(device)
    with torch.no_grad():
        flow = flow_pred(corr_vol, body_feat, part_masks)
    assert flow.shape == (B, 2, 128, 96)
    print(f"✓ Flow prediction: {flow.shape}")
    
    print("\n✅ All tests passed!")


if __name__ == '__main__':
    test_warping_module()
