"""
IP-Adapter for Garment Identity Conditioning

This module implements IP-Adapter (Image Prompt Adapter) for injecting garment
identity information into the diffusion UNet via cross-attention.

Architecture:
1. Frozen CLIP-ViT-L-14 vision encoder
2. Image projection MLP (257 tokens → 16 tokens)
3. Learnable ip_scale parameter (controls adapter strength)
4. Custom attention processor for cross-attention injection

CRITICAL: Uses `cloth_image_raw` (unaugmented) for CLIP encoding.
The GarmentExtractor uses `cloth_image` (augmented) for texture/shape.

Key Features:
- CLIP vision encoder frozen (no gradients)
- Projection MLP learns to map CLIP features to UNet's cross-attention space
- ip_scale initialized to 0.1, clamped to [0, 3.0] during training
- Outputs key/value pairs + scale for injection into UNet attention layers

Reference: IP-Adapter (Ye et al., 2023)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple, Optional
from transformers import CLIPVisionModelWithProjection, CLIPImageProcessor


class ImageProjectionMLP(nn.Module):
    """
    Projects CLIP image features to UNet cross-attention space.
    
    Input: clip_features [B, 257, 1024] (CLS + 256 patch tokens from ViT-L-14)
    Output: ip_tokens [B, 16, 768] (compressed to 16 tokens, 768-dim for SD 1.5)
    
    Uses cross-attention to compress 257 tokens → 16 learnable query tokens.
    """
    
    def __init__(
        self,
        clip_feat_dim: int = 1024,  # CLIP-ViT-L-14 output dim
        cross_attn_dim: int = 768,  # SD 1.5 cross-attention dim
        num_output_tokens: int = 16,
    ):
        super().__init__()
        
        self.num_output_tokens = num_output_tokens
        
        # Learnable query tokens
        self.query_tokens = nn.Parameter(
            torch.randn(1, num_output_tokens, cross_attn_dim) * 0.02
        )
        
        # Cross-attention to compress CLIP features
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=cross_attn_dim,
            num_heads=8,
            batch_first=True,
        )
        
        # Layer norm
        self.ln_pre = nn.LayerNorm(cross_attn_dim)
        self.ln_post = nn.LayerNorm(cross_attn_dim)
        
        # Input projection (CLIP features → cross_attn_dim)
        self.input_proj = nn.Linear(clip_feat_dim, cross_attn_dim)
        
        # MLP refinement
        self.mlp = nn.Sequential(
            nn.Linear(cross_attn_dim, cross_attn_dim * 4),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(cross_attn_dim * 4, cross_attn_dim),
        )
    
    def forward(self, clip_features: torch.Tensor) -> torch.Tensor:
        """
        Args:
            clip_features: [B, 257, 1024] CLIP image features
        
        Returns:
            ip_tokens: [B, 16, 768] projected tokens for cross-attention
        """
        B, N, C = clip_features.shape
        assert N == 257 and C == 1024, \
            f"Expected [B,257,1024], got {clip_features.shape}"
        
        # Project CLIP features to cross-attention space
        clip_proj = self.input_proj(clip_features)  # [B, 257, 768]
        
        # Expand learnable queries for batch
        queries = self.query_tokens.expand(B, -1, -1)  # [B, 16, 768]
        queries = self.ln_pre(queries)
        
        # Cross-attention: queries attend to CLIP features
        attn_out, _ = self.cross_attn(
            query=queries,
            key=clip_proj,
            value=clip_proj,
        )  # [B, 16, 768]
        
        # Residual connection + layer norm
        queries = queries + attn_out
        queries = self.ln_post(queries)
        
        # MLP refinement
        ip_tokens = queries + self.mlp(queries)  # [B, 16, 768]
        
        assert ip_tokens.shape == (B, self.num_output_tokens, 768), \
            f"Expected [B,{self.num_output_tokens},768], got {ip_tokens.shape}"
        
        return ip_tokens


class IPAdapterAttnProcessor(nn.Module):
    """
    Custom attention processor for IP-Adapter injection.
    
    This replaces the default attention processor in UNet cross-attention layers.
    Computes both text cross-attention and image cross-attention, then combines.
    
    Args:
        hidden_size: UNet hidden dimension (varies by layer)
        cross_attention_dim: Text encoder output dim (768 for SD 1.5)
        ip_scale: Scaling factor for image cross-attention (0.0 = text only)
    
    Forward inputs:
        - hidden_states: [B, N, hidden_size] spatial features
        - encoder_hidden_states: [B, 77, 768] text prompt embeddings (optional)
        - ip_hidden_states: [B, 16, 768] image prompt tokens (optional)
        - ip_scale: float, current IP-Adapter strength
    
    Output:
        - attn_output: [B, N, hidden_size] attended features
    
    Computation:
        attn_output = text_attn + ip_scale * image_attn
    """
    
    def __init__(
        self,
        hidden_size: int,
        cross_attention_dim: int = 768,
    ):
        super().__init__()
        
        self.hidden_size = hidden_size
        self.cross_attention_dim = cross_attention_dim
        
        # Query projection (from spatial features)
        self.to_q = nn.Linear(hidden_size, hidden_size, bias=False)
        
        # Key/value projections for text cross-attention
        self.to_k_text = nn.Linear(cross_attention_dim, hidden_size, bias=False)
        self.to_v_text = nn.Linear(cross_attention_dim, hidden_size, bias=False)
        
        # Key/value projections for image cross-attention (IP-Adapter)
        self.to_k_ip = nn.Linear(cross_attention_dim, hidden_size, bias=False)
        self.to_v_ip = nn.Linear(cross_attention_dim, hidden_size, bias=False)
        
        # Output projection
        self.to_out = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.Dropout(0.0),  # No dropout in attention output
        )
        
        self.num_heads = 8
        self.head_dim = hidden_size // self.num_heads
        assert hidden_size % self.num_heads == 0
    
    def forward(
        self,
        hidden_states: torch.Tensor,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> torch.Tensor:
        """
        Args:
            hidden_states: [B, N, hidden_size] spatial features
            encoder_hidden_states: [B, 77, 768] text embeddings (optional)
            **kwargs: additional args from diffusers Attention module
        
        IP-Adapter keys/values are read from temporary attributes set by
        DiffusionUNet.forward() before the UNet call:
            self._ip_keys:   [B, 16, 768]
            self._ip_values: [B, 16, 768]
            self._ip_scale:  float
        
        Returns:
            attn_output: [B, N, hidden_size]
        """
        B, N, C = hidden_states.shape
        
        # Compute queries from spatial features
        Q = self.to_q(hidden_states)  # [B, N, hidden_size]
        Q = Q.view(B, N, self.num_heads, self.head_dim).transpose(1, 2)  # [B, heads, N, head_dim]
        
        attn_output = 0.0
        
        # Text cross-attention
        if encoder_hidden_states is not None:
            K_text = self.to_k_text(encoder_hidden_states)  # [B, 77, hidden_size]
            V_text = self.to_v_text(encoder_hidden_states)
            
            K_text = K_text.view(B, -1, self.num_heads, self.head_dim).transpose(1, 2)
            V_text = V_text.view(B, -1, self.num_heads, self.head_dim).transpose(1, 2)
            
            # Scaled dot-product attention
            scores_text = torch.matmul(Q, K_text.transpose(-2, -1)) / (self.head_dim ** 0.5)
            attn_weights_text = F.softmax(scores_text, dim=-1)
            attn_text = torch.matmul(attn_weights_text, V_text)  # [B, heads, N, head_dim]
            
            # Reshape and add to output
            attn_text = attn_text.transpose(1, 2).reshape(B, N, C)
            attn_output = attn_output + attn_text
        
        # Image cross-attention (IP-Adapter)
        # Read from temporary attributes set by DiffusionUNet.forward()
        ip_keys = getattr(self, '_ip_keys', None)
        ip_values = getattr(self, '_ip_values', None)
        ip_scale = getattr(self, '_ip_scale', 1.0)
        
        if ip_keys is not None and ip_values is not None and ip_scale > 0.0:
            K_ip = self.to_k_ip(ip_keys)    # [B, 16, hidden_size]
            V_ip = self.to_v_ip(ip_values)   # [B, 16, hidden_size]
            
            K_ip = K_ip.view(B, -1, self.num_heads, self.head_dim).transpose(1, 2)
            V_ip = V_ip.view(B, -1, self.num_heads, self.head_dim).transpose(1, 2)
            
            # Scaled dot-product attention
            scores_ip = torch.matmul(Q, K_ip.transpose(-2, -1)) / (self.head_dim ** 0.5)
            attn_weights_ip = F.softmax(scores_ip, dim=-1)
            attn_ip = torch.matmul(attn_weights_ip, V_ip)  # [B, heads, N, head_dim]
            
            # Reshape and add to output with scaling
            attn_ip = attn_ip.transpose(1, 2).reshape(B, N, C)
            attn_output = attn_output + ip_scale * attn_ip
        
        # Output projection
        attn_output = self.to_out(attn_output)
        
        return attn_output


class IPAdapter(nn.Module):
    """
    Complete IP-Adapter module for garment identity conditioning.
    
    Inputs:
        - cloth_image_raw: [B, 3, 1024, 768] RGB garment (UNAUGMENTED)
    
    Outputs:
        - ip_keys: [B, 16, 768] image prompt keys
        - ip_values: [B, 16, 768] image prompt values  
        - ip_scale: float, current adapter strength
    
    Usage in UNet:
        1. Encode cloth_image_raw with frozen CLIP
        2. Project to 16 tokens via MLP
        3. Inject into UNet cross-attention layers via custom processor
        4. Combine with text cross-attention weighted by ip_scale
    
    CRITICAL: Must use `cloth_image_raw` (unaugmented) for stable CLIP encoding.
    Data augmentation is applied to `cloth_image` for GarmentExtractor only.
    """
    
    def __init__(
        self,
        clip_model_name: str = "openai/clip-vit-large-patch14",
        cross_attention_dim: int = 768,
        num_output_tokens: int = 16,
        init_ip_scale: float = 0.1,
        max_ip_scale: float = 3.0,
    ):
        super().__init__()
        
        self.max_ip_scale = max_ip_scale
        
        # Frozen CLIP vision encoder
        self.clip_vision = CLIPVisionModelWithProjection.from_pretrained(clip_model_name)
        for param in self.clip_vision.parameters():
            param.requires_grad = False
        self.clip_vision.eval()
        
        # CLIP image processor (handles normalization)
        self.clip_processor = CLIPImageProcessor.from_pretrained(clip_model_name)
        
        # Projection MLP
        self.image_projection = ImageProjectionMLP(
            clip_feat_dim=1024,  # CLIP-ViT-L-14
            cross_attn_dim=cross_attention_dim,
            num_output_tokens=num_output_tokens,
        )
        
        # Learnable IP scale (controls adapter strength)
        self.ip_scale = nn.Parameter(torch.tensor(init_ip_scale))
    
    def get_ip_scale(self) -> float:
        """Get current IP scale, clamped to [0, max_ip_scale]."""
        return torch.clamp(self.ip_scale, 0.0, self.max_ip_scale).item()
    
    @torch.no_grad()
    def encode_image_clip(self, cloth_image_raw: torch.Tensor) -> torch.Tensor:
        """
        Encode image with frozen CLIP vision encoder.
        
        Args:
            cloth_image_raw: [B, 3, 1024, 768] RGB in [-1, 1] (normalized with mean=0.5,std=0.5)
        
        Returns:
            clip_features: [B, 257, 1024] CLIP image features
        """
        B, C, H, W = cloth_image_raw.shape
        assert C == 3 and H == 1024 and W == 768
        
        # Convert from [-1, 1] to [0, 1] first
        cloth_01 = (cloth_image_raw + 1.0) / 2.0
        cloth_01 = cloth_01.clamp(0.0, 1.0)
        
        # Resize to CLIP input size (224x224) with bicubic + antialias per spec
        cloth_resized = F.interpolate(
            cloth_01,
            size=(224, 224),
            mode='bicubic',
            align_corners=False,
            antialias=True,
        )
        cloth_resized = cloth_resized.clamp(0.0, 1.0)
        
        # Normalize with CLIP's mean/std
        mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).view(1, 3, 1, 1).to(cloth_resized.device)
        std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).view(1, 3, 1, 1).to(cloth_resized.device)
        
        cloth_norm = (cloth_resized - mean) / std
        
        # Encode with CLIP
        outputs = self.clip_vision.vision_model(pixel_values=cloth_norm)
        clip_features = outputs.last_hidden_state  # [B, 257, 1024]
        
        return clip_features
    
    def forward(self, cloth_image_raw: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, float]:
        """
        Compute IP-Adapter features for garment identity conditioning.
        
        Args:
            cloth_image_raw: [B, 3, 1024, 768] unaugmented RGB garment
        
        Returns:
            ip_tokens: [B, 16, 768] image prompt tokens
            ip_tokens: [B, 16, 768] (keys and values are same)
            ip_scale: float, current adapter strength
        """
        # Encode with frozen CLIP
        clip_features = self.encode_image_clip(cloth_image_raw)  # [B, 257, 1024]
        
        # Project to IP tokens
        ip_tokens = self.image_projection(clip_features)  # [B, 16, 768]
        
        # Get current IP scale (clamped)
        ip_scale = self.get_ip_scale()
        
        # Return tokens twice (used as both keys and values in attention)
        return ip_tokens, ip_tokens, ip_scale


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_ip_adapter():
    """Test IPAdapter with synthetic inputs."""
    print("Testing IPAdapter...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create model
    print("Loading CLIP model (this may take a moment)...")
    model = IPAdapter(
        clip_model_name="openai/clip-vit-large-patch14",
        cross_attention_dim=768,
        num_output_tokens=16,
        init_ip_scale=0.1,
        max_ip_scale=3.0,
    ).to(device)
    
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    frozen_params = sum(p.numel() for p in model.parameters() if not p.requires_grad)
    print(f"Trainable parameters: {trainable_params / 1e6:.2f}M")
    print(f"Frozen parameters (CLIP): {frozen_params / 1e6:.2f}M")
    
    # Create synthetic input (unaugmented cloth image)
    cloth_image_raw = torch.rand(B, 3, 1024, 768).to(device)  # [0, 1]
    
    # Forward pass
    with torch.no_grad():
        ip_keys, ip_values, ip_scale = model(cloth_image_raw)
    
    print(f"\nOutput shapes:")
    print(f"  ip_keys: {ip_keys.shape}")
    print(f"  ip_values: {ip_values.shape}")
    print(f"  ip_scale: {ip_scale:.4f}")
    
    assert ip_keys.shape == (B, 16, 768)
    assert ip_values.shape == (B, 16, 768)
    assert 0.0 <= ip_scale <= 3.0
    
    print("\n✓ IPAdapter test passed!")
    
    # Test individual components
    print("\nTesting individual components...")
    
    # Image projection
    proj = ImageProjectionMLP().to(device)
    clip_feat = torch.randn(B, 257, 1024).to(device)
    with torch.no_grad():
        ip_tokens = proj(clip_feat)
    assert ip_tokens.shape == (B, 16, 768)
    print(f"✓ Image projection: {ip_tokens.shape}")
    
    # Attention processor
    attn_proc = IPAdapterAttnProcessor(hidden_size=320).to(device)
    hidden_states = torch.randn(B, 64, 320).to(device)
    encoder_hidden = torch.randn(B, 77, 768).to(device)
    ip_hidden = torch.randn(B, 16, 768).to(device)
    
    with torch.no_grad():
        attn_out = attn_proc(
            hidden_states=hidden_states,
            encoder_hidden_states=encoder_hidden,
            ip_hidden_states=ip_hidden,
            ip_scale=0.5,
        )
    assert attn_out.shape == (B, 64, 320)
    print(f"✓ Attention processor: {attn_out.shape}")
    
    print("\n✅ All tests passed!")


if __name__ == '__main__':
    test_ip_adapter()
