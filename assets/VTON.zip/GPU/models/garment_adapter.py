"""
Garment Latent Adapter - Adapts warped cloth from pixel to latent space.
Frozen VAE encoder + trainable adapter layers.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class GarmentLatentAdapter(nn.Module):
    """
    Adapts warped garment image to latent space for diffusion UNet.
    
    Pipeline:
    1. Frozen VAE encoder: cloth_warped [B,3,1024,768] → latent [B,4,128,96]
    2. Trainable adapter: Conv2d adaptation for domain shift
    
    The adapter learns to bridge the gap between:
    - Warped garment appearance (geometric transformation applied)
    - Latent space of diffusion model (SD 1.5 VAE)
    
    Args:
        vae: Frozen VAE from Stable Diffusion (passed as dependency)
        vae_scaling_factor: VAE latent scaling (0.18215 for SD 1.5)
    """
    
    def __init__(self, vae, vae_scaling_factor: float = 0.18215):
        super().__init__()
        self.vae = vae
        self.vae_scaling_factor = vae_scaling_factor
        
        # Freeze VAE encoder
        for param in self.vae.parameters():
            param.requires_grad = False
        
        # Trainable adapter: 4→4 channels, 1×1 convolutions
        # Learns residual adaptation in latent space
        self.adapter = nn.Sequential(
            nn.Conv2d(4, 4, kernel_size=1),
            nn.GroupNorm(4, 4),  # Group norm with 4 groups (1 per channel)
            nn.GELU(),
            nn.Conv2d(4, 4, kernel_size=1),
        )
        
        # Initialize adapter near identity (small residual)
        nn.init.normal_(self.adapter[0].weight, mean=0.0, std=0.01)
        nn.init.constant_(self.adapter[0].bias, 0.0)
        nn.init.normal_(self.adapter[3].weight, mean=0.0, std=0.01)
        nn.init.constant_(self.adapter[3].bias, 0.0)
    
    def forward(self, cloth_warped: torch.Tensor) -> torch.Tensor:
        """
        Args:
            cloth_warped: Warped cloth image [B, 3, 1024, 768] float32 [-1, 1]
        
        Returns:
            cloth_latent_adapted: [B, 4, 128, 96] float32
        """
        B, C, H, W = cloth_warped.shape
        
        assert C == 3, f"Expected 3-channel RGB, got {C}"
        assert H == 1024 and W == 768, f"Expected [1024, 768], got [{H}, {W}]"
        
        # Encode with frozen VAE
        with torch.no_grad():
            # VAE encode returns distribution, sample from it
            latent_dist = self.vae.encode(cloth_warped).latent_dist
            cloth_latent = latent_dist.sample()  # [B, 4, 128, 96]
            cloth_latent = cloth_latent * self.vae_scaling_factor  # Scale to VAE range
        
        # Ensure latent is in correct range and shape
        assert cloth_latent.shape[1] == 4, f"VAE should produce 4 channels, got {cloth_latent.shape[1]}"
        assert cloth_latent.shape[2] == 128 and cloth_latent.shape[3] == 96, (
            f"VAE latent should be [128, 96], got [{cloth_latent.shape[2]}, {cloth_latent.shape[3]}]"
        )
        
        # Apply trainable adapter
        cloth_latent_adapted = self.adapter(cloth_latent)
        
        # Shape assertion
        assert cloth_latent_adapted.shape == (B, 4, 128, 96), (
            f"Output shape mismatch: {cloth_latent_adapted.shape}, expected [{B}, 4, 128, 96]"
        )
        
        return cloth_latent_adapted


if __name__ == "__main__":
    from diffusers import AutoencoderKL
    
    print("Testing GarmentLatentAdapter...")
    
    # Load pretrained VAE
    vae = AutoencoderKL.from_pretrained(
        "runwayml/stable-diffusion-v1-5",
        subfolder="vae"
    )
    
    # Create adapter
    adapter = GarmentLatentAdapter(vae, vae_scaling_factor=0.18215)
    
    # Test forward pass
    B = 2
    cloth_warped = torch.randn(B, 3, 1024, 768) * 0.5  # Simulated normalized image
    
    with torch.no_grad():
        output = adapter(cloth_warped)
    
    print(f"Input shape: {cloth_warped.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Expected shape: [2, 4, 128, 96]")
    
    assert output.shape == (B, 4, 128, 96), f"Shape mismatch: {output.shape}"
    print("GarmentLatentAdapter test: PASSED")
