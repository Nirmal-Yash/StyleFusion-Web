"""
Region Compositor - Learned Alpha Blending

Per spec MODULE I: Simple 3-layer conv to predict alpha for compositing.

Input: concat(I_synth[B,3], person_image[B,3], agnostic_mask[B,1]) → [B,7,H,W]
fusion_net: Conv(7→32,3,p1)→GN→GELU → Conv(32→32,3,p1)→GN→GELU → Conv(32→1,1)
alpha = sigmoid(alpha_logit) * agnostic_mask  ← hard prior: zero outside garment
I_final = alpha * I_synth + (1-alpha) * person_image

Returns: (I_final [B,3,H,W], alpha [B,1,H,W], alpha_logit [B,1,H,W])
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple


class RegionCompositor(nn.Module):
    """
    Per spec MODULE I: Simple 3-layer conv compositor.
    
    Input: concat(I_synth, person_image, agnostic_mask) → [B,7,H,W]
    Output: (I_final, alpha, alpha_logit)
    """
    
    def __init__(self, in_channels: int = 7, hidden_channels: int = 32):
        super().__init__()
        
        # Per spec: Conv(7→32,3,p1)→GN→GELU → Conv(32→32,3,p1)→GN→GELU → Conv(32→1,1)
        self.fusion_net = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, kernel_size=3, padding=1),
            nn.GroupNorm(8, hidden_channels),
            nn.GELU(),
            nn.Conv2d(hidden_channels, hidden_channels, kernel_size=3, padding=1),
            nn.GroupNorm(8, hidden_channels),
            nn.GELU(),
            nn.Conv2d(hidden_channels, 1, kernel_size=1),
        )
    
    def forward(
        self,
        I_synth: torch.Tensor,
        person_image: torch.Tensor,
        agnostic_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Args:
            I_synth: [B, 3, 1024, 768] diffusion decoded prediction (0-1 range)
            person_image: [B, 3, 1024, 768] original person (0-1 range)
            agnostic_mask: [B, 1, 1024, 768] binary mask
        
        Returns:
            I_final: [B, 3, 1024, 768] composited result
            alpha: [B, 1, 1024, 768] final alpha after hard prior
            alpha_logit: [B, 1, 1024, 768] raw logit before sigmoid
        """
        B, C, H, W = person_image.shape
        
        # Concatenate inputs (7 channels per spec)
        concat_input = torch.cat([
            I_synth,         # 3ch
            person_image,    # 3ch
            agnostic_mask,   # 1ch
        ], dim=1)  # [B, 7, H, W]
        
        # Predict alpha logit
        alpha_logit = self.fusion_net(concat_input)  # [B, 1, H, W]
        
        # Hard prior: alpha = sigmoid(alpha_logit) * agnostic_mask
        # This zeros alpha outside garment region
        alpha = torch.sigmoid(alpha_logit) * agnostic_mask  # [B, 1, H, W]
        
        # Blend: I_final = alpha * I_synth + (1-alpha) * person_image
        I_final = alpha * I_synth + (1.0 - alpha) * person_image
        
        return I_final, alpha, alpha_logit


class BoundaryMaskComputer(nn.Module):
    """
    Computes boundary weight mask for loss weighting.
    
    Gives higher loss weight near mask boundaries for smooth transitions.
    
    Input: agnostic_mask [B, 1, H, W] binary mask
    Output: boundary_weight [B, 1, H, W] weights in [1.0, boundary_weight_scale]
    
    Uses dilation + erosion to find boundary region.
    """
    
    def __init__(self, boundary_width: int = 5, boundary_weight_scale: float = 5.0):
        super().__init__()
        
        self.boundary_width = boundary_width
        self.boundary_weight_scale = boundary_weight_scale
    
    def forward(self, agnostic_mask: torch.Tensor) -> torch.Tensor:
        """
        Args:
            agnostic_mask: [B, 1, H, W] binary mask {0, 1}
        
        Returns:
            boundary_weight: [B, 1, H, W] weights in [1.0, scale]
        """
        B, C, H, W = agnostic_mask.shape
        
        # Dilate mask
        kernel_size = self.boundary_width * 2 + 1
        dilate_kernel = torch.ones(1, 1, kernel_size, kernel_size).to(agnostic_mask.device)
        
        mask_dilated = F.conv2d(
            agnostic_mask,
            dilate_kernel,
            padding=self.boundary_width,
        )
        mask_dilated = (mask_dilated > 0.5).float()
        
        # Erode mask
        mask_eroded = F.conv2d(
            agnostic_mask,
            dilate_kernel,
            padding=self.boundary_width,
        )
        mask_eroded = (mask_eroded >= (kernel_size * kernel_size) - 0.5).float()
        
        # Boundary region: dilated - eroded
        boundary_region = mask_dilated - mask_eroded  # [B, 1, H, W]
        
        # Create weight map
        boundary_weight = torch.ones_like(agnostic_mask)
        boundary_weight = boundary_weight + boundary_region * (self.boundary_weight_scale - 1.0)
        
        return boundary_weight


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_compositor():
    """Test RegionCompositor with synthetic inputs."""
    print("Testing RegionCompositor...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create model
    model = RegionCompositor().to(device)
    
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
    
    # Create synthetic inputs
    person_image = torch.rand(B, 3, 1024, 768).to(device)
    agnostic_image = torch.rand(B, 3, 1024, 768).to(device)
    cloth_warped = torch.rand(B, 3, 1024, 768).to(device)
    diffusion_output = torch.rand(B, 3, 1024, 768).to(device)
    agnostic_mask = torch.rand(B, 1, 1024, 768).to(device)
    agnostic_mask = (agnostic_mask > 0.5).float()
    
    # Forward pass
    with torch.no_grad():
        I_final, alpha_logit = model(
            person_image=person_image,
            agnostic_image=agnostic_image,
            cloth_warped=cloth_warped,
            diffusion_output=diffusion_output,
            agnostic_mask=agnostic_mask,
        )
    
    print(f"\nOutput shapes:")
    print(f"  I_final: {I_final.shape}")
    print(f"  alpha_logit: {alpha_logit.shape}")
    
    assert I_final.shape == (B, 3, 1024, 768)
    assert alpha_logit.shape == (B, 1, 1024, 768)
    
    print("\n✓ RegionCompositor test passed!")
    
    # Test that hard prior is applied correctly
    alpha = torch.sigmoid(alpha_logit)
    alpha_with_prior = model.apply_hard_prior(alpha, agnostic_mask)
    
    # Check: where mask=1, alpha should be 1.0
    mask_region = (agnostic_mask > 0.5)
    alpha_in_mask = alpha_with_prior[mask_region]
    assert torch.allclose(alpha_in_mask, torch.ones_like(alpha_in_mask), atol=1e-6), \
        "Hard prior not applied correctly!"
    
    print("✓ Hard prior verified!")
    
    # Test boundary mask computer
    print("\nTesting BoundaryMaskComputer...")
    boundary_computer = BoundaryMaskComputer(
        boundary_width=5,
        boundary_weight_scale=5.0,
    ).to(device)
    
    with torch.no_grad():
        boundary_weight = boundary_computer(agnostic_mask)
    
    print(f"  Boundary weight shape: {boundary_weight.shape}")
    print(f"  Boundary weight range: [{boundary_weight.min():.2f}, {boundary_weight.max():.2f}]")
    
    assert boundary_weight.shape == (B, 1, 1024, 768)
    assert boundary_weight.min() >= 1.0
    assert boundary_weight.max() <= 5.0
    
    print("✓ BoundaryMaskComputer test passed!")
    
    print("\n✅ All tests passed!")


if __name__ == '__main__':
    test_compositor()
