"""
Virtual Try-On System - Complete Integration

This module integrates all components into a complete try-on system:

1. BodyConditionEncoder: Encodes person features (agnostic, pose, parse, densepose)
2. GarmentFeatureExtractor: Extracts garment features from cloth_image (AUGMENTED)
3. GarmentWarpingModule: Warps garment to match body pose
4. GarmentLatentAdapter: Adapts warped cloth to latent space
5. IPAdapter: Encodes garment identity from cloth_image_raw (UNAUGMENTED)
6. ModifiedDiffusionUNet: Generates inpainted result with 17-channel input
7. RegionCompositor: Blends diffusion output with original person image

CRITICAL Data Flow:
- cloth_image_raw (unaugmented) → IPAdapter (CLIP encoding)
- cloth_image (augmented) → GarmentExtractor (texture/shape features)
- Both paths ensure: stable CLIP features + robust training augmentation

Forward Pass:
    Input: batch dict from VITONHDDataset
    Output: dict with all intermediate and final outputs
    
Training:
    - Diffusion loss on predicted noise
    - Warp losses (pretrain + mask, None-safe)
    - Perceptual + SSIM losses on final output
    - Compositor boundary loss
    
Inference:
    - Sample from diffusion model (DDIM/DDPM)
    - Return final composited try-on result
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional
from diffusers import AutoencoderKL, DDIMScheduler
from omegaconf import DictConfig

from .body_encoder import BodyConditionEncoder
from .garment_extractor import GarmentFeatureExtractor
from .warping import GarmentWarpingModule
from .garment_adapter import GarmentLatentAdapter
from .ip_adapter import IPAdapter
from .parse_embedder import ParseMapEmbedder
from .diffusion_unet import ModifiedDiffusionUNet
from .compositor import RegionCompositor


class VirtualTryOnSystem(nn.Module):
    """
    Complete Virtual Try-On system integrating all modules.
    
    Inputs (from VITONHDDataset batch):
        - person_image: [B, 3, 1024, 768] original person
        - agnostic_image: [B, 3, 1024, 768] person with garment masked
        - pose_image: [B, 18, 1024, 768] OpenPose heatmap
        - pose_keypoints: [B, 18, 2] keypoint coordinates
        - parse_unified25: [B, 1024, 768] semantic parse
        - densepose_uv: [B, 3, 1024, 768] DensePose IUV
        - densepose_conf: [B, 1, 1024, 768] DensePose confidence
        - cloth_image_raw: [B, 3, 1024, 768] garment RGB (UNAUGMENTED)
        - cloth_image: [B, 3, 1024, 768] garment RGB (AUGMENTED)
        - cloth_mask: [B, 1, 1024, 768] garment mask
        - agnostic_mask: [B, 1, 1024, 768] binary inpaint mask
        - warp_cloth: None (MOD-10 absent, handled gracefully)
        - warp_cloth_mask: None (MOD-11 absent, handled gracefully)
    
    Outputs (dict with 15+ keys):
        Training outputs (Section 9.5):
            - eps_pred: [B, 4, 128, 96] predicted noise
            - eps_target: [B, 4, 128, 96] target noise
            - timesteps: [B] sampled timesteps
            - x0_pred_image: [B, 3, 1024, 768] predicted clean image
            - cloth_warped: [B, 3, 1024, 768] warped garment
            - cloth_mask_warped: [B, 1, 1024, 768] warped mask
            - deformation_field: [B, 2, 128, 96] flow field
            - part_masks_full: [B, 5, 1024, 768] body part masks
            - ctrl_pts_src: [B, 25, 2] TPS source points
            - ctrl_pts_tgt: [B, 25, 2] TPS target points
            - alpha_logit: [B, 1, 1024, 768] compositor alpha
            - I_final: [B, 3, 1024, 768] final result
            - ip_scale: float, IP-Adapter strength
            - garment_features: [B, 512] garment descriptor
            - body_features: [B, 256, 128, 96] body features
    """
    
    def __init__(self, cfg: DictConfig):
        super().__init__()
        
        self.cfg = cfg
        
        # VAE scaling factor (defined early — used by GarmentLatentAdapter)
        self.vae_scale_factor = 0.18215
        
        # Load pretrained VAE (frozen)
        print("Loading pretrained VAE...")
        self.vae = AutoencoderKL.from_pretrained(
            cfg.model.diffusion.base_model,
            subfolder="vae",
        )
        for param in self.vae.parameters():
            param.requires_grad = False
        self.vae.eval()
        
        # Initialize all modules
        print("Initializing BodyConditionEncoder...")
        self.body_encoder = BodyConditionEncoder(
            pretrained_swin=cfg.model.body_encoder.get('pretrained', True),
            freeze_swin=cfg.model.body_encoder.get('freeze_swin', False),
            densepose_min_coverage=cfg.data.get('densepose_min_coverage', 0.15),
        )
        
        print("Initializing GarmentFeatureExtractor...")
        self.garment_extractor = GarmentFeatureExtractor(
            pretrained_convnext=cfg.model.garment_extractor.get('pretrained', True),
            freeze_convnext=cfg.model.garment_extractor.get('freeze_convnext', False),
        )
        
        print("Initializing GarmentWarpingModule...")
        self.warping_module = GarmentWarpingModule(
            body_channels=256,
            cloth_channels=3,
            num_parts=cfg.model.warping.get('num_parts', 5),
            correlation_displacement=cfg.model.warping.get('correlation_max_displacement', 8),
            num_ctrl_pts=int(cfg.model.warping.get('tps_control_points', 25) ** 0.5),
        )
        
        print("Initializing GarmentLatentAdapter...")
        self.garment_adapter = GarmentLatentAdapter(
            vae=self.vae,
            vae_scaling_factor=self.vae_scale_factor,
        )
        
        print("Initializing IPAdapter...")
        self.ip_adapter = IPAdapter(
            clip_model_name=cfg.model.ip_adapter.get('clip_model', 'openai/clip-vit-large-patch14'),
            cross_attention_dim=cfg.model.ip_adapter.get('unet_dim', 768),
            num_output_tokens=cfg.model.ip_adapter.get('num_tokens', 16),
            init_ip_scale=cfg.model.ip_adapter.get('ip_scale_init', 0.1),
            max_ip_scale=cfg.model.ip_adapter.get('ip_scale_max', 3.0),
        )
        
        print("Initializing ModifiedDiffusionUNet...")
        self.diffusion_unet = ModifiedDiffusionUNet(
            pretrained_model_name=cfg.model.diffusion.base_model,
            freeze_pretrained=False,
        )
        
        print("Initializing RegionCompositor...")
        self.compositor = RegionCompositor(
            in_channels=cfg.model.compositor.get('in_channels', 7),
            hidden_channels=cfg.model.compositor.get('hidden_channels', 32),
        )
        
        print("Initializing ParseMapEmbedder...")
        self.parse_embedder = ParseMapEmbedder(
            vocab_size=cfg.model.get('unified_parse_classes', 25),
            embed_dim=cfg.model.parse_embedder.get('embed_dim', 64),
            output_channels=cfg.model.parse_embedder.get('output_channels', 3),
        )
        
        # Diffusion scheduler (for sampling during inference)
        self.scheduler = DDIMScheduler.from_pretrained(
            cfg.model.diffusion.base_model,
            subfolder="scheduler",
        )
        
        # Create null-text embedding for unconditional generation
        # SD 1.5 expects [B, 77, 768] text encoder hidden states
        self.register_buffer(
            'null_text_embedding',
            torch.zeros(1, 77, 768),
        )
        
        print("✓ VirtualTryOnSystem initialized!")
    
    @torch.no_grad()
    def encode_to_latent(self, image: torch.Tensor) -> torch.Tensor:
        """
        Encode RGB image to latent space using frozen VAE.
        
        Args:
            image: [B, 3, 1024, 768] RGB in [-1, 1] or [0, 1]
        
        Returns:
            latent: [B, 4, 128, 96] latent representation
        """
        # Ensure image is in [-1, 1]
        if image.min() >= 0.0:
            image = image * 2.0 - 1.0
        
        latent_dist = self.vae.encode(image).latent_dist
        latent = latent_dist.sample() * self.vae_scale_factor
        
        return latent
    
    @torch.no_grad()
    def decode_from_latent(self, latent: torch.Tensor) -> torch.Tensor:
        """
        Decode latent to RGB image using frozen VAE.
        
        Args:
            latent: [B, 4, 128, 96] latent representation
        
        Returns:
            image: [B, 3, 1024, 768] RGB in [-1, 1]
        """
        image = self.vae.decode(latent / self.vae_scale_factor).sample
        
        return image
    
    def forward_train(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        Training forward pass with diffusion loss.
        
        Args:
            batch: dict from VITONHDDataset
        
        Returns:
            output_dict with all intermediate and final outputs
        """
        B = batch['person_image'].shape[0]
        device = batch['person_image'].device
        
        # =====================================================================
        # 1. ENCODE BODY CONDITIONS
        # =====================================================================
        
        # Derive per-pixel densepose confidence from IUV
        # R channel × 255 gives raw part ID; part_id > 0 means body part detected
        densepose_iuv = batch['densepose_iuv']
        raw_part = (densepose_iuv[:, 0:1, :, :] * 255.0).round()
        densepose_conf = (raw_part > 0).float()  # [B, 1, 1024, 768]
        
        # parse_unified25 comes as [B,1,H,W] from dataset — squeeze for body_encoder
        parse_u25 = batch['parse_unified25'].squeeze(1)  # [B, 1024, 768]
        
        body_feat = self.body_encoder(
            agnostic_image=batch['agnostic_image'],
            pose_image=batch['openpose_img'],
            pose_keypoints=batch['keypoint_coords'],
            parse_unified25=parse_u25,
            densepose_uv=densepose_iuv,
            densepose_conf=densepose_conf,
        )  # [B, 256, 128, 96]
        
        # =====================================================================
        # 2. EXTRACT GARMENT FEATURES (uses cloth_image AUGMENTED)
        # =====================================================================
        
        garment_features = self.garment_extractor(
            cloth_image=batch['cloth_image'],  # AUGMENTED
            cloth_mask=batch['cloth_mask'],
        )  # [B, 512]
        
        # =====================================================================
        # 3. WARP GARMENT TO BODY POSE
        # =====================================================================
        
        warp_output = self.warping_module(
            body_feat=body_feat,
            cloth_image=batch['cloth_image'],
            cloth_mask=batch['cloth_mask'],
        )
        
        cloth_warped = warp_output['cloth_warped']            # [B, 3, 1024, 768]
        cloth_mask_warped = warp_output['cloth_mask_warped']  # [B, 1, 1024, 768]
        deformation_field = warp_output['deformation_field']  # [B, 2, 128, 96]
        part_masks_full = warp_output['part_masks_full']      # [B, 5, 1024, 768]
        ctrl_pts_src = warp_output['ctrl_pts_src']            # [B, 25, 2]
        ctrl_pts_tgt = warp_output['ctrl_pts_tgt']            # [B, 25, 2]
        
        # =====================================================================
        # 4. ADAPT WARPED GARMENT TO LATENT SPACE
        # =====================================================================
        
        garment_latent = self.garment_adapter(cloth_warped)  # [B, 4, 128, 96]
        
        # =====================================================================
        # 5. ENCODE IP-ADAPTER FEATURES (uses cloth_image_raw UNAUGMENTED)
        # =====================================================================
        
        ip_keys, ip_values, ip_scale = self.ip_adapter(
            cloth_image_raw=batch['cloth_image_raw']  # UNAUGMENTED
        )
        # ip_keys/values: [B, 16, 768]
        # ip_scale: float
        
        # =====================================================================
        # 6. ENCODE IMAGES TO LATENTS & BUILD 17-CHANNEL INPUT
        # =====================================================================
        
        # Encode person image to latent (training target)
        person_latent = self.encode_to_latent(batch['person_image'])  # [B, 4, 128, 96]
        
        # Ch 4-7: Encode agnostic (masked person) image to latent
        masked_person_latent = self.encode_to_latent(batch['agnostic_image'])  # [B, 4, 128, 96]
        
        # Ch 8: Downsample agnostic mask to latent resolution
        agnostic_mask_ds = F.interpolate(
            batch['agnostic_mask'],
            size=(128, 96),
            mode='bilinear',
            align_corners=False,
        )  # [B, 1, 128, 96]
        
        # Ch 9-12: cloth_latent_adapted (already computed above as garment_latent)
        # garment_latent = [B, 4, 128, 96]
        
        # Ch 13: Downsample warped cloth mask to latent resolution
        cloth_mask_warped_ds = F.interpolate(
            cloth_mask_warped,
            size=(128, 96),
            mode='nearest',
        )  # [B, 1, 128, 96]
        
        # Ch 14-16: Parse map embedding
        parse_embedded = self.parse_embedder(
            batch['parse_unified25']
        )  # [B, 3, 128, 96]
        
        # =====================================================================
        # 7. DIFFUSION FORWARD PROCESS (add noise)
        # =====================================================================
        
        # Sample timesteps
        timesteps = torch.randint(
            0,
            self.scheduler.config.num_train_timesteps,
            (B,),
            device=device,
        ).long()
        
        # Sample noise
        noise = torch.randn_like(person_latent)
        
        # Add noise to person latent
        noisy_latent = self.scheduler.add_noise(person_latent, noise, timesteps)
        
        # =====================================================================
        # 8. DIFFUSION UNET FORWARD (17-channel input per spec)
        # =====================================================================
        
        # Expand null-text embedding for batch
        null_text = self.null_text_embedding.expand(B, -1, -1)  # [B, 77, 768]
        
        # Predict noise — UNet internally concatenates to 17 channels:
        # Ch 0-3: noisy_latent, Ch 4-7: masked_person_latent, Ch 8: agnostic_mask_ds,
        # Ch 9-12: cloth_latent_adapted, Ch 13: cloth_mask_warped_ds, Ch 14-16: parse_embedded
        eps_pred = self.diffusion_unet(
            noisy_latent=noisy_latent,
            timesteps=timesteps,
            agnostic_latent=masked_person_latent,
            inpaint_mask=agnostic_mask_ds,
            body_latent=garment_latent,         # Ch 9-12: cloth_latent_adapted
            garment_latent=torch.cat([cloth_mask_warped_ds, parse_embedded], dim=1),  # Ch 13-16
            encoder_hidden_states=null_text,    # Null-text embedding for cross-attention
            ip_hidden_states=(ip_keys, ip_values),  # Both K and V for IP-Adapter
            ip_scale=ip_scale,
        )  # [B, 4, 128, 96]
        
        # =====================================================================
        # 9. PREDICT CLEAN IMAGE FROM NOISE
        # =====================================================================
        
        # Estimate x0 from noise prediction (DDIM formula)
        alpha_t = self.scheduler.alphas_cumprod[timesteps].view(B, 1, 1, 1).to(device)
        sqrt_alpha_t = torch.sqrt(alpha_t)
        sqrt_one_minus_alpha_t = torch.sqrt(1.0 - alpha_t)
        
        x0_pred_latent = (noisy_latent - sqrt_one_minus_alpha_t * eps_pred) / sqrt_alpha_t
        
        # Decode to image space
        x0_pred_image = self.decode_from_latent(x0_pred_latent)  # [B, 3, 1024, 768]
        
        # Normalize to [0, 1] for compositor
        x0_pred_image = (x0_pred_image + 1.0) / 2.0
        x0_pred_image = torch.clamp(x0_pred_image, 0.0, 1.0)
        
        # =====================================================================
        # 10. COMPOSITOR (blend diffusion output with original person)
        # =====================================================================
        
        # Ensure person_image is in [0, 1] for compositor
        # person_image is always [-1,1] from dataset, so always convert
        person_01 = (batch['person_image'] + 1.0) / 2.0
        
        # Per spec MODULE I: concat(I_synth, person_image, agnostic_mask) → 7ch
        I_final, alpha, alpha_logit = self.compositor(
            I_synth=x0_pred_image,
            person_image=person_01,
            agnostic_mask=batch['agnostic_mask'],
        )
        
        # =====================================================================
        # 11. ASSEMBLE OUTPUT DICTIONARY
        # =====================================================================
        
        output = {
            # Diffusion outputs
            'eps_pred': eps_pred,                      # [B, 4, 128, 96]
            'eps_target': noise,                       # [B, 4, 128, 96]
            'timesteps': timesteps,                    # [B]
            'x0_pred_image': x0_pred_image,            # [B, 3, 1024, 768]
            
            # Warping outputs
            'cloth_warped': cloth_warped,              # [B, 3, 1024, 768]
            'cloth_mask_warped': cloth_mask_warped,    # [B, 1, 1024, 768]
            'deformation_field': deformation_field,    # [B, 2, 128, 96]
            'part_masks_full': part_masks_full,        # [B, 5, 1024, 768]
            'ctrl_pts_src': ctrl_pts_src,              # [B, 25, 2]
            'ctrl_pts_tgt': ctrl_pts_tgt,              # [B, 25, 2]
            
            # Compositor outputs
            'alpha_logit': alpha_logit,                # [B, 1, 1024, 768]
            'I_final': I_final,                        # [B, 3, 1024, 768]
            
            # Feature outputs
            'ip_scale': ip_scale,                      # float
            'garment_features': garment_features,      # [B, 512]
            'body_features': body_feat,                # [B, 256, 128, 96]
            
            # Ground truth (for losses)
            'person_image': person_01,                 # [B, 3, 1024, 768]
            'warp_cloth_gt': batch.get('warp_cloth', None),      # None (MOD-10 absent)
            'warp_mask_gt': batch.get('warp_cloth_mask', None),  # None (MOD-11 absent)
        }
        
        return output
    
    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """
        Main forward method (delegates to forward_train).
        
        Args:
            batch: dict from VITONHDDataset
        
        Returns:
            output_dict with all outputs
        """
        return self.forward_train(batch)


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_tryon_system():
    """Test VirtualTryOnSystem with synthetic inputs."""
    print("Testing VirtualTryOnSystem...")
    print("WARNING: This will download ~5GB of pretrained weights.")
    print("Press Ctrl+C to cancel, or wait to continue...")
    
    import time
    time.sleep(3)
    
    from omegaconf import OmegaConf
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 1  # Small batch for testing
    
    # Create minimal config
    cfg = OmegaConf.create({
        'model': {
            'diffusion': {
                'pretrained_model': 'stabilityai/stable-diffusion-inpainting',
            },
            'body_encoder': {
                'pretrained_swin': False,  # Faster for testing
                'freeze_swin': False,
                'densepose_conf_threshold': 0.15,
            },
            'garment_extractor': {
                'pretrained_convnext': False,  # Faster
                'freeze_convnext': False,
            },
            'warping': {
                'correlation_displacement': 8,
                'num_ctrl_pts': 5,
            },
            'ip_adapter': {
                'clip_model_name': 'openai/clip-vit-large-patch14',
                'num_output_tokens': 16,
                'init_ip_scale': 0.1,
                'max_ip_scale': 3.0,
            },
        }
    })
    
    # Create model
    model = VirtualTryOnSystem(cfg).to(device)
    
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\nTrainable parameters: {trainable_params / 1e6:.2f}M")
    
    # Create synthetic batch
    batch = {
        'person_image': torch.rand(B, 3, 1024, 768).to(device),
        'agnostic_image': torch.rand(B, 3, 1024, 768).to(device),
        'pose_image': torch.rand(B, 18, 1024, 768).to(device),
        'pose_keypoints': torch.randn(B, 18, 2).to(device) * 2 - 1,
        'parse_unified25': torch.randint(0, 25, (B, 1024, 768)).to(device),
        'densepose_uv': torch.rand(B, 3, 1024, 768).to(device),
        'densepose_conf': torch.rand(B, 1, 1024, 768).to(device),
        'cloth_image_raw': torch.rand(B, 3, 1024, 768).to(device),
        'cloth_image': torch.rand(B, 3, 1024, 768).to(device),
        'cloth_mask': (torch.rand(B, 1, 1024, 768) > 0.5).float().to(device),
        'agnostic_mask': (torch.rand(B, 1, 1024, 768) > 0.5).float().to(device),
        'warp_cloth': None,  # MOD-10 absent
        'warp_cloth_mask': None,  # MOD-11 absent
    }
    
    # Forward pass
    print("\nRunning forward pass...")
    with torch.no_grad():
        output = model(batch)
    
    print("\nOutput keys:")
    for key in output.keys():
        val = output[key]
        if isinstance(val, torch.Tensor):
            print(f"  {key}: {val.shape}")
        else:
            print(f"  {key}: {val}")
    
    # Verify critical outputs
    assert output['eps_pred'].shape == (B, 4, 128, 96)
    assert output['I_final'].shape == (B, 3, 1024, 768)
    assert output['cloth_warped'].shape == (B, 3, 1024, 768)
    
    print("\n✅ VirtualTryOnSystem test passed!")


if __name__ == '__main__':
    test_tryon_system()
