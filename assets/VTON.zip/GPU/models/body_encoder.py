"""
Body Condition Encoder - Multi-Branch Fusion Architecture

This module encodes 4 body condition inputs into a unified latent representation:
1. Agnostic RGB image (via SwinV2-Small backbone)
2. OpenPose image + keypoint coordinates (via PoseCNN + KeypointMLP)
3. Semantic parse map UNIFIED-25 (via ParseMapEmbedCNN)
4. DensePose UV + confidence (via DensePoseCNN with confidence weighting)

All branches downsample to 128×96 spatial resolution (stride-8 from 1024×768).
Outputs are fused via cross-attention to produce final body features.

Key Features:
- SwinV2 pretrained backbone (frozen initially, unfrozen after warm-up)
- Keypoint coordinates (18×2) encoded via MLP and added to pose feature map
- Semantic parse uses learned embedding + stride-8 CNN
- DensePose masked by low-confidence regions
- Cross-attention fusion with learnable queries
- Output: [B, 256, 128, 96] feature map
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple
import timm


class SwinV2AgnosticBranch(nn.Module):
    """
    Branch 1: Agnostic RGB image encoder using SwinV2-Small backbone.
    
    Input: agnostic_image [B, 3, 1024, 768]
    Output: agnostic_feat [B, 256, 128, 96]
    
    Uses timm's swinv2_small_window8_256 pretrained on ImageNet-1K.
    Extracts features before final pooling/classification, then projects to target dims.
    """
    
    def __init__(self, pretrained: bool = True, freeze_backbone: bool = False):
        super().__init__()
        
        # Load SwinV2-Small with window size 8
        # Default input 256x256, we'll adapt for 1024x768
        self.backbone = timm.create_model(
            'swinv2_small_window8_256',
            pretrained=pretrained,
            features_only=True,
            out_indices=[3],  # Stage 4 output: stride-32
        )
        
        # SwinV2-Small stage 4 output: 768 channels at stride-32
        # For 1024x768 input → 32x24 feature map
        # We need 128x96 (stride-8), so upsample 4x
        self.upsample = nn.Sequential(
            nn.ConvTranspose2d(768, 512, kernel_size=4, stride=2, padding=1),  # 64x48
            nn.GroupNorm(32, 512),
            nn.GELU(),
            nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1),  # 128x96
            nn.GroupNorm(32, 256),
            nn.GELU(),
        )
        
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
    
    def forward(self, agnostic_image: torch.Tensor) -> torch.Tensor:
        """
        Args:
            agnostic_image: [B, 3, 1024, 768] RGB image with garment area masked
        
        Returns:
            agnostic_feat: [B, 256, 128, 96] encoded features
        """
        B, C, H, W = agnostic_image.shape
        assert C == 3 and H == 1024 and W == 768, \
            f"Expected [B,3,1024,768], got {agnostic_image.shape}"
        
        # Extract features from backbone (returns list with 1 element)
        features = self.backbone(agnostic_image)[0]  # [B, 768, H/32, W/32]
        
        # Upsample to target resolution
        agnostic_feat = self.upsample(features)  # [B, 256, 128, 96]
        
        assert agnostic_feat.shape == (B, 256, 128, 96), \
            f"Expected [B,256,128,96], got {agnostic_feat.shape}"
        
        return agnostic_feat


class PoseBranch(nn.Module):
    """
    Branch 2: OpenPose image + keypoint coordinates encoder.
    
    Combines:
    - Pose image: 3-channel RGB skeleton render [B, 3, 1024, 768]
    - Pose keypoints: [B, 36] or [B, 18, 2] normalized coordinates
    
    Output: pose_feat [B, 128, 128, 96]
    
    Strategy:
    - CNN encodes skeleton render to stride-8 feature map
    - MLP encodes keypoint coordinates to [B, 128] vector
    - Broadcast MLP output and add to feature map spatially
    """
    
    def __init__(self):
        super().__init__()
        
        # CNN for pose image (3-channel RGB skeleton render)
        self.pose_cnn = nn.Sequential(
            # 1024x768 -> 512x384
            nn.Conv2d(3, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            
            # 512x384 -> 256x192
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            
            # 256x192 -> 128x96
            nn.Conv2d(128, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
        )
        
        # MLP for keypoint coordinates
        self.keypoint_mlp = nn.Sequential(
            nn.Flatten(),  # [B, 36] or [B, 18, 2] -> [B, 36]
            nn.Linear(18 * 2, 256),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(256, 128),
            nn.GELU(),
        )
    
    def forward(self, pose_image: torch.Tensor, pose_keypoints: torch.Tensor) -> torch.Tensor:
        """
        Args:
            pose_image: [B, 3, 1024, 768] OpenPose RGB skeleton render
            pose_keypoints: [B, 36] or [B, 18, 2] normalized coordinates
        
        Returns:
            pose_feat: [B, 128, 128, 96] encoded pose features
        """
        B = pose_image.shape[0]
        assert pose_image.shape == (B, 3, 1024, 768), \
            f"Expected pose_image [B,3,1024,768], got {pose_image.shape}"
        
        # Reshape keypoints if flat
        if pose_keypoints.dim() == 2 and pose_keypoints.shape[-1] == 36:
            pose_keypoints = pose_keypoints.view(B, 18, 2)
        
        # Encode pose image
        pose_feat_spatial = self.pose_cnn(pose_image)  # [B, 128, 128, 96]
        
        # Encode keypoint coordinates
        keypoint_feat = self.keypoint_mlp(pose_keypoints)  # [B, 128]
        
        # Broadcast and add to spatial features
        keypoint_feat_spatial = keypoint_feat.view(B, 128, 1, 1).expand(B, 128, 128, 96)
        
        pose_feat = pose_feat_spatial + keypoint_feat_spatial  # [B, 128, 128, 96]
        
        assert pose_feat.shape == (B, 128, 128, 96), \
            f"Expected [B,128,128,96], got {pose_feat.shape}"
        
        return pose_feat


class ParseMapBranch(nn.Module):
    """
    Branch 3: Semantic parse map encoder (UNIFIED-25 vocabulary).
    
    Input: parse_unified25 [B, 1024, 768] long tensor with values [0, 24]
    Output: parse_feat [B, 64, 128, 96]
    
    Uses learned embedding + stride-8 CNN encoder.
    """
    
    def __init__(self, num_classes: int = 25, embed_dim: int = 64):
        super().__init__()
        
        # Learned embedding for each class
        self.embedding = nn.Embedding(num_classes, embed_dim)
        nn.init.normal_(self.embedding.weight, mean=0.0, std=0.01)
        
        # Stride-8 CNN encoder
        self.encoder = nn.Sequential(
            # 1024x768 -> 512x384
            nn.Conv2d(embed_dim, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            
            # 512x384 -> 256x192
            nn.Conv2d(128, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            
            # 256x192 -> 128x96
            nn.Conv2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
        )
    
    def forward(self, parse_unified25: torch.Tensor) -> torch.Tensor:
        """
        Args:
            parse_unified25: [B, 1024, 768] long tensor, values in [0, 24]
        
        Returns:
            parse_feat: [B, 64, 128, 96] encoded semantic features
        """
        B, H, W = parse_unified25.shape
        assert H == 1024 and W == 768, \
            f"Expected [B,1024,768], got {parse_unified25.shape}"
        
        # Embed each pixel: [B, H, W] -> [B, H, W, embed_dim]
        parse_embedded = self.embedding(parse_unified25)  # [B, 1024, 768, 64]
        
        # Permute to [B, C, H, W] for conv layers
        parse_embedded = parse_embedded.permute(0, 3, 1, 2)  # [B, 64, 1024, 768]
        
        # Encode to stride-8
        parse_feat = self.encoder(parse_embedded)  # [B, 64, 128, 96]
        
        assert parse_feat.shape == (B, 64, 128, 96), \
            f"Expected [B,64,128,96], got {parse_feat.shape}"
        
        return parse_feat


class DensePoseBranch(nn.Module):
    """
    Branch 4: DensePose IUV encoder with soft confidence weighting.
    
    Input: 
        - densepose_uv: [B, 3, 1024, 768] (R=part_id norm, G=U_coord, B=V_coord [0,1])
        - densepose_conf: [B, 1, 1024, 768] per-pixel binary (part detected or not)
    
    Output: densepose_feat [B, 64, 128, 96]
    
    Per spec Section 4.2 Module D:
    - Compute coverage = fraction of pixels with part_id > 0
    - confidence = (coverage / DENSEPOSE_MIN_COVERAGE).clamp(0, 1)  [soft, per-sample scalar]
    - Encode IUV through stride-8 CNN
    - Multiply output by confidence (soft weighting, NOT binary threshold)
    """
    
    def __init__(self, min_coverage: float = 0.15):
        super().__init__()
        self.min_coverage = min_coverage
        
        # Stride-8 CNN encoder for 4-channel input (IUV + conf)
        self.encoder = nn.Sequential(
            nn.Conv2d(4, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            nn.Conv2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
        )
    
    def forward(self, densepose_uv: torch.Tensor, densepose_conf: torch.Tensor) -> torch.Tensor:
        """
        Args:
            densepose_uv: [B, 3, 1024, 768] IUV values
            densepose_conf: [B, 1, 1024, 768] per-pixel detection (0 or 1)
        
        Returns:
            densepose_feat: [B, 64, 128, 96] confidence-weighted features
        """
        B, C, H, W = densepose_uv.shape
        assert C == 3 and H == 1024 and W == 768
        assert densepose_conf.shape == (B, 1, H, W)
        
        # Compute per-sample coverage (fraction of pixels with body part detected)
        coverage = densepose_conf.mean(dim=[1, 2, 3])  # [B] scalar per sample
        
        # Soft confidence weight: linear ramp from 0 to 1 based on coverage
        # coverage 0.0 → weight 0.0 (no densepose → branch contributes nothing)
        # coverage >= min_coverage → weight 1.0 (full contribution)
        # coverage between → proportional (partial contribution)
        confidence = (coverage / self.min_coverage).clamp(0.0, 1.0)  # [B]
        
        # Concatenate IUV + confidence
        densepose_input = torch.cat([densepose_uv, densepose_conf], dim=1)  # [B, 4, H, W]
        
        # Encode to stride-8
        densepose_feat = self.encoder(densepose_input)  # [B, 64, 128, 96]
        
        # Apply soft confidence weighting (per-sample scalar, NOT per-pixel threshold)
        densepose_feat = densepose_feat * confidence.view(B, 1, 1, 1)
        
        assert densepose_feat.shape == (B, 64, 128, 96)
        
        return densepose_feat


class CrossAttentionFusion(nn.Module):
    """
    Channel-attention fusion of 4 body condition branches.
    
    Uses channel squeeze-excitation + conv layers instead of full spatial
    attention (which would OOM at 128x96 = 12288 tokens).
    
    Input (concatenated):
        - agnostic_feat: [B, 256, 128, 96]
        - pose_feat: [B, 128, 128, 96]
        - parse_feat: [B, 64, 128, 96]
        - densepose_feat: [B, 64, 128, 96]
        Total: [B, 512, 128, 96]
    
    Output: body_feat [B, 256, 128, 96]
    """
    
    def __init__(self, in_channels: int = 512, out_channels: int = 256, num_heads: int = 8):
        super().__init__()
        
        # Projection from concatenated 512ch to 256ch
        self.proj = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1),
            nn.GroupNorm(32, out_channels),
            nn.GELU(),
        )
        
        # Two residual conv blocks for local spatial mixing
        self.block1 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.GroupNorm(32, out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.GroupNorm(32, out_channels),
        )
        self.block2 = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.GroupNorm(32, out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.GroupNorm(32, out_channels),
        )
        
        # Channel squeeze-excitation for global attention
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(out_channels, out_channels // 4),
            nn.GELU(),
            nn.Linear(out_channels // 4, out_channels),
            nn.Sigmoid(),
        )
        
        self.act = nn.GELU()
    
    def forward(self, concat_feat: torch.Tensor) -> torch.Tensor:
        """
        Args:
            concat_feat: [B, 512, 128, 96] concatenated branch features
        
        Returns:
            body_feat: [B, 256, 128, 96] fused body features
        """
        B, C, H, W = concat_feat.shape
        assert C == 512 and H == 128 and W == 96, \
            f"Expected [B,512,128,96], got {concat_feat.shape}"
        
        # Project 512 -> 256
        x = self.proj(concat_feat)  # [B, 256, 128, 96]
        
        # Residual conv blocks for spatial mixing
        x = self.act(x + self.block1(x))
        x = self.act(x + self.block2(x))
        
        # Channel attention via squeeze-excitation
        se_weight = self.se(x).unsqueeze(-1).unsqueeze(-1)  # [B, 256, 1, 1]
        body_feat = x * se_weight
        
        assert body_feat.shape == (B, 256, H, W), \
            f"Expected [B,256,128,96], got {body_feat.shape}"
        
        return body_feat


class BodyConditionEncoder(nn.Module):
    """
    Complete body condition encoder combining all 4 branches with cross-attention fusion.
    
    Inputs:
        - agnostic_image: [B, 3, 1024, 768]
        - pose_image: [B, 18, 1024, 768]
        - pose_keypoints: [B, 18, 2]
        - parse_unified25: [B, 1024, 768] long
        - densepose_uv: [B, 3, 1024, 768]
        - densepose_conf: [B, 1, 1024, 768]
    
    Output:
        - body_feat: [B, 256, 128, 96] unified body condition features
    
    Architecture:
        Branch 1 (Agnostic): SwinV2-Small -> 256 channels
        Branch 2 (Pose): PoseCNN + KeypointMLP -> 128 channels
        Branch 3 (Parse): EmbedCNN -> 64 channels
        Branch 4 (DensePose): DensePoseCNN -> 64 channels
        Fusion: Cross-attention -> 256 channels
    """
    
    def __init__(
        self,
        pretrained_swin: bool = True,
        freeze_swin: bool = False,
        densepose_min_coverage: float = 0.15,
    ):
        super().__init__()
        
        # Initialize all branches
        self.agnostic_branch = SwinV2AgnosticBranch(
            pretrained=pretrained_swin,
            freeze_backbone=freeze_swin
        )
        self.pose_branch = PoseBranch()
        self.parse_branch = ParseMapBranch(num_classes=25, embed_dim=64)
        self.densepose_branch = DensePoseBranch(min_coverage=densepose_min_coverage)
        
        # Cross-attention fusion
        # Input: 256 + 128 + 64 + 64 = 512 channels
        # Output: 256 channels
        self.fusion = CrossAttentionFusion(in_channels=512, out_channels=256, num_heads=8)
    
    def forward(
        self,
        agnostic_image: torch.Tensor,
        pose_image: torch.Tensor,
        pose_keypoints: torch.Tensor,
        parse_unified25: torch.Tensor,
        densepose_uv: torch.Tensor,
        densepose_conf: torch.Tensor,
    ) -> torch.Tensor:
        """
        Encode all body condition inputs into unified representation.
        
        Args:
            agnostic_image: [B, 3, 1024, 768] RGB with garment masked
            pose_image: [B, 3, 1024, 768] OpenPose skeleton render
            pose_keypoints: [B, 36] or [B, 18, 2] normalized keypoint coordinates
            parse_unified25: [B, 1024, 768] semantic parse (UNIFIED-25 vocab)
            densepose_uv: [B, 3, 1024, 768] DensePose IUV
            densepose_conf: [B, 1, 1024, 768] DensePose confidence
        
        Returns:
            body_feat: [B, 256, 128, 96] encoded body features
        """
        B = agnostic_image.shape[0]
        
        # Encode each branch
        agnostic_feat = self.agnostic_branch(agnostic_image)         # [B, 256, 128, 96]
        pose_feat = self.pose_branch(pose_image, pose_keypoints)     # [B, 128, 128, 96]
        parse_feat = self.parse_branch(parse_unified25)              # [B, 64, 128, 96]
        densepose_feat = self.densepose_branch(densepose_uv, densepose_conf)  # [B, 64, 128, 96]
        
        # Concatenate all branches
        concat_feat = torch.cat([
            agnostic_feat,    # 256 channels
            pose_feat,        # 128 channels
            parse_feat,       # 64 channels
            densepose_feat,   # 64 channels
        ], dim=1)  # [B, 512, 128, 96]
        
        # Fuse with cross-attention
        body_feat = self.fusion(concat_feat)  # [B, 256, 128, 96]
        
        assert body_feat.shape == (B, 256, 128, 96), \
            f"Expected [B,256,128,96], got {body_feat.shape}"
        
        return body_feat


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_body_encoder():
    """Test BodyConditionEncoder with synthetic inputs."""
    print("Testing BodyConditionEncoder...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create model
    model = BodyConditionEncoder(
        pretrained_swin=False,  # Faster for testing
        freeze_swin=False,
        densepose_min_coverage=0.15,
    ).to(device)
    
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
    
    # Create synthetic inputs
    agnostic_image = torch.randn(B, 3, 1024, 768).to(device)
    pose_image = torch.randn(B, 3, 1024, 768).to(device)
    pose_keypoints = torch.randn(B, 18, 2).to(device) * 2 - 1  # [-1, 1]
    parse_unified25 = torch.randint(0, 25, (B, 1024, 768)).to(device)
    densepose_uv = torch.randn(B, 3, 1024, 768).to(device)
    densepose_conf = torch.rand(B, 1, 1024, 768).to(device)
    
    # Forward pass
    with torch.no_grad():
        body_feat = model(
            agnostic_image=agnostic_image,
            pose_image=pose_image,
            pose_keypoints=pose_keypoints,
            parse_unified25=parse_unified25,
            densepose_uv=densepose_uv,
            densepose_conf=densepose_conf,
        )
    
    print(f"Output shape: {body_feat.shape}")
    assert body_feat.shape == (B, 256, 128, 96), "Output shape mismatch!"
    
    print("✓ BodyConditionEncoder test passed!")
    
    # Test individual branches
    print("\nTesting individual branches...")
    
    # Branch 1: Agnostic
    agnostic_branch = SwinV2AgnosticBranch(pretrained=False).to(device)
    with torch.no_grad():
        agnostic_feat = agnostic_branch(agnostic_image)
    assert agnostic_feat.shape == (B, 256, 128, 96)
    print(f"✓ Agnostic branch: {agnostic_feat.shape}")
    
    # Branch 2: Pose
    pose_branch = PoseBranch().to(device)
    with torch.no_grad():
        pose_feat = pose_branch(pose_image, pose_keypoints)
    assert pose_feat.shape == (B, 128, 128, 96)
    print(f"✓ Pose branch: {pose_feat.shape}")
    
    # Branch 3: Parse
    parse_branch = ParseMapBranch().to(device)
    with torch.no_grad():
        parse_feat = parse_branch(parse_unified25)
    assert parse_feat.shape == (B, 64, 128, 96)
    print(f"✓ Parse branch: {parse_feat.shape}")
    
    # Branch 4: DensePose
    densepose_branch = DensePoseBranch().to(device)
    with torch.no_grad():
        densepose_feat = densepose_branch(densepose_uv, densepose_conf)
    assert densepose_feat.shape == (B, 64, 128, 96)
    print(f"✓ DensePose branch: {densepose_feat.shape}")
    
    print("\n✅ All tests passed!")


if __name__ == '__main__':
    test_body_encoder()
