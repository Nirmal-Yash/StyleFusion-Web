"""
Garment Feature Extractor - Dual-Branch Texture + Shape Encoder

This module extracts compact garment representations from 2 inputs:
1. cloth_image: [B, 3, 1024, 768] RGB garment image (augmented)
2. cloth_mask: [B, 1, 1024, 768] binary mask of garment region

Architecture:
- Texture Branch: ConvNeXt-Tiny pretrained backbone (frozen initially)
- Shape Branch: Lightweight CNN on binary mask
- Both branches → global average pooling → concatenate → z_cloth [B, 512]

Key Features:
- ConvNeXt-Tiny from timm (ImageNet-1K pretrained)
- Shape branch learns coarse garment silhouette
- Output is compact global descriptor (no spatial info)
- Used by IP-Adapter for garment identity conditioning

CRITICAL: This operates on `cloth_image` (augmented), NOT `cloth_image_raw`.
The IP-Adapter uses `cloth_image_raw` (unaugmented) for CLIP encoding.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple
import timm


class ConvNeXtTextureBranch(nn.Module):
    """
    Texture branch: ConvNeXt-Tiny pretrained backbone.
    
    Input: cloth_image [B, 3, 1024, 768] augmented RGB garment
    Output: texture_feat [B, 384] global texture descriptor
    
    Uses timm's convnext_tiny pretrained on ImageNet-1K.
    Extracts features before classification head, applies global pooling.
    """
    
    def __init__(self, pretrained: bool = True, freeze_backbone: bool = False):
        super().__init__()
        
        # Load ConvNeXt-Tiny
        # Default input 224x224, we'll adapt for 1024x768
        self.backbone = timm.create_model(
            'convnext_tiny',
            pretrained=pretrained,
            num_classes=0,  # Remove classification head
            global_pool='avg',  # Global average pooling
        )
        
        # ConvNeXt-Tiny outputs 768 channels after global pooling
        # We reduce to 384 for concatenation with shape features
        self.projection = nn.Sequential(
            nn.Linear(768, 384),
            nn.GELU(),
            nn.Dropout(0.1),
        )
        
        if freeze_backbone:
            for param in self.backbone.parameters():
                param.requires_grad = False
    
    def forward(self, cloth_image: torch.Tensor) -> torch.Tensor:
        """
        Args:
            cloth_image: [B, 3, 1024, 768] RGB garment image (augmented)
        
        Returns:
            texture_feat: [B, 384] global texture descriptor
        """
        B, C, H, W = cloth_image.shape
        assert C == 3 and H == 1024 and W == 768, \
            f"Expected [B,3,1024,768], got {cloth_image.shape}"
        
        # Extract features with global pooling
        feat = self.backbone(cloth_image)  # [B, 768]
        
        # Project to target dimension
        texture_feat = self.projection(feat)  # [B, 384]
        
        assert texture_feat.shape == (B, 384), \
            f"Expected [B,384], got {texture_feat.shape}"
        
        return texture_feat


class LightShapeBranch(nn.Module):
    """
    Shape branch: Lightweight CNN on binary garment mask.
    
    Input: cloth_mask [B, 1, 1024, 768] binary mask {0, 1}
    Output: shape_feat [B, 128] global shape descriptor
    
    Learns coarse garment silhouette representation.
    Much lighter than texture branch (binary input = simpler).
    """
    
    def __init__(self):
        super().__init__()
        
        # Lightweight CNN encoder
        self.encoder = nn.Sequential(
            # 1024x768 -> 512x384
            nn.Conv2d(1, 32, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(4, 32),
            nn.GELU(),
            
            # 512x384 -> 256x192
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            
            # 256x192 -> 128x96
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
            
            # 128x96 -> 64x48
            nn.Conv2d(128, 128, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(16, 128),
            nn.GELU(),
        )
        
        # Global average pooling (implicit in forward)
        # 64x48 spatial -> single vector
        
        # Final projection
        self.projection = nn.Sequential(
            nn.Linear(128, 128),
            nn.GELU(),
            nn.Dropout(0.1),
        )
    
    def forward(self, cloth_mask: torch.Tensor) -> torch.Tensor:
        """
        Args:
            cloth_mask: [B, 1, 1024, 768] binary mask {0.0, 1.0}
        
        Returns:
            shape_feat: [B, 128] global shape descriptor
        """
        B, C, H, W = cloth_mask.shape
        assert C == 1 and H == 1024 and W == 768, \
            f"Expected [B,1,1024,768], got {cloth_mask.shape}"
        
        # Encode to spatial features
        feat = self.encoder(cloth_mask)  # [B, 128, 64, 48]
        
        # Global average pooling
        feat = F.adaptive_avg_pool2d(feat, (1, 1))  # [B, 128, 1, 1]
        feat = feat.view(B, 128)  # [B, 128]
        
        # Project
        shape_feat = self.projection(feat)  # [B, 128]
        
        assert shape_feat.shape == (B, 128), \
            f"Expected [B,128], got {shape_feat.shape}"
        
        return shape_feat


class GarmentFeatureExtractor(nn.Module):
    """
    Complete garment feature extractor combining texture and shape branches.
    
    Inputs:
        - cloth_image: [B, 3, 1024, 768] RGB garment (augmented)
        - cloth_mask: [B, 1, 1024, 768] binary mask
    
    Output:
        - z_cloth: [B, 512] compact garment descriptor
    
    Architecture:
        Texture Branch (ConvNeXt-Tiny): RGB -> 384-dim vector
        Shape Branch (LightCNN): Binary mask -> 128-dim vector
        Concat: 384 + 128 = 512-dim final descriptor
    
    CRITICAL NOTES:
    - This uses `cloth_image` (augmented for training robustness)
    - IP-Adapter uses `cloth_image_raw` (unaugmented for CLIP)
    - Output is global descriptor (no spatial structure)
    - Used for garment identity conditioning in diffusion
    """
    
    def __init__(
        self,
        pretrained_convnext: bool = True,
        freeze_convnext: bool = False,
    ):
        super().__init__()
        
        # Texture branch (384-dim output)
        self.texture_branch = ConvNeXtTextureBranch(
            pretrained=pretrained_convnext,
            freeze_backbone=freeze_convnext,
        )
        
        # Shape branch (128-dim output)
        self.shape_branch = LightShapeBranch()
        
        # No additional fusion - just concatenate
        # Total output: 384 + 128 = 512 dimensions
    
    def forward(
        self,
        cloth_image: torch.Tensor,
        cloth_mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Extract compact garment features.
        
        Args:
            cloth_image: [B, 3, 1024, 768] RGB garment (AUGMENTED)
            cloth_mask: [B, 1, 1024, 768] binary mask
        
        Returns:
            z_cloth: [B, 512] garment descriptor
        """
        B = cloth_image.shape[0]
        
        # Extract texture and shape features
        texture_feat = self.texture_branch(cloth_image)  # [B, 384]
        shape_feat = self.shape_branch(cloth_mask)       # [B, 128]
        
        # Concatenate to form final descriptor
        z_cloth = torch.cat([texture_feat, shape_feat], dim=1)  # [B, 512]
        
        assert z_cloth.shape == (B, 512), \
            f"Expected [B,512], got {z_cloth.shape}"
        
        return z_cloth


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_garment_extractor():
    """Test GarmentFeatureExtractor with synthetic inputs."""
    print("Testing GarmentFeatureExtractor...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create model
    model = GarmentFeatureExtractor(
        pretrained_convnext=False,  # Faster for testing
        freeze_convnext=False,
    ).to(device)
    
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
    
    # Create synthetic inputs
    cloth_image = torch.randn(B, 3, 1024, 768).to(device)
    cloth_mask = torch.rand(B, 1, 1024, 768).to(device)
    cloth_mask = (cloth_mask > 0.5).float()  # Binary mask
    
    # Forward pass
    with torch.no_grad():
        z_cloth = model(cloth_image, cloth_mask)
    
    print(f"Output shape: {z_cloth.shape}")
    assert z_cloth.shape == (B, 512), "Output shape mismatch!"
    
    print("✓ GarmentFeatureExtractor test passed!")
    
    # Test individual branches
    print("\nTesting individual branches...")
    
    # Texture branch
    texture_branch = ConvNeXtTextureBranch(pretrained=False).to(device)
    with torch.no_grad():
        texture_feat = texture_branch(cloth_image)
    assert texture_feat.shape == (B, 384)
    print(f"✓ Texture branch: {texture_feat.shape}")
    
    # Shape branch
    shape_branch = LightShapeBranch().to(device)
    with torch.no_grad():
        shape_feat = shape_branch(cloth_mask)
    assert shape_feat.shape == (B, 128)
    print(f"✓ Shape branch: {shape_feat.shape}")
    
    # Verify concatenation
    z_concat = torch.cat([texture_feat, shape_feat], dim=1)
    assert z_concat.shape == (B, 512)
    print(f"✓ Concatenated features: {z_concat.shape}")
    
    print("\n✅ All tests passed!")


if __name__ == '__main__':
    test_garment_extractor()
