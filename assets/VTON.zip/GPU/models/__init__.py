"""
Models Package - Virtual Try-On System

Exports all model components for easy importing.
"""

from .tps import DifferentiableTPS
from .parse_embedder import ParseMapEmbedder
from .garment_adapter import GarmentLatentAdapter
from .body_encoder import (
    SwinV2AgnosticBranch,
    PoseBranch,
    ParseMapBranch,
    DensePoseBranch,
    CrossAttentionFusion,
    BodyConditionEncoder,
)
from .garment_extractor import (
    ConvNeXtTextureBranch,
    LightShapeBranch,
    GarmentFeatureExtractor,
)
from .warping import (
    PartSegmenter,
    LocalCorrelationVolume,
    WarpFlowPredictor,
    TPSWarper,
    GarmentWarpingModule,
)
from .ip_adapter import (
    ImageProjectionMLP,
    IPAdapterAttnProcessor,
    IPAdapter,
)
from .diffusion_unet import (
    ModifiedDiffusionUNet,
    get_pretrained_vae,
)
from .compositor import (
    RegionCompositor,
    BoundaryMaskComputer,
)
from .tryon_system import VirtualTryOnSystem

__all__ = [
    # TPS
    'DifferentiableTPS',
    
    # Parse embedder
    'ParseMapEmbedder',
    
    # Garment adapter
    'GarmentLatentAdapter',
    
    # Body encoder
    'SwinV2AgnosticBranch',
    'PoseBranch',
    'ParseMapBranch',
    'DensePoseBranch',
    'CrossAttentionFusion',
    'BodyConditionEncoder',
    
    # Garment extractor
    'ConvNeXtTextureBranch',
    'LightShapeBranch',
    'GarmentFeatureExtractor',
    
    # Warping
    'PartSegmenter',
    'LocalCorrelationVolume',
    'WarpFlowPredictor',
    'TPSWarper',
    'GarmentWarpingModule',
    
    # IP-Adapter
    'ImageProjectionMLP',
    'IPAdapterAttnProcessor',
    'IPAdapter',
    
    # Diffusion UNet
    'ModifiedDiffusionUNet',
    'get_pretrained_vae',
    
    # Compositor
    'RegionCompositor',
    'BoundaryMaskComputer',
    
    # Main system
    'VirtualTryOnSystem',
]
