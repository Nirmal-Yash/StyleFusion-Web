"""
Differentiable Thin Plate Spline (TPS) transformation for geometric warping.
Critical features:
- Identity initialization (control points start at regular grid)
- FP32 solve for numerical stability (mandatory)
- Supports batch processing and differentiable grid sampling
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple
import math


class DifferentiableTPS(nn.Module):
    """
    Differentiable Thin Plate Spline (TPS) transformation.
    
    Transforms source image to target via learned control point displacements.
    Uses Radial Basis Function (RBF) interpolation with thin-plate kernel.
    
    Key features:
    - Identity initialization: ctrl_pts_src == ctrl_pts_tgt at epoch 0
    - FP32 solve: torch.linalg.solve always in FP32 for numerical stability
    - Regularization: lambda_reg prevents ill-conditioned system
    - Differentiable: gradients flow through entire transformation
    
    Args:
        n_cp: Number of control points (default 25 for 5×5 grid)
        lambda_reg: Regularization term for K matrix (default 1e-5)
    """
    
    def __init__(self, n_cp: int = 25, lambda_reg: float = 1e-5):
        super().__init__()
        self.n_cp = n_cp
        self.lambda_reg = lambda_reg
        
        # Identity initialization — CRITICAL FOR STABILITY
        # Control points initialized to regular 5×5 grid in [-0.8, 0.8]
        # Source and target start identical → identity warp at epoch 0
        grid_size = int(math.sqrt(n_cp))
        assert grid_size * grid_size == n_cp, f"n_cp must be perfect square, got {n_cp}"
        
        lin = torch.linspace(-0.8, 0.8, grid_size)
        gy, gx = torch.meshgrid(lin, lin, indexing='ij')
        identity_ctrl_pts = torch.stack([gx.flatten(), gy.flatten()], dim=-1)  # [25,2]
        
        self.register_buffer('identity_ctrl_pts', identity_ctrl_pts)
    
    def forward(
        self,
        ctrl_pts_src: torch.Tensor,  # [B, n_cp, 2]
        ctrl_pts_tgt: torch.Tensor,  # [B, n_cp, 2]
        output_size: Tuple[int, int]  # (H, W)
    ) -> torch.Tensor:
        """
        Compute TPS transformation from source to target control points.
        
        Args:
            ctrl_pts_src: Source control points [B, n_cp, 2] in normalized coords [-1,1]
            ctrl_pts_tgt: Target control points [B, n_cp, 2] in normalized coords [-1,1]
            output_size: (Height, Width) of output grid
        
        Returns:
            grid: Sampling grid [B, H, W, 2] for F.grid_sample
        """
        B = ctrl_pts_src.shape[0]
        H, W = output_size
        device = ctrl_pts_src.device
        dtype = ctrl_pts_src.dtype
        
        # ═══════════════════════════════════════════════════════════════════════
        # Step 1: Build RBF kernel matrix K [B, n_cp, n_cp]
        # ═══════════════════════════════════════════════════════════════════════
        # K_ij = ||p_i - p_j||^2 * log(||p_i - p_j||)
        diff = ctrl_pts_src.unsqueeze(2) - ctrl_pts_src.unsqueeze(1)  # [B, n_cp, n_cp, 2]
        dist = diff.norm(dim=-1)  # [B, n_cp, n_cp]
        K = dist ** 2 * torch.log(dist + 1e-8)  # [B, n_cp, n_cp]
        
        # ═══════════════════════════════════════════════════════════════════════
        # Step 2: Build polynomial matrix P [B, n_cp, 3]
        # ═══════════════════════════════════════════════════════════════════════
        # P = [1, x, y] for affine component
        ones = torch.ones(B, self.n_cp, 1, device=device, dtype=dtype)
        P = torch.cat([ones, ctrl_pts_src], dim=-1)  # [B, n_cp, 3]
        
        # ═══════════════════════════════════════════════════════════════════════
        # Step 3: Build system matrix L [B, n_cp+3, n_cp+3]
        # ═══════════════════════════════════════════════════════════════════════
        # L = [ K   P  ]
        #     [ P^T 0  ]
        zeros33 = torch.zeros(B, 3, 3, device=device, dtype=dtype)
        top = torch.cat([K, P], dim=-1)  # [B, n_cp, n_cp+3]
        bottom = torch.cat([P.transpose(1, 2), zeros33], dim=-1)  # [B, 3, n_cp+3]
        L = torch.cat([top, bottom], dim=1)  # [B, n_cp+3, n_cp+3]
        
        # ═══════════════════════════════════════════════════════════════════════
        # Step 4: Regularize and solve (FP32 MANDATORY)
        # ═══════════════════════════════════════════════════════════════════════
        # Add regularization to K block to prevent singular matrix
        I_ncp = torch.eye(self.n_cp, device=device, dtype=dtype).unsqueeze(0)  # [1, n_cp, n_cp]
        L_reg = L.clone()
        L_reg[:, :self.n_cp, :self.n_cp] += self.lambda_reg * I_ncp
        
        # Right-hand side: target points + zero padding
        Y = torch.cat([
            ctrl_pts_tgt,  # [B, n_cp, 2]
            torch.zeros(B, 3, 2, device=device, dtype=dtype)
        ], dim=1)  # [B, n_cp+3, 2]
        
        # CRITICAL: Solve in FP32 for numerical stability
        # torch.linalg.solve can fail in BF16/FP16 with ill-conditioned matrices
        coeffs = torch.linalg.solve(L_reg.float(), Y.float()).to(dtype)  # [B, n_cp+3, 2]
        
        # ═══════════════════════════════════════════════════════════════════════
        # Step 5: Evaluate TPS at all output grid points
        # ═══════════════════════════════════════════════════════════════════════
        # Create dense grid in normalized coordinates [-1, 1]
        gy, gx = torch.meshgrid(
            torch.linspace(-1, 1, H, device=device, dtype=dtype),
            torch.linspace(-1, 1, W, device=device, dtype=dtype),
            indexing='ij'
        )
        grid_pts = torch.stack([gx.flatten(), gy.flatten()], dim=1)  # [H*W, 2]
        grid_pts = grid_pts.unsqueeze(0).expand(B, -1, -1)  # [B, H*W, 2]
        
        # Compute RBF basis for all grid points
        diff2 = grid_pts.unsqueeze(2) - ctrl_pts_src.unsqueeze(1)  # [B, H*W, n_cp, 2]
        dist2 = diff2.norm(dim=-1)  # [B, H*W, n_cp]
        phi = dist2 ** 2 * torch.log(dist2 + 1e-8)  # [B, H*W, n_cp]
        
        # Polynomial basis
        ones2 = torch.ones(B, H * W, 1, device=device, dtype=dtype)
        P2 = torch.cat([ones2, grid_pts], dim=-1)  # [B, H*W, 3]
        
        # Full basis
        basis = torch.cat([phi, P2], dim=-1)  # [B, H*W, n_cp+3]
        
        # Apply transformation coefficients
        warped_pts = torch.bmm(basis, coeffs)  # [B, H*W, 2]
        grid = warped_pts.view(B, H, W, 2)  # [B, H, W, 2]
        
        # Clamp to prevent extreme extrapolation artifacts
        grid = grid.clamp(-1.1, 1.1)
        
        return grid
    
    def identity_penalty(
        self,
        ctrl_pts_src: torch.Tensor,  # [B, n_cp, 2]
        ctrl_pts_tgt: torch.Tensor   # [B, n_cp, 2]
    ) -> torch.Tensor:
        """
        L2 penalty on displacement from identity.
        
        High early in training (lambda=5.0), linearly decayed to 0 by epoch 20.
        Anchors TPS when correlation features are still noisy.
        
        Args:
            ctrl_pts_src: Source control points
            ctrl_pts_tgt: Target control points
        
        Returns:
            Scalar tensor: Mean squared displacement from identity
        """
        displacement = ctrl_pts_tgt - ctrl_pts_src
        return (displacement ** 2).mean()


def test_tps_identity():
    """
    Test that TPS produces identity transformation when ctrl_pts_src == ctrl_pts_tgt.
    """
    tps = DifferentiableTPS(n_cp=25)
    
    # Create batch with identity control points
    B = 2
    ctrl_pts = tps.identity_ctrl_pts.unsqueeze(0).expand(B, -1, -1)  # [B, 25, 2]
    
    # Compute grid
    grid = tps(ctrl_pts, ctrl_pts, output_size=(128, 96))
    
    # Expected: identity grid (grid[i,j] ≈ normalized coords of (i,j))
    H, W = 128, 96
    gy, gx = torch.meshgrid(
        torch.linspace(-1, 1, H),
        torch.linspace(-1, 1, W),
        indexing='ij'
    )
    expected_grid = torch.stack([gx, gy], dim=-1).unsqueeze(0).expand(B, -1, -1, -1)
    
    # Check approximate equality (allows small numerical error)
    max_error = (grid - expected_grid).abs().max().item()
    print(f"TPS Identity Test: max_error = {max_error:.6f}")
    assert max_error < 0.01, f"Identity grid error too large: {max_error}"
    print("TPS Identity Test: PASSED")


if __name__ == "__main__":
    test_tps_identity()
