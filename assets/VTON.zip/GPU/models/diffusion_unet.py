"""
Modified Diffusion UNet for Virtual Try-On

This module adapts Stable Diffusion 1.5 Inpainting UNet for try-on task:

1. Load pretrained SD 1.5 inpainting UNet (9-channel input)
2. Modify conv_in: 9 channels → 17 channels
3. Preserve pretrained weights for original 9 channels
4. Initialize new 8 channels (body + garment latents) near zero
5. Inject IP-Adapter processors into all cross-attention layers

Input Channels (17 total):
    0-3: Noisy latent x_t (4 channels)
    4-7: Agnostic latent (4 channels, from body)
    8: Binary inpainting mask (1 channel)
    9-12: Body condition latent (4 channels, from BodyEncoder)
    13-16: Garment latent (4 channels, from GarmentAdapter)

Architecture:
    - Base: SD 1.5 inpainting UNet (stabilityai/stable-diffusion-inpainting)
    - Modified conv_in: Conv2d(17, 320, kernel_size=3, padding=1)
    - IP-Adapter injected into cross-attention layers
    - Outputs predicted noise ε_θ

Key Features:
- Pretrained weights preserved for channels 0-8
- New channels initialized with small random values
- IP-Adapter cross-attention for garment identity
- Text cross-attention for semantic guidance
- Timestep conditioning via sinusoidal embeddings
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional
from diffusers import UNet2DConditionModel

from .ip_adapter import IPAdapterAttnProcessor


class ModifiedDiffusionUNet(nn.Module):
    """
    Modified SD 1.5 UNet with 17-channel input and IP-Adapter injection.
    
    Inputs:
        - noisy_latent: [B, 4, 128, 96] noised x_t
        - timesteps: [B] timestep values
        - agnostic_latent: [B, 4, 128, 96] encoded agnostic image
        - inpaint_mask: [B, 1, 128, 96] binary mask (garment region)
        - body_latent: [B, 4, 128, 96] encoded body conditions
        - garment_latent: [B, 4, 128, 96] adapted warped garment
        - encoder_hidden_states: [B, 77, 768] text embeddings (optional)
        - ip_hidden_states: [B, 16, 768] image prompt tokens (optional)
        - ip_scale: float, IP-Adapter strength
    
    Output:
        - noise_pred: [B, 4, 128, 96] predicted noise ε_θ
    
    Architecture modifications:
        1. conv_in: 9ch → 17ch (8 new channels for body + garment)
        2. Cross-attention: IPAdapterAttnProcessor injected
        3. All other layers: unchanged from SD 1.5
    """
    
    def __init__(
        self,
        pretrained_model_name: str = "stabilityai/stable-diffusion-inpainting",
        freeze_pretrained: bool = False,
    ):
        super().__init__()
        
        # Load pretrained SD 1.5 inpainting UNet
        print(f"Loading pretrained UNet from {pretrained_model_name}...")
        self.unet = UNet2DConditionModel.from_pretrained(
            pretrained_model_name,
            subfolder="unet",
        )
        
        # Store original conv_in for reference
        original_conv_in = self.unet.conv_in
        
        # Create new conv_in with 17 input channels
        new_conv_in = nn.Conv2d(
            in_channels=17,  # 4 (noisy) + 4 (agnostic) + 1 (mask) + 4 (body) + 4 (garment)
            out_channels=original_conv_in.out_channels,  # 320
            kernel_size=original_conv_in.kernel_size,
            stride=original_conv_in.stride,
            padding=original_conv_in.padding,
        )
        
        # Initialize new conv_in weights
        with torch.no_grad():
            # Copy pretrained weights for first 9 channels
            new_conv_in.weight[:, :9, :, :] = original_conv_in.weight
            
            # Initialize new 8 channels with small random values
            # This ensures minimal impact at start of training
            nn.init.normal_(new_conv_in.weight[:, 9:, :, :], mean=0.0, std=0.01)
            
            # Copy bias
            if original_conv_in.bias is not None:
                new_conv_in.bias = original_conv_in.bias
        
        # Replace conv_in
        self.unet.conv_in = new_conv_in
        
        # Inject IP-Adapter processors into cross-attention layers
        self._inject_ip_adapter_processors()
        
        # Optionally freeze pretrained weights
        if freeze_pretrained:
            for name, param in self.unet.named_parameters():
                # Only freeze if NOT part of new channels or IP-Adapter
                if 'conv_in.weight' in name:
                    # Create a mask to freeze only first 9 channels
                    param.requires_grad = True  # We'll handle freezing via hook
                elif 'to_k_ip' in name or 'to_v_ip' in name:
                    param.requires_grad = True  # IP-Adapter always trainable
                else:
                    param.requires_grad = False  # Freeze rest
        
        print("✓ UNet modified: conv_in 9ch → 17ch, IP-Adapter injected")
    
    def _inject_ip_adapter_processors(self):
        """
        Replace default attention processors with IPAdapterAttnProcessor
        in all cross-attention layers.
        """
        # Iterate through all attention layers in UNet
        attn_procs = {}
        
        for name, module in self.unet.named_modules():
            if hasattr(module, 'processor') and 'attn2' in name:  # Cross-attention layers
                # Get hidden size for this layer
                if hasattr(module, 'to_q'):
                    hidden_size = module.to_q.out_features
                else:
                    continue
                
                # Create IP-Adapter processor
                attn_procs[name] = IPAdapterAttnProcessor(
                    hidden_size=hidden_size,
                    cross_attention_dim=768,  # SD 1.5 cross-attention dim
                )
        
        # Set processors
        for name, proc in attn_procs.items():
            # Navigate to the module
            parts = name.split('.')
            module = self.unet
            for part in parts[:-1]:
                module = getattr(module, part)
            
            # Set the processor
            final_module = getattr(module, parts[-1])
            if hasattr(final_module, 'set_processor'):
                final_module.set_processor(proc)
            else:
                final_module.processor = proc
        
        print(f"✓ Injected IP-Adapter into {len(attn_procs)} cross-attention layers")
    
    def forward(
        self,
        noisy_latent: torch.Tensor,
        timesteps: torch.Tensor,
        agnostic_latent: torch.Tensor,
        inpaint_mask: torch.Tensor,
        body_latent: torch.Tensor,
        garment_latent: torch.Tensor,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        ip_hidden_states=None,
        ip_scale: float = 1.0,
    ) -> torch.Tensor:
        """
        Forward pass through modified UNet.
        
        17-channel input composition per spec:
            Ch 0-3:   noisy_latent [B,4,128,96]
            Ch 4-7:   masked_person_latent [B,4,128,96]
            Ch 8:     agnostic_mask_ds [B,1,128,96]
            Ch 9-12:  cloth_latent_adapted [B,4,128,96]
            Ch 13:    cloth_mask_warped_ds [B,1,128,96]  }
            Ch 14-16: parse_embedded [B,3,128,96]        } combined in garment_latent [B,4]
        
        Args:
            noisy_latent: [B, 4, 128, 96] x_t
            timesteps: [B] timestep indices
            agnostic_latent: [B, 4, 128, 96] encoded masked person image
            inpaint_mask: [B, 1, 128, 96] binary agnostic mask
            body_latent: [B, 4, 128, 96] cloth_latent_adapted
            garment_latent: [B, 4, 128, 96] concat(cloth_mask_warped_ds, parse_embedded)
            encoder_hidden_states: [B, 77, 768] text embeddings
            ip_hidden_states: tuple(ip_keys, ip_values) each [B, 16, 768], or single tensor
            ip_scale: float, IP-Adapter strength
        
        Returns:
            noise_pred: [B, 4, 128, 96] predicted noise
        """
        B = noisy_latent.shape[0]
        
        # Validate shapes
        assert noisy_latent.shape == (B, 4, 128, 96)
        assert agnostic_latent.shape == (B, 4, 128, 96)
        assert inpaint_mask.shape == (B, 1, 128, 96)
        assert body_latent.shape == (B, 4, 128, 96)
        assert garment_latent.shape == (B, 4, 128, 96)
        
        # Concatenate all conditioning inputs (17 channels total)
        unet_input = torch.cat([
            noisy_latent,      # Channels 0-3:   noise
            agnostic_latent,   # Channels 4-7:   masked person latent
            inpaint_mask,      # Channel  8:     agnostic mask
            body_latent,       # Channels 9-12:  cloth latent adapted
            garment_latent,    # Channels 13-16: cloth mask + parse embedded
        ], dim=1)  # [B, 17, 128, 96]
        
        # Prepare kwargs for UNet forward
        # Note: diffusers UNet expects specific argument names
        forward_kwargs = {
            'encoder_hidden_states': encoder_hidden_states,
        }
        
        # If using IP-Adapter, pass ip_keys and ip_values to attention processors
        if ip_hidden_states is not None:
            # Unpack tuple (ip_keys, ip_values) from tryon_system
            if isinstance(ip_hidden_states, tuple):
                ip_keys, ip_values = ip_hidden_states
            else:
                # Backward compat: single tensor used for both K and V
                ip_keys = ip_hidden_states
                ip_values = ip_hidden_states
            
            for name, module in self.unet.named_modules():
                if hasattr(module, 'processor') and isinstance(module.processor, IPAdapterAttnProcessor):
                    module.processor._ip_keys = ip_keys
                    module.processor._ip_values = ip_values
                    module.processor._ip_scale = ip_scale
        
        # Forward through UNet
        noise_pred = self.unet(
            sample=unet_input,
            timestep=timesteps,
            **forward_kwargs,
        ).sample  # [B, 4, 128, 96]
        
        # Clean up temporary state
        if ip_hidden_states is not None:
            for name, module in self.unet.named_modules():
                if hasattr(module, 'processor') and isinstance(module.processor, IPAdapterAttnProcessor):
                    for attr in ('_ip_keys', '_ip_values', '_ip_scale'):
                        if hasattr(module.processor, attr):
                            delattr(module.processor, attr)
        
        assert noise_pred.shape == (B, 4, 128, 96), \
            f"Expected [B,4,128,96], got {noise_pred.shape}"
        
        return noise_pred


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_pretrained_vae():
    """
    Load pretrained VAE from Stable Diffusion 1.5.
    Used for encoding/decoding images to/from latent space.
    
    Returns:
        vae: AutoencoderKL model
    """
    from diffusers import AutoencoderKL
    
    vae = AutoencoderKL.from_pretrained(
        "stabilityai/stable-diffusion-inpainting",
        subfolder="vae",
    )
    
    return vae


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_diffusion_unet():
    """Test ModifiedDiffusionUNet with synthetic inputs."""
    print("Testing ModifiedDiffusionUNet...")
    print("WARNING: This will download ~3.5GB of pretrained weights.")
    print("Press Ctrl+C to cancel, or wait to continue...")
    
    import time
    time.sleep(3)
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create model
    model = ModifiedDiffusionUNet(
        pretrained_model_name="stabilityai/stable-diffusion-inpainting",
        freeze_pretrained=False,
    ).to(device)
    
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Trainable parameters: {trainable_params / 1e6:.2f}M")
    
    # Create synthetic inputs
    noisy_latent = torch.randn(B, 4, 128, 96).to(device)
    timesteps = torch.randint(0, 1000, (B,)).to(device)
    agnostic_latent = torch.randn(B, 4, 128, 96).to(device)
    inpaint_mask = torch.rand(B, 1, 128, 96).to(device)
    inpaint_mask = (inpaint_mask > 0.5).float()
    body_latent = torch.randn(B, 4, 128, 96).to(device)
    garment_latent = torch.randn(B, 4, 128, 96).to(device)
    encoder_hidden_states = torch.randn(B, 77, 768).to(device)
    ip_hidden_states = torch.randn(B, 16, 768).to(device)
    
    # Forward pass
    print("\nRunning forward pass...")
    with torch.no_grad():
        noise_pred = model(
            noisy_latent=noisy_latent,
            timesteps=timesteps,
            agnostic_latent=agnostic_latent,
            inpaint_mask=inpaint_mask,
            body_latent=body_latent,
            garment_latent=garment_latent,
            encoder_hidden_states=encoder_hidden_states,
            ip_hidden_states=ip_hidden_states,
            ip_scale=0.5,
        )
    
    print(f"Output shape: {noise_pred.shape}")
    assert noise_pred.shape == (B, 4, 128, 96), "Output shape mismatch!"
    
    print("\n✓ ModifiedDiffusionUNet test passed!")
    
    # Test VAE loading
    print("\nTesting VAE loading...")
    vae = get_pretrained_vae().to(device)
    print(f"✓ VAE loaded: {vae.__class__.__name__}")
    
    # Test encoding/decoding
    test_image = torch.randn(B, 3, 1024, 768).to(device)
    with torch.no_grad():
        latent = vae.encode(test_image).latent_dist.sample() * 0.18215
        recon = vae.decode(latent / 0.18215).sample
    
    print(f"  Image → Latent: {test_image.shape} → {latent.shape}")
    print(f"  Latent → Image: {latent.shape} → {recon.shape}")
    
    print("\n✅ All tests passed!")


if __name__ == '__main__':
    test_diffusion_unet()
