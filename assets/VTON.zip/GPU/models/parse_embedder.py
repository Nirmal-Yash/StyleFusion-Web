"""
Parse Map Embedder - Converts semantic segmentation to latent features.
Processes UNIFIED-25 class labels into continuous feature maps.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ParseMapEmbedder(nn.Module):
    """
    Embeds semantic parse maps (UNIFIED-25) into continuous feature space.
    
    Architecture:
    - nn.Embedding(25, 64): Class ID → dense embedding
    - Stride-8 CNN: Downsample to latent resolution [B, 3, 128, 96]
    - Channel attention: Weight classes by batch frequency
    
    Input: parse_unified25 [B, 1, 1024, 768] int64, values [0, 24]
    Output: parse_embedded [B, 3, 128, 96] float32
    """
    
    def __init__(self, vocab_size: int = 25, embed_dim: int = 64, output_channels: int = 3):
        super().__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        
        # Embedding layer: class ID → dense vector
        # Init with small normal distribution
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        nn.init.normal_(self.embedding.weight, mean=0.0, std=0.01)
        
        # Stride-8 CNN: [B, embed_dim, 1024, 768] → [B, 3, 128, 96]
        self.encoder = nn.Sequential(
            # Stage 1: 1024×768 → 512×384
            nn.Conv2d(embed_dim, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            
            # Stage 2: 512×384 → 256×192
            nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(8, 64),
            nn.GELU(),
            
            # Stage 3: 256×192 → 128×96
            nn.Conv2d(64, 32, kernel_size=4, stride=2, padding=1),
            nn.GroupNorm(4, 32),
            nn.GELU(),
            
            # Final: reduce to output channels
            nn.Conv2d(32, output_channels, kernel_size=1),
        )
        
        # Channel attention gate (computed per batch)
        # Weights classes by their frequency in the batch
        self.channel_attention = nn.Linear(vocab_size, vocab_size)
        nn.init.constant_(self.channel_attention.weight, 1.0 / vocab_size)
        nn.init.constant_(self.channel_attention.bias, 0.0)
    
    def forward(self, parse_map: torch.Tensor) -> torch.Tensor:
        """
        Args:
            parse_map: [B, 1, H, W] int64, values in [0, vocab_size)
        
        Returns:
            parse_embedded: [B, output_channels, H_latent, W_latent] float32
        """
        B, _, H, W = parse_map.shape
        
        assert parse_map.max() < self.vocab_size, (
            f"Parse map max value {parse_map.max().item()} >= vocab_size {self.vocab_size}"
        )
        assert parse_map.min() >= 0, f"Parse map has negative values: {parse_map.min().item()}"
        
        # Squeeze channel dimension and clamp for safety
        parse_map = parse_map.squeeze(1).long().clamp(0, self.vocab_size - 1)  # [B, H, W]
        
        # Compute class frequencies for channel attention
        class_freqs = torch.zeros(B, self.vocab_size, device=parse_map.device)
        for b in range(B):
            for c in range(self.vocab_size):
                class_freqs[b, c] = (parse_map[b] == c).float().mean()
        
        # Apply channel attention gate
        attention_weights = torch.sigmoid(self.channel_attention(class_freqs))  # [B, vocab_size]
        
        # Embed parse map
        embedded = self.embedding(parse_map)  # [B, H, W, embed_dim]
        embedded = embedded.permute(0, 3, 1, 2)  # [B, embed_dim, H, W]
        
        # Apply channel attention (broadcast over spatial dimensions)
        attention_weights = attention_weights.unsqueeze(-1).unsqueeze(-1)  # [B, vocab_size, 1, 1]
        
        # Compute weighted embedding (attention acts on class dimension indirectly)
        # For each pixel, its embedding is weighted by the attention of its class
        weighted_embedded = embedded.clone()
        for c in range(self.vocab_size):
            mask = (parse_map == c).unsqueeze(1).float()  # [B, 1, H, W]
            weighted_embedded = weighted_embedded + mask * (attention_weights[:, c:c+1] - 1.0) * embedded
        
        # Encode to latent resolution
        output = self.encoder(weighted_embedded)
        
        # Shape assertion
        assert output.shape[1] == 3, f"Expected 3 output channels, got {output.shape[1]}"
        assert output.shape[2] == 128 and output.shape[3] == 96, (
            f"Expected latent size [128, 96], got [{output.shape[2]}, {output.shape[3]}]"
        )
        
        return output


if __name__ == "__main__":
    # Test parse embedder
    embedder = ParseMapEmbedder(vocab_size=25, embed_dim=64, output_channels=3)
    
    # Create synthetic parse map
    B = 2
    parse_map = torch.randint(0, 25, (B, 1, 1024, 768))
    
    # Forward pass
    output = embedder(parse_map)
    
    print(f"Input shape: {parse_map.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Expected shape: [2, 3, 128, 96]")
    
    assert output.shape == (B, 3, 128, 96), f"Shape mismatch: {output.shape}"
    print("Parse embedder test: PASSED")
