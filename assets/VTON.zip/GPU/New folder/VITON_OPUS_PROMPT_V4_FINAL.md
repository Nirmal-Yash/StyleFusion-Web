# VITON-HD Virtual Try-On System — Claude Opus 4.6 Prompt (v4.0 FINAL)
## Extended: Multi-Dataset | DensePose | Indian Textiles | Bottomwear | Operational Completeness
### Supersedes v3.0 — All Critical and High-Priority Issues Resolved + 5 Operational Extensions

---

## HOW TO USE

Copy everything between `---PROMPT START---` and `---PROMPT END---` and paste directly into Claude Opus 4.6.
If Opus reaches a context limit, it will output `=== CONTINUATION BREAK ===` and continue in the next response.

---

---PROMPT START---

You are a world-class deep learning engineer and computer vision researcher with expert-level mastery of latent diffusion models, geometric warping, adapter-based conditioning, multi-dataset training, and virtual try-on systems. You have deeply studied VITON-HD, HR-VITON, GP-VTON, StableVITON, IDM-VTON, DCI-VTON, CatVTON, GarDiff, FIA-VTON, Re-CatVTON, and DressCode. You understand not only what each architecture proposes, but **why each design decision was made, what it trades off, and how failures manifest in practice**.

Your task is to architect and implement — entirely in original code — a **production-ready, commercially deployable, high-accuracy virtual try-on system** that supports:
- **VITON-HD dataset** (upper-body garments, 1024×768)
- **DressCode dataset** (upper-body, lower-body, full-body garments, 1024×768)
- **Indian textile garment categories** (kurta, saree, salwar kameez, lehenga, dupatta)
- **Bottomwear and outfit-pair try-on**

---

## ABSOLUTE CONSTRAINTS

1. **NO copied code** from any public repository. All code is original.
2. **NO exact module names** from official implementations.
3. Dataset is **already preprocessed and on disk**. Do NOT include OpenPose inference or human parsing inference runtime code. All dataset artifacts are ready. A separate `PREPROCESSING_SPEC.md` document is required as a deliverable.
4. Every function must be **complete and runnable** — no `pass` stubs, no `TODO` in production paths.
5. Framework: **PyTorch 2.x + PyTorch Lightning 2.x**.
6. Hardware: **NVIDIA A100 (80GB VRAM)**.
7. Deliver a **Jupyter Notebook (.ipynb)** as primary execution interface.
8. All dataset loading must include **JSON schema validation, class histogram verification, and tensor dimension asserts** before training begins.

---

## PART 1: ARCHITECTURAL PARADIGM (INHERITED FROM v3.0, CONFIRMED)

### Paradigm: Latent Diffusion (SD v1.5 Inpainting Backbone)

Performance evidence (VITON-HD benchmark):
```
Method           Paradigm    FID ↓   SSIM ↑   LPIPS ↓
GP-VTON          GAN          6.43   0.898    0.105   ← best GAN
IDM-VTON         Diffusion    6.29   0.870    0.102
GarDiff          Diffusion    6.02   0.912    0.036
Re-CatVTON       Diffusion    4.44   0.918    0.041
FIA-VTON (2025)  Diffusion    4.69   0.913    0.047
```

No GAN loss. No SPADE. No sequential freezing. Joint training with LR annealing.
Full rationale in v3.0 is preserved and not repeated here — implement exactly as specified.

---

## PART 2: COMPLETE DATASET MODALITY SPECIFICATION

### 2.1 VITON-HD Dataset (Full 11-Modality Specification)

Previous versions specified 8 modalities. The complete VITON-HD dataset contains **11 modalities**. All must be loaded.

```
viton_hd/
├── train/
│   ├── image/                  # [MODALITY 1]  Person RGB, 1024×768, PNG/JPG
│   ├── image-parse-v3/         # [MODALITY 2]  20-class LIP parse map, PNG (palette)
│   ├── openpose-img/           # [MODALITY 3]  OpenPose rendered heatmap, PNG
│   ├── openpose-json/          # [MODALITY 4]  OpenPose JSON: pose_keypoints_2d (18 kps)
│   ├── cloth/                  # [MODALITY 5]  Garment RGB, 1024×768, PNG/JPG
│   ├── cloth-mask/             # [MODALITY 6]  Binary garment mask, PNG
│   ├── agnostic-v3.2/          # [MODALITY 7]  Cloth-agnostic person image, PNG
│   ├── agnostic-mask/          # [MODALITY 8]  Binary agnostic region mask, PNG
│   ├── image-densepose/        # [MODALITY 9]  DensePose UV map (IUV image), PNG
│   ├── warp-cloth/             # [MODALITY 10] Pre-warped cloth (provided in dataset), PNG
│   └── warp-cloth-mask/        # [MODALITY 11] Pre-warped cloth mask, PNG
└── test/
    └── (identical structure)
```

**Modality 9 — DensePose IUV Maps:**
- Format: 3-channel PNG where R=part index (0–24), G=U coordinate (0–255), B=V coordinate (0–255).
- 24 body surface parts defined by DensePose SMPL surface parameterization.
- **Role in architecture:** DensePose provides dense surface correspondence between garment and body, enabling the `PartAwareWarpingModule` to learn physically grounded part-to-body mappings rather than purely appearance-based correlation. The IUV map is used as an additional conditioning channel in the `BodyConditionEncoder` and as a supervision signal for the part segmenter pseudo-labels.
- **Loading:** Read as uint8 [H, W, 3], normalize R channel to float [0, 1] (24-part indices), normalize G and B to float [0, 1]. Output tensor: `densepose_iuv` [3, H, W] float32 in [0, 1].

**Modality 10–11 — Pre-Warped Cloth:**
- Pre-warped cloth and mask provided in the dataset are computed by the VITON-HD authors using their GMM.
- **Role:** Used as a warm-start initialization for the `PartAwareWarpingModule` during epoch 1 only. Specifically, the pre-warped cloth latent is used to initialize the UNet conditioning before the learned warping produces quality output.
- Also used as a secondary warp supervision signal: `L_warp_pretrain = L1(cloth_warped, warp_cloth_gt)` with weight decaying to 0 by epoch 10.

### 2.2 DressCode Dataset (Full Modality Specification)

DressCode (Morelli et al., 2022) covers **three garment categories**: upper-body, lower-body (bottomwear), and dresses (full-body). Dataset structure:

```
dresscode/
├── upper_body/
│   ├── images/                 # [MODALITY 1]  Person RGB, 1024×768
│   ├── cloth/                  # [MODALITY 2]  Garment RGB, 1024×768
│   ├── cloth_mask/             # [MODALITY 3]  Binary garment mask
│   ├── dense/                  # [MODALITY 4]  DensePose IUV maps
│   ├── keypoints/              # [MODALITY 5]  OpenPose JSON (same format as VITON-HD)
│   ├── label_maps/             # [MODALITY 6]  ATR-18 semantic parse maps (18-class, NOT LIP-20)
│   ├── skeletons/              # [MODALITY 7]  OpenPose rendered skeleton images
│   └── pairs.txt               # [FILE] train/test pair definitions (person_id cloth_id)
├── lower_body/
│   └── (same structure as upper_body/)
├── dresses/
│   └── (same structure as upper_body/)
└── train_pairs.txt             # Global pair list with category column
    test_pairs.txt
```

**DressCode-specific detail:**
- `pairs.txt` format: `person_filename.jpg cloth_filename.jpg` (one pair per line, tab-separated).
- `label_maps/` uses **ATR-18** parsing scheme (18 classes, different from LIP-20).
- **ATR-18 to LIP-20 mapping** must be implemented for cross-dataset compatibility (see Part 3).
- DressCode does NOT provide `agnostic-v3.2` or `agnostic-mask` — these must be **derived at load time** from the label map and person image:
  - Agnostic mask = union of garment-region classes from ATR parse (see class definitions in Part 3).
  - Agnostic image = person image with agnostic mask zeroed out.

### 2.3 Indian Textile Dataset (Custom Extension)

For Indian textile garment support, the system must be extensible to a custom dataset following this structure:

```
indian_textiles/
├── images/                     # Person RGB images (any resolution, resized to 1024×768)
├── cloth/                      # Garment RGB images
├── cloth_mask/                 # Binary garment masks
├── label_maps/                 # Semantic parse maps (INDIAN-22 scheme, see Part 5)
├── keypoints/                  # OpenPose JSON (same format)
├── dense/                      # DensePose IUV maps
├── garment_meta/               # [EXTENSION] Per-garment JSON metadata
│   └── {cloth_id}_meta.json    # Fabric type, garment category, coverage
└── pairs.txt
```

`{cloth_id}_meta.json` schema:
```json
{
  "garment_id": "string",
  "category": "kurta|saree|salwar_kameez|lehenga|dupatta|western_top|western_bottom|dress",
  "subcategory": "anarkali|straight|a_line|...",
  "fabric": "cotton|silk|chiffon|georgette|linen|khadi|chanderi|...",
  "pattern": "solid|stripes|floral|geometric|embroidered|printed|block_print|...",
  "coverage": "upper|lower|full|dupatta",
  "has_dupatta": true,
  "paired_garment_id": "string|null",
  "try_on_region": [top_y_frac, bottom_y_frac, left_x_frac, right_x_frac]
}
```

---

## PART 3: MULTI-DATASET SEMANTIC LABEL UNIFICATION

### 3.1 The Cross-Dataset Label Problem

VITON-HD uses **LIP-20** (20 classes). DressCode uses **ATR-18** (18 classes). The Indian textile extension uses **INDIAN-22** (22 classes, defined below). The model cannot receive inconsistent label spaces — it must operate on a unified internal label space.

**Solution:** Define a **UNIFIED-25** internal label space. All dataset-specific schemes are mapped to UNIFIED-25 at load time. The model always receives UNIFIED-25 labels. The `ParseMapEmbedder` uses `vocab_size=25`.

### 3.2 LIP-20 Class Definitions
```
0:  Background          10: Left-arm
1:  Hat                 11: Right-arm
2:  Hair                12: Left-leg
3:  Glove               13: Right-leg
4:  Sunglasses          14: Left-shoe
5:  Upper-cloth         15: Right-shoe
6:  Dress               16: Socks
7:  Coat                17: Neck/Scarf
8:  Socks (dup)         18: Skirt
9:  Pants               19: Face
```

### 3.3 ATR-18 Class Definitions
```
0:  Background          9:  Left-arm
1:  Hat                 10: Right-arm
2:  Hair                11: Left-leg
3:  Sunglasses          12: Right-leg
4:  Upper-cloth         13: Left-shoe
5:  Skirt               14: Right-shoe
6:  Pants               15: Left-bag
7:  Dress               16: Right-bag
8:  Belt                17: Face
```

### 3.4 INDIAN-22 Class Definitions (Custom, for Indian Textiles)
```
0:  Background          11: Left-leg
1:  Hair                12: Right-leg
2:  Face                13: Left-shoe
3:  Neck                14: Right-shoe
4:  Upper-cloth         15: Dupatta
5:  Kurta               16: Lehenga-skirt
6:  Salwar              17: Belt
7:  Saree-drape         18: Jewelry-neck
8:  Pants               19: Left-arm
9:  Skirt               20: Right-arm
10: Dress               21: Bag
```

### 3.5 UNIFIED-25 Internal Label Space
```
0:  Background          13: Left-leg
1:  Hat                 14: Right-leg
2:  Hair                15: Left-shoe
3:  Face                16: Right-shoe
4:  Neck/Scarf          17: Socks
5:  Upper-cloth         18: Belt/Waistband
6:  Kurta               19: Skirt
7:  Dress               20: Saree-drape
8:  Dupatta             21: Lehenga-skirt
9:  Salwar/Pants        22: Left-bag
10: Sunglasses          23: Right-bag
11: Jewelry-neck        24: Glove
12: Left-arm
```

### 3.6 Label Mapping Implementation

Implement `utils/label_mapper.py`:

```python
# LIP20_TO_UNIFIED25: shape [20], maps each LIP-20 class index to UNIFIED-25 index
LIP20_TO_UNIFIED25 = torch.tensor([
    0,   # 0 Background → 0 Background
    1,   # 1 Hat → 1 Hat
    2,   # 2 Hair → 2 Hair
    24,  # 3 Glove → 24 Glove
    10,  # 4 Sunglasses → 10 Sunglasses
    5,   # 5 Upper-cloth → 5 Upper-cloth
    7,   # 6 Dress → 7 Dress
    5,   # 7 Coat → 5 Upper-cloth (treat coat as upper-cloth)
    17,  # 8 Socks → 17 Socks
    9,   # 9 Pants → 9 Salwar/Pants
    12,  # 10 Left-arm → 12 Left-arm
    20,  # 11 Right-arm → (corrected) → actually index 20 doesn't exist — Right-arm is index 20 in LIP but maps to 20? Let me recalculate
    ...  # (implement the complete mapping, resolve all 20 entries)
], dtype=torch.long)
```

**Implement complete mapping tables** for all three schemes to UNIFIED-25. Apply via:
```python
def remap_labels(parse_map: torch.Tensor, mapping: torch.Tensor) -> torch.Tensor:
    """
    Args:
        parse_map: [H, W] long tensor with source scheme indices
        mapping: [N_source_classes] long tensor mapping source → UNIFIED-25
    Returns:
        [H, W] long tensor with UNIFIED-25 indices
    """
    return mapping[parse_map]  # vectorized lookup, no loops
```

### 3.7 Garment Region Classes per Dataset

For each dataset scheme, define which classes constitute the **garment try-on region** (used for warp mask supervision and agnostic mask construction):

```python
# UNIFIED-25 garment classes by try-on type
GARMENT_CLASSES_UPPER   = [5, 6]          # upper-cloth, kurta
GARMENT_CLASSES_LOWER   = [9, 19, 21]     # pants/salwar, skirt, lehenga-skirt
GARMENT_CLASSES_FULL    = [7, 10]         # dress, saree-drape (union)
GARMENT_CLASSES_DUPATTA = [8, 20]         # dupatta, saree-drape overlay
GARMENT_CLASSES_ALL     = list(set(GARMENT_CLASSES_UPPER + GARMENT_CLASSES_LOWER +
                                   GARMENT_CLASSES_FULL + GARMENT_CLASSES_DUPATTA))
```

---

## PART 4: PREPROCESSING SPECIFICATION DOCUMENT

Generate `PREPROCESSING_SPEC.md` as a standalone deliverable. This document specifies **exactly** how the dataset was (or should be) preprocessed before training. It is a reference document — not executable code — enabling users to reproduce the preprocessing pipeline.

`PREPROCESSING_SPEC.md` must contain:

### Section 1: Required Tools and Versions
```markdown
| Tool              | Version   | Purpose                          | Install Command                        |
|-------------------|-----------|----------------------------------|----------------------------------------|
| OpenPose          | 1.7.0     | 18-keypoint pose estimation      | See OpenPose GitHub (CUDA build)       |
| SCHP              | commit abc | Human parsing (LIP-20/ATR-18)   | pip install -e git+https://...         |
| DensePose         | detectron2 | IUV surface maps                | pip install detectron2==0.6            |
| mmpose            | 1.1.0     | Alternative pose (DWPose)        | pip install mmpose                     |
| Pillow            | 10.3.0    | Image I/O                        | pip install Pillow==10.3.0             |
| numpy             | 1.26.4    | Array operations                 | pip install numpy==1.26.4              |
```

### Section 2: Per-Modality Processing Commands
For each of the 11 VITON-HD modalities and 7 DressCode modalities, document:
- **Input:** what file(s) are consumed
- **Command:** exact command-line call (with all flags)
- **Output:** expected output file path and format
- **Validation:** how to verify the output is correct
- **Common failures:** what errors appear and how to fix them

Example entry (include all modalities in this format):
```markdown
#### MODALITY 3: openpose-img + openpose-json

**Input:** `image/{stem}.jpg`
**Command:**
  cd /path/to/openpose
  ./build/examples/openpose/openpose.bin \
    --image_dir /data/viton_hd/train/image/ \
    --write_images /data/viton_hd/train/openpose-img/ \
    --write_json /data/viton_hd/train/openpose-json/ \
    --display 0 \
    --render_pose 1 \
    --hand 0 \
    --face 0 \
    --net_resolution "-1x368" \
    --model_pose "BODY_25"

**Output:**
  openpose-img/{stem}_rendered.png   ← rename to {stem}.png
  openpose-json/{stem}_keypoints.json

**Validation:**
  - JSON must contain key 'people' with at least 1 entry
  - 'pose_keypoints_2d' must have length 54 (18 × 3)
  - At least 10 keypoints must have confidence > 0.1
  - Image must be 1024×768 RGB

**Common failures:**
  - Empty 'people' list: person too small/occluded → skip this image pair
  - CUDA out of memory: reduce --net_resolution to "-1x256"
  - Wrong number of keypoints: using BODY_25 model gives 75 values (25 kps), not 54.
    Use BODY_18 model: --model_pose "COCO" for 18 keypoints (54 values).
```

### Section 3: DensePose Processing Command
```markdown
#### MODALITY 9: image-densepose (IUV maps)

**Command:**
  python apply_net.py show \
    configs/densepose_rcnn_R_50_FPN_s1x.yaml \
    densepose_rcnn_R_50_FPN_s1x.pkl \
    dp_u dp_v dp_i \
    --input /data/viton_hd/train/image/ \
    --output /data/viton_hd/train/image-densepose/ \
    --opts MODEL.DEVICE cuda

**Output format:** 3-channel PNG (R=part_id 0-24, G=U_coord 0-255, B=V_coord 0-255)

**Validation:**
  - R channel must contain values 0–24 only
  - Non-background pixels (R > 0) should cover > 20% of image area
  - Image dimensions must match person image exactly
```

### Section 4: Agnostic Representation Construction
```markdown
#### MODALITY 7+8: agnostic-v3.2 + agnostic-mask

**Not a model inference step — derived from parsing + image:**

  python construct_agnostic.py \
    --image_dir /data/viton_hd/train/image/ \
    --parse_dir /data/viton_hd/train/image-parse-v3/ \
    --output_agnostic /data/viton_hd/train/agnostic-v3.2/ \
    --output_mask /data/viton_hd/train/agnostic-mask/ \
    --scheme lip20 \
    --garment_classes 5,6,7 \
    --preserve_classes 2,3,4,11,12,13,14,15,17,19

**Logic:**
  agnostic_mask = (parse_map ∈ garment_classes) | (parse_map ∈ arm_classes)
  agnostic_image = person_image * (1 - agnostic_mask) + fill_value * agnostic_mask
  fill_value = mean pixel value of person_image (per-image, not global mean)

**Validation:**
  - agnostic_mask should cover 10–45% of image pixels for typical upper-body garments
  - agnostic_image should have no NaN pixels
```

### Section 5: Validation Checklist (Run Before Training)
```markdown
Run this validation script before training:
  python validate_dataset.py --data_root /data/viton_hd/ --split train

Expected outputs:
  [PASS] 11,647 valid training pairs found
  [PASS] All 11 modalities present for all pairs
  [PASS] Image dimensions: all 1024×768
  [PASS] Parsing class distribution: 20 unique values in [0,19]
  [PASS] Skeleton keypoints: mean confidence 0.73 across dataset
  [PASS] DensePose coverage: mean 34.2% of image area
  [PASS] Agnostic mask coverage: mean 28.5% of image area

If any [FAIL]: the specific pairs are listed in failed_pairs.txt for investigation.
```

### Section 6: DressCode-Specific Notes
```markdown
DressCode Agnostic Construction:
  Use ATR-18 garment classes:
  - upper_body garment classes: [4]  (upper-cloth)
  - lower_body garment classes: [5, 6]  (skirt, pants)
  - dresses garment classes: [7]  (dress)

DressCode does not provide warp-cloth or warp-cloth-mask.
Set cfg.data.use_pretrained_warp = False for DressCode.

Pair file parsing:
  Each line in pairs.txt: "000001_0.jpg\t000001_1.jpg"
  person_id = "000001_0", cloth_id = "000001_1"
  (The _0/_1 suffix distinguishes person vs cloth images)
```

---

## PART 5: INDIAN TEXTILE EXTENSION SPECIFICATION

### 5.1 Extended Garment Taxonomy

Indian garment categories require specific handling due to their unique structural properties:

| Category | Try-On Region | Special Properties | Architecture Handling |
|---|---|---|---|
| Kurta | Upper body | Long (often hip-length), side slits | `coverage='upper'`, extend lower boundary to hip-level in agnostic mask |
| Salwar Kameez | Upper + lower | Two-piece; kameez=top, salwar=bottom | `coverage='full'`, two separate warp passes (one per piece) |
| Saree | Full body, complex | 6-9m of fabric; draping-dependent | `coverage='full'`, DensePose-guided draping simulation |
| Lehenga | Lower + dupatta | Flared skirt + blouse + dupatta | `coverage='lower_extended'`, three-piece handling |
| Dupatta | Overlay | Transparent/sheer; drapes over body | `coverage='dupatta'`, alpha-composited separately |
| Western top | Upper | Same as VITON-HD upper-body | `coverage='upper'` (standard path) |
| Palazzo/Churidar | Lower | Wide-leg / fitted lower-body | `coverage='lower'` (standard DressCode lower path) |

### 5.2 Fabric Conditioning Module (`models/fabric_conditioner.py`)

**Purpose:** Inject fabric and pattern information to guide diffusion texture generation. Indian textiles have distinctive fabric behaviors (silk draping, cotton texture, chiffon translucency, embroidery relief) that affect how the garment should look on the body.

**Architecture:**
- Input: `garment_meta` dict loaded from `{cloth_id}_meta.json`.
- **Fabric Embedding:** `nn.Embedding(N_fabrics, 64)` where `N_fabrics = 12` (cotton, silk, chiffon, georgette, linen, khadi, chanderi, crepe, velvet, net, satin, synthetic). Map fabric string → integer index via a lookup dict.
- **Pattern Embedding:** `nn.Embedding(N_patterns, 32)` where `N_patterns = 10` (solid, stripes, floral, geometric, embroidered, printed, block_print, tie_dye, ikat, bandhani).
- **Category Embedding:** `nn.Embedding(8, 32)` for the 8 garment categories.
- **Fusion:** Concatenate all three embeddings → Linear(128, 256) → GELU → Linear(256, 256) = `fabric_vector` [B, 256].
- **Injection:** The `fabric_vector` is injected into the `IPAdapterProjection` module by adding it (after a learned projection Linear(256, 768)) to each of the 16 IP-Adapter token embeddings. This modulates the garment appearance conditioning with fabric-aware context.
- **Fallback (when no metadata):** When `garment_meta` is absent (VITON-HD or DressCode images), use a zero-filled `fabric_vector` → the fabric conditioning branch contributes nothing (identity behavior via additive injection).

### 5.3 Extended Part Segmentation for Indian Garments

The garment part segmenter (5-part for western garments) must be extended to 8 parts for Indian garments:

| Part Index | Western Garment | Indian Garment |
|---|---|---|
| 0 | Torso | Torso (kurta body, blouse) |
| 1 | Left sleeve | Left sleeve |
| 2 | Right sleeve | Right sleeve |
| 3 | Lower front | Lower front (salwar/lehenga front) |
| 4 | Lower back | Lower back |
| 5 | (not used) | Collar/Neckline decorative |
| 6 | (not used) | Dupatta section |
| 7 | (not used) | Embellishment region (border/zari) |

The `PartAwareWarpingModule` must be configurable via `cfg.warping.num_parts` (default=5 for western, 8 for Indian). When `num_parts=8`, parts 5–7 apply identity (no-deformation) warp — they are overlaid as rigid elements.

### 5.4 Bottomwear and Full-Outfit Try-On

The system must support three try-on modes, selected per sample via `cfg.tryon_mode` or per-batch via a `tryon_mode` key in the dataset dict:

**Mode A: Upper-body only** (default, VITON-HD compatible)
- Agnostic mask covers: upper-cloth, coat, arms
- Warp target: cloth → upper torso
- Standard pipeline

**Mode B: Lower-body only** (DressCode lower_body, palazzo/lehenga)
- Agnostic mask covers: pants, skirt, lehenga, lower legs
- Warp target: cloth → lower body
- DensePose part indices for lower body: IUV parts 7–12 (thighs, legs, feet)
- The `BodyConditionEncoder` uses DensePose lower-body parts as primary conditioning

**Mode C: Full-outfit / Pair** (DressCode dresses, saree, salwar kameez)
- Agnostic mask covers: full body garment region (upper + lower)
- Two cloth inputs: `cloth_upper` + `cloth_lower` (or single `cloth_full` for dresses/saree)
- For two-piece outfits: run `PartAwareWarpingModule` twice (once per piece) then concatenate warped results
- The UNet receives both warped cloths: `cloth_warped_upper` (4ch) + `cloth_warped_lower` (4ch) via the garment adapter
- UNet input channels expand from 17 to 21 for Mode C:
  - Original 17 channels + 4 additional for second garment
  - The extra 4 channels use σ=0.02 init (same strategy as v3.0)
- `cfg.model.diffusion.unet_in_channels_by_mode = {A: 17, B: 17, C: 21}`

**Mode D: Dupatta/Overlay** (Indian extension)
- Run Mode A or C first to get base try-on `I_base`
- Encode dupatta image through a frozen VAE → dupatta latent
- Run a second lightweight UNet pass (shared weights, different conditioning) to add dupatta drape
- Alpha-composite dupatta result over `I_base` using a draping mask predicted by `RegionCompositor`
- **Implementation note:** Mode D requires `has_dupatta=true` in garment metadata. The paired dupatta garment ID is looked up from `paired_garment_id` field.

---

## PART 6: DATASET LOADER VALIDATION SYSTEM

### 6.1 JSON Schema Validation (`utils/schema_validator.py`)

Every JSON file loaded by the dataset must be validated against a schema before the training epoch begins. Use `jsonschema` library.

**OpenPose JSON Schema:**
```python
OPENPOSE_SCHEMA = {
    "type": "object",
    "required": ["version", "people"],
    "properties": {
        "version": {"type": "string"},
        "people": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "required": ["pose_keypoints_2d"],
                "properties": {
                    "pose_keypoints_2d": {
                        "type": "array",
                        "minItems": 54,
                        "maxItems": 54,  # 18 keypoints × 3 values
                        "items": {"type": "number"}
                    }
                }
            }
        }
    }
}
```

**Garment Metadata JSON Schema:**
```python
GARMENT_META_SCHEMA = {
    "type": "object",
    "required": ["garment_id", "category", "fabric", "coverage"],
    "properties": {
        "garment_id": {"type": "string"},
        "category": {"type": "string", "enum": [
            "kurta", "saree", "salwar_kameez", "lehenga",
            "dupatta", "western_top", "western_bottom", "dress"
        ]},
        "subcategory": {"type": "string"},
        "fabric": {"type": "string"},
        "pattern": {"type": "string"},
        "coverage": {"type": "string", "enum": ["upper", "lower", "full", "dupatta"]},
        "has_dupatta": {"type": "boolean"},
        "paired_garment_id": {"type": ["string", "null"]},
        "try_on_region": {
            "type": "array",
            "items": {"type": "number", "minimum": 0.0, "maximum": 1.0},
            "minItems": 4,
            "maxItems": 4
        }
    }
}
```

Implement `validate_json_file(path, schema)` that raises `DatasetValidationError` with the file path and specific validation error message if the JSON does not conform.

### 6.2 Class Histogram Verification (`utils/dataset_validator.py`)

Before training begins, scan all parse maps in the dataset and compute class histograms. The `DatasetValidator` class must:

1. **Compute per-class pixel frequency** across a random 5% sample of the training set (for speed).
2. **Verify expected class presence:**
   - For VITON-HD (UNIFIED-25): classes 0, 2, 3, 5, 12 must each appear in > 80% of samples.
   - For DressCode upper: classes 0, 2, 3, 5, 12 must appear in > 70% of samples.
   - For DressCode lower: classes 0, 2, 3, 9, 13, 14 must appear in > 70% of samples.
3. **Detect mapping errors:** If any sample contains class index ≥ UNIFIED-25 size (25), raise `LabelMappingError`.
4. **Output validation report:**
   ```
   Dataset Validation Report
   ========================
   Dataset: VITON-HD train split
   Sampled: 582 / 11,647 pairs (5.0%)
   
   Class Histogram (UNIFIED-25, pixel frequency):
     0  Background:    45.2%  [PASS]
     1  Hat:            0.3%  [INFO - rare class]
     2  Hair:           8.1%  [PASS]
     3  Face:           4.2%  [PASS]
     4  Neck/Scarf:     1.8%  [PASS]
     5  Upper-cloth:   12.4%  [PASS]
     ...
   
   Skeleton quality:
     Mean keypoints with conf > 0.1: 13.2 / 18  [PASS]
     Samples with < 5 valid kps: 43 (7.4%)  [WARN - check these]
   
   DensePose coverage:
     Mean body surface coverage: 34.2%  [PASS]
     Samples with < 10% coverage: 12 (2.1%)  [WARN]
   
   Validation PASSED (2 warnings)
   ```
5. Log warnings but do not abort training on warnings — only abort on errors.

### 6.3 Tensor Dimension Assertions (`data/dataset.py`)

In `VITONHDDataset.__getitem__` and `DressCodeDataset.__getitem__`, after assembling the output dict, assert expected shapes:

```python
def _assert_shapes(self, sample: Dict[str, torch.Tensor], H: int, W: int) -> None:
    """Assert all tensor shapes match expected dimensions. Raises AssertionError with details."""
    expected = {
        'person_image':       (3, H, W),
        'agnostic_image':     (3, H, W),
        'agnostic_mask':      (1, H, W),
        'parsing_map':        (H, W),        # long tensor — no channel dim
        'pose_image':         (3, H, W),
        'skeleton_heatmaps':  (18, H, W),
        'cloth_image':        (3, H, W),
        'cloth_mask':         (1, H, W),
        'densepose_iuv':      (3, H, W),
        'pseudo_part_labels': (H, W),
        # For VITON-HD only:
        'warp_cloth':         (3, H, W),     # optional
        'warp_cloth_mask':    (1, H, W),     # optional
    }
    for key, shape in expected.items():
        if key not in sample:
            continue
        actual = tuple(sample[key].shape)
        assert actual == shape, (
            f"Shape mismatch for '{key}': expected {shape}, got {actual}. "
            f"Stem: {sample.get('filename', 'unknown')}"
        )
    # Range checks
    assert sample['parsing_map'].max() < 25, \
        f"UNIFIED-25 violation: parsing_map contains index {sample['parsing_map'].max()}"
    assert sample['cloth_mask'].min() >= 0.0 and sample['cloth_mask'].max() <= 1.0, \
        f"cloth_mask range violation: [{sample['cloth_mask'].min()}, {sample['cloth_mask'].max()}]"
    assert sample['agnostic_mask'].dtype == torch.float32, \
        f"agnostic_mask must be float32, got {sample['agnostic_mask'].dtype}"
    assert sample['parsing_map'].dtype == torch.int64, \
        f"parsing_map must be int64 (long), got {sample['parsing_map'].dtype}"
```

### 6.4 Multi-Dataset Unified DataModule (`data/unified_datamodule.py`)

Implement `VirtualTryOnDataModule(LightningDataModule)` that:

1. Accepts list of dataset configs: `[{name: 'viton_hd', root: '/data/viton_hd', weight: 1.0}, {name: 'dresscode', root: '/data/dresscode', weight: 0.5}]`.
2. Instantiates the appropriate dataset class per name: `VITONHDDataset`, `DressCodeDataset`, `IndianTextileDataset`.
3. Wraps multiple datasets in `torch.utils.data.ConcatDataset` with weighted sampling: use `torch.utils.data.WeightedRandomSampler` to sample from each dataset proportional to `weight * len(dataset)`.
4. Runs `DatasetValidator` on each dataset during `setup()`.
5. `DataLoader` config: `batch_size=cfg.data.batch_size`, `num_workers=cfg.data.num_workers`, `pin_memory=True`, `persistent_workers=True`, `prefetch_factor=2`.

---

## PART 7: COMPLETE UPDATED PIPELINE WITH ALL EXTENSIONS

```
INPUTS (per batch item):
  person_image [3,H,W]          agnostic_image [3,H,W]       agnostic_mask [1,H,W]
  parsing_map [H,W] (UNIFIED-25) pose_image [3,H,W]          skeleton_heatmaps [18,H,W]
  cloth_image [3,H,W]           cloth_mask [1,H,W]           densepose_iuv [3,H,W]
  warp_cloth [3,H,W]*           warp_cloth_mask [1,H,W]*     garment_meta (dict)*
  tryon_mode (str: A/B/C/D)
  (* = optional, dataset-dependent)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STAGE 0: CONDITIONING PREPARATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FabricConditioner (optional, Indian textiles)
    garment_meta → fabric_vector [B, 256]

  ParseMapEmbedder
    parsing_map (UNIFIED-25, 25-class vocab) → parse_embedded [B, 3, H/8, W/8]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STAGE 1: GEOMETRIC ALIGNMENT (jointly trainable)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BodyConditionEncoder
    Input: agnostic + agnostic_mask + pose_image + skeleton_heatmaps +
           parsing_map (embedded) + densepose_iuv (new in v4.0)
    → {F_body_4, F_body_8, F_body_16}

  GarmentFeatureExtractor
    Input: cloth_image + cloth_mask
    → {F_cloth_4, F_cloth_8, F_cloth_16} + z_cloth_global

  PartAwareWarpingModule (num_parts configurable: 5 or 8)
    Local correlation → per-part TPS → blend
    → cloth_warped, cloth_mask_warped, deformation_field, part_masks

  [Mode C/D only: second PartAwareWarpingModule pass for cloth_lower]

  GarmentLatentAdapter
    VAE-encode cloth_warped → adapt → cloth_warped_latent [4, H/8, W/8]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STAGE 2: LATENT DIFFUSION SYNTHESIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [FROZEN] VAE + CLIP
  IPAdapterProjection + FabricConditioner injection
    → garment_context [B, 16, 768] (fabric-modulated)

  DiffusionSynthesisUNet (17ch standard, 21ch for Mode C)
    → predicted_noise

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COMPOSITING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  RegionCompositor → I_final [3,H,W]
  [Mode D: DupatteCompositor → I_final_with_dupatta]
  EMA shadow of UNet (inference only)
```

### DensePose Integration in BodyConditionEncoder

Add **Branch D (DensePose)** to `BodyConditionEncoder`:
- Input: `densepose_iuv` [B, 3, H, W] — R=part_id (normalized to [0,1]), G=U, B=V.
- 4-layer CNN: Conv2d(3→32, 3×3, stride 2) → BN → ReLU → Conv2d(32→64, 3×3, stride 2) → BN → ReLU → Conv2d(64→128, 3×3, stride 2) → BN → ReLU → Conv2d(128→256, 1×1).
- Output at stride 8: `F_dense_8` [B, 256, H/8, W/8].
- Add `F_dense_8` to the cross-modal fusion (concatenate alongside F_agn_8, F_pose_8, F_parse_8).
- Update fusion input: `[F_agn_8(256), F_pose_8(256), F_parse_8(256), F_dense_8(256)]` → [B, 1024, H/8, W/8] → cross-attention → [B, 256, H/8, W/8].

**Fallback when DensePose unavailable:** If `densepose_iuv` is absent from batch (e.g., some samples missing DensePose), use a zero tensor [B, 256, H/8, W/8] for `F_dense_8`. The model is robust to this (all-zero contribution after the cross-attention is effectively neutral).

---

## PART 8: UPDATED FULL PROJECT FILE STRUCTURE (v4.0)

```
virtual_tryon/
├── configs/
│   ├── default.yaml                     # Base config (VITON-HD upper-body, Mode A)
│   ├── dresscode_lower.yaml             # DressCode lower-body override
│   ├── dresscode_full.yaml              # DressCode dress/full-body override
│   ├── multi_dataset.yaml               # Multi-dataset training config
│   └── indian_textiles.yaml             # Indian textile extension config
│
├── data/
│   ├── dataset_vitonhd.py               # VITONHDDataset (11 modalities)
│   ├── dataset_dresscode.py             # DressCodeDataset (7 modalities + agnostic construction)
│   ├── dataset_indian.py                # IndianTextileDataset (+ garment metadata loading)
│   ├── unified_datamodule.py            # VirtualTryOnDataModule (multi-dataset, weighted sampler)
│   └── label_mapper.py                  # LIP20/ATR18/INDIAN22 → UNIFIED-25 mapping tables
│
├── models/
│   ├── __init__.py
│   ├── body_encoder.py                  # BodyConditionEncoder (Swin V2 + 4 branches + DensePose)
│   ├── garment_extractor.py             # GarmentFeatureExtractor (ConvNeXt + Shape CNN)
│   ├── tps.py                           # Differentiable TPS (FP32 solve + K regularization)
│   ├── warping.py                       # PartAwareWarpingModule (configurable num_parts: 5 or 8)
│   ├── garment_adapter.py               # GarmentLatentAdapter
│   ├── parse_embedder.py                # ParseMapEmbedder (25-class vocab)
│   ├── ip_adapter.py                    # IPAdapterProjection (pretrained IP-Adapter)
│   ├── fabric_conditioner.py            # FabricConditioner (fabric/pattern/category embeddings)
│   ├── diffusion_unet.py                # DiffusionSynthesisUNet (mode-aware channel config)
│   ├── compositor.py                    # RegionCompositor + DupatteCompositor (Mode D)
│   └── tryon_mode_router.py             # TryOnModeRouter (routes batch items to correct pipeline)
│
├── losses/
│   ├── __init__.py
│   ├── diffusion_loss.py
│   ├── perceptual.py
│   ├── ssim.py
│   └── warp_losses.py                   # + L_warp_pretrain (pre-warped cloth supervision)
│
├── utils/
│   ├── constants.py                     # UNIFIED-25 defs + all garment class lists + all norms
│   ├── label_mapper.py                  # (also in data/ — shared utility)
│   ├── schema_validator.py              # JSON schema validation (OpenPose + garment meta)
│   ├── dataset_validator.py             # DatasetValidator class (histogram + coverage checks)
│   ├── viz.py
│   └── metrics.py
│
├── training/
│   ├── lightning_module.py              # VirtualTryOnModule (mode-aware forward + joint training)
│   └── trainer_setup.py
│
├── inference/
│   ├── infer.py                         # CLI (Mode A/B/C/D, config-driven)
│   └── preprocess_utils.py
│
├── train.py
├── requirements.txt
├── PREPROCESSING_SPEC.md                # [NEW DELIVERABLE] Full preprocessing reference doc
└── VirtualTryOn_Notebook.ipynb
```

---

## PART 9: UPDATED CONFIGURATION SYSTEM

### `configs/default.yaml` (base, VITON-HD upper-body):
```yaml
data:
  datasets:
    - name: viton_hd
      root: "./viton_hd"
      weight: 1.0
      split_train: train
      split_test: test
  image_height: 1024
  image_width: 768
  num_workers: 8
  batch_size: 4
  pin_memory: true
  use_pretrained_warp: true       # Use warp-cloth modality (VITON-HD only)
  label_scheme: lip20             # Input label scheme before mapping
  validate_before_training: true  # Run DatasetValidator on setup()

tryon_mode: A                     # A=upper, B=lower, C=full, D=dupatta

model:
  unified_parse_classes: 25       # UNIFIED-25 vocab size
  body_encoder:
    backbone: swin_v2_base_patch4_window12_192_22k
    pretrained: true
    output_channels: 256
    use_densepose: true
  garment_extractor:
    backbone: convnext_base
    pretrained: true
    output_channels: 256
  warping:
    num_control_points: 25
    num_parts: 5                  # 5 for western, 8 for Indian
    correlation_max_displacement: 8
    tps_reg_lambda: 1.0e-5
  diffusion:
    base_model: "runwayml/stable-diffusion-inpainting"
    clip_model: "openai/clip-vit-large-patch14"
    ip_adapter_weights: "h94/IP-Adapter"
    unet_in_channels_by_mode:
      A: 17
      B: 17
      C: 21
      D: 17                       # Mode D uses Mode A/C result + separate dupatta pass
    scheduler_train: ddpm
    scheduler_inference: dpm_solver_pp
    num_inference_steps: 50       # validation: 50, inference default: 50
    num_inference_steps_fast: 20  # fast inference option
    guidance_scale: 2.5
    cfg_dropout_prob: 0.1
    ip_num_tokens: 16
  compositor:
    base_channels: 32
  fabric_conditioner:
    enabled: false                # Enable for Indian textiles config
    n_fabric_types: 12
    n_pattern_types: 10
    n_categories: 8
    embed_dim: 64

training:
  max_epochs: 200
  lr_warp: 1.0e-4
  lr_diffusion: 5.0e-5
  lr_compositor: 1.0e-4
  weight_decay: 1.0e-2
  warmup_steps: 500
  gradient_clip: 1.0
  gradient_checkpointing: true
  effective_batch_size: 8
  warp_pretrain_loss_decay_epochs: 10   # L_warp_pretrain weight decays to 0 by epoch 10

losses:
  lambda_denoise: 1.0
  lambda_x0_perc: 0.05
  lambda_ssim: 0.05
  lambda_warp_smooth: 40.0
  lambda_warp_mask: 1.0
  lambda_part_seg: 0.5
  lambda_composite: 0.5
  lambda_warp_pretrain: 2.0       # L1 to pre-warped cloth (VITON-HD only, decays to 0)
  vgg_layers: [relu1_1, relu2_1, relu3_1, relu4_1]
  vgg_weights: [0.03125, 0.0625, 0.125, 0.25]
  ssim_window_size: 11
  ssim_sigma: 1.5

logging:
  log_dir: "./logs"
  tensorboard: true
  log_images_every_n_steps: 200
  save_top_k: 3
  val_image_samples: 4

inference:
  device: cuda
  precision: bf16
  num_denoising_steps: 50
  guidance_scale: 2.5
  auto_preprocess_model: "facebook/mask2former-swin-large-coco-panoptic"
```

### `configs/indian_textiles.yaml` (override):
```yaml
# Inherits from default.yaml, overrides:
data:
  datasets:
    - name: indian_textiles
      root: "./indian_textiles"
      weight: 1.0
      label_scheme: indian22
  validate_before_training: true

tryon_mode: A                     # Override per-sample via garment_meta.coverage

model:
  warping:
    num_parts: 8                  # 8-part segmentation for Indian garments
  fabric_conditioner:
    enabled: true

training:
  lr_warp: 5.0e-5                 # Lower LR for fine-tuning from VITON-HD checkpoint
  lr_diffusion: 2.0e-5
```

---

## PART 10: UPDATED CONSTANTS (`utils/constants.py`)

```python
# ─── Normalization ───────────────────────────────────────────
RGB_MEAN = [0.5, 0.5, 0.5]
RGB_STD  = [0.5, 0.5, 0.5]
CLIP_MEAN = [0.48145466, 0.4578275, 0.40821073]
CLIP_STD  = [0.26862954, 0.26130258, 0.27577711]

# ─── Spatial Resolutions ─────────────────────────────────────
FEATURE_RESOLUTIONS = {4: (256, 192), 8: (128, 96), 16: (64, 48), 32: (32, 24)}
LATENT_SCALE_FACTOR = 8
LATENT_H, LATENT_W = 128, 96
VAE_SCALING_FACTOR = 0.18215

# ─── Label Schemes ────────────────────────────────────────────
N_LIP20    = 20
N_ATR18    = 18
N_INDIAN22 = 22
N_UNIFIED25 = 25   # All model inputs use UNIFIED-25

# UNIFIED-25 garment region class groups
GARMENT_CLASSES_UPPER   = [5, 6]          # upper-cloth, kurta
GARMENT_CLASSES_LOWER   = [9, 19, 21]     # pants/salwar, skirt, lehenga-skirt
GARMENT_CLASSES_FULL    = [7, 10]         # dress, saree-drape
GARMENT_CLASSES_DUPATTA = [8, 20]         # dupatta, saree-drape overlay
GARMENT_CLASSES_BY_MODE = {
    'A': GARMENT_CLASSES_UPPER,
    'B': GARMENT_CLASSES_LOWER,
    'C': GARMENT_CLASSES_FULL,
    'D': GARMENT_CLASSES_DUPATTA,
}

# ─── Flip Augmentation ───────────────────────────────────────
KEYPOINT_FLIP_PAIRS = [(1,2),(3,4),(5,6),(7,8),(9,10),(11,12),(13,14),(15,16)]
PARSE_FLIP_PAIRS_UNIFIED25 = [(12,20)]  # left-arm(12) ↔ right-arm(20) in UNIFIED-25

# ─── TPS / Warping ───────────────────────────────────────────
TPS_REG_LAMBDA = 1e-5
CORR_MAX_DISPLACEMENT = 8
CORR_FEATURE_DIM = 256     # sqrt(CORR_FEATURE_DIM) used for normalization

# ─── DensePose ───────────────────────────────────────────────
DENSEPOSE_NUM_PARTS = 24
DENSEPOSE_LOWER_BODY_PARTS = [7, 8, 9, 10, 11, 12]  # thighs, legs, feet
DENSEPOSE_UPPER_BODY_PARTS = [1, 2, 3, 4, 5, 6]     # torso, arms

# ─── Diffusion ───────────────────────────────────────────────
EMA_DECAY = 0.9999
CFG_DROPOUT_PROB = 0.1
IP_NUM_TOKENS = 16

# ─── Fabric Types (Indian Textiles) ──────────────────────────
FABRIC_TYPES = {
    'cotton': 0, 'silk': 1, 'chiffon': 2, 'georgette': 3,
    'linen': 4, 'khadi': 5, 'chanderi': 6, 'crepe': 7,
    'velvet': 8, 'net': 9, 'satin': 10, 'synthetic': 11, 'unknown': 0
}
PATTERN_TYPES = {
    'solid': 0, 'stripes': 1, 'floral': 2, 'geometric': 3,
    'embroidered': 4, 'printed': 5, 'block_print': 6,
    'tie_dye': 7, 'ikat': 8, 'bandhani': 9, 'unknown': 0
}
GARMENT_CATEGORIES = {
    'kurta': 0, 'saree': 1, 'salwar_kameez': 2, 'lehenga': 3,
    'dupatta': 4, 'western_top': 5, 'western_bottom': 6, 'dress': 7
}
```

---

## PART 11: UPDATED REQUIREMENTS.TXT

```
torch==2.2.1+cu121
torchvision==0.17.1+cu121
torchaudio==2.2.1+cu121
pytorch-lightning==2.2.1
diffusers==0.27.2
transformers==4.39.3
accelerate==0.28.0
timm==0.9.16
omegaconf==2.3.0
tensorboard==2.16.2
Pillow==10.3.0
numpy==1.26.4
matplotlib==3.8.4
tqdm==4.66.2
scipy==1.13.0
einops==0.7.0
albumentations==1.4.3
xformers==0.0.25
triton==2.2.0
safetensors==0.4.2
huggingface-hub==0.22.2
controlnet-aux==0.0.7
clean-fid==0.1.35
lpips==0.1.4
jsonschema==4.22.0
```

---

## PART 12: COMPLETE OUTPUT DELIVERABLES (v4.0)

Generate all 35 files completely, in order, without truncation. Label each with full path.

**Configuration (5 files):**
1. `requirements.txt`
2. `configs/default.yaml`
3. `configs/dresscode_lower.yaml`
4. `configs/multi_dataset.yaml`
5. `configs/indian_textiles.yaml`

**Documentation (1 file):**
6. `PREPROCESSING_SPEC.md`

**Utilities (6 files):**
7. `utils/constants.py`
8. `utils/label_mapper.py`
9. `utils/schema_validator.py`
10. `utils/dataset_validator.py`
11. `utils/viz.py`
12. `utils/metrics.py`

**Data Loaders (4 files):**
13. `data/dataset_vitonhd.py`
14. `data/dataset_dresscode.py`
15. `data/dataset_indian.py`
16. `data/unified_datamodule.py`

**Models (13 files):**
17. `models/tps.py`
18. `models/body_encoder.py`
19. `models/garment_extractor.py`
20. `models/warping.py`
21. `models/garment_adapter.py`
22. `models/parse_embedder.py`
23. `models/ip_adapter.py`
24. `models/fabric_conditioner.py`
25. `models/diffusion_unet.py`
26. `models/compositor.py`
27. `models/tryon_mode_router.py`
28. `models/__init__.py`

**Losses (5 files):**
29. `losses/perceptual.py`
30. `losses/ssim.py`
31. `losses/warp_losses.py`
32. `losses/diffusion_loss.py`
33. `losses/__init__.py`

**Training & Inference (4 files):**
34. `training/lightning_module.py`
35. `training/trainer_setup.py`
36. `train.py`
37. `inference/infer.py`
38. `inference/preprocess_utils.py`

**Notebook (1 file):**
39. `VirtualTryOn_Notebook.ipynb`

---

## PART 13: UPDATED INTEGRATION VERIFICATION CHECKLIST

Before generating each file, verify:

**Label unification:**
- [ ] `ParseMapEmbedder` uses `vocab_size=25` (UNIFIED-25), never 20 or 18
- [ ] All dataset loaders apply `remap_labels()` before returning `parsing_map`
- [ ] `remap_labels()` imported from `utils/label_mapper.py` — not reimplemented per-dataset
- [ ] `GARMENT_CLASSES_BY_MODE` used in each dataset's agnostic mask construction

**Dataset validation:**
- [ ] `DatasetValidator.run()` called in `VirtualTryOnDataModule.setup()` before training
- [ ] Every JSON file validated against schema before first epoch
- [ ] `_assert_shapes()` called in every `__getitem__` (not just during validation scan)
- [ ] `DatasetValidationError` and `LabelMappingError` are custom exception classes defined in `utils/schema_validator.py`

**DensePose:**
- [ ] `densepose_iuv` [3, H, W] loaded in all three dataset classes
- [ ] Zero fallback tensor provided when `densepose_iuv` file is missing
- [ ] `BodyConditionEncoder` Branch D has explicit `if cfg.model.body_encoder.use_densepose` guard
- [ ] DensePose IUV channel order: R=part_id, G=U, B=V — verified in loading code comment

**Multi-dataset:**
- [ ] `tryon_mode` key present in every dataset's `__getitem__` output
- [ ] `TryOnModeRouter` dispatches correct UNet channel config per mode
- [ ] `warp_cloth` / `warp_cloth_mask` handled gracefully when absent (DressCode)
- [ ] `garment_meta` handled gracefully when absent (VITON-HD / DressCode)
- [ ] `fabric_vector` is zero tensor when `FabricConditioner.enabled=False`

**Indian textiles:**
- [ ] `IndianTextileDataset` loads and validates `garment_meta` JSON per cloth item
- [ ] `FabricConditioner` correctly falls back to zero vector when metadata absent
- [ ] `num_parts=8` mode in `PartAwareWarpingModule` uses parts 5–7 as identity warps
- [ ] `INDIAN-22 → UNIFIED-25` mapping table is complete (all 22 entries)

**Pre-warped cloth:**
- [ ] `L_warp_pretrain` weight computed as `lambda * max(0, (decay_epochs - epoch) / decay_epochs)`
- [ ] `L_warp_pretrain` = 0 when `cfg.data.use_pretrained_warp = False`
- [ ] `warp_cloth` used only in loss, not fed into diffusion UNet

**All v3.0 checks still apply:**
- [ ] FEATURE_RESOLUTIONS from constants, never hardcoded
- [ ] CLIP normalization ONLY inside `ip_adapter.py`
- [ ] TPS_REG_LAMBDA added to K before `torch.linalg.solve`; FP32 cast around solve
- [ ] Correlation normalized by `sqrt(CORR_FEATURE_DIM)` = `sqrt(256)`
- [ ] No `.detach()` on `cloth_warped` in training graph
- [ ] EMA updated every 10 steps; used only at inference
- [ ] No SPADE anywhere in diffusion UNet
- [ ] DPM-Solver++ for validation (50 steps) and inference; DDPM for training noise only

---

## PART 14: UPDATED JUPYTER NOTEBOOK SECTIONS

The notebook must include all v3.0 sections plus these new sections:

### Section 0b: Dataset Download Pointers
```python
# VITON-HD: https://github.com/shadow2496/VITON-HD (requires agreement)
# DressCode: https://github.com/aimagelab/dress-code (academic license)
# Indian Textiles: user-provided custom dataset following Part 2.3 structure
# Print the expected folder structure and validate it exists
import os
def check_dataset_structure(root, expected_subdirs):
    for subdir in expected_subdirs:
        path = os.path.join(root, subdir)
        exists = os.path.isdir(path)
        count = len(os.listdir(path)) if exists else 0
        print(f"  {'✓' if exists else '✗'} {subdir}/ — {count} files")
```

### Section 1b: Multi-Dataset Verification
- Run `DatasetValidator` on each configured dataset.
- Display class histogram bar charts for UNIFIED-25 labels.
- Show 3 samples from each dataset in a comparative grid.
- Verify DensePose IUV map visualization (show 24 body parts color-coded).

### Section 2b: Try-On Mode Demonstration
- Instantiate model and run a single forward pass for each of Mode A, B, C.
- Print input/output tensor shapes for each mode.
- Show which UNet input channels are active per mode.

### Section 6b: Indian Textile Inference Demo
- Upload a kurta image and a person image.
- Provide example `garment_meta.json` for the kurta.
- Run Mode A inference with `fabric_conditioner.enabled=True`.
- Compare result with and without fabric conditioning.

**If you reach a context limit before completing all 39 files:**
Output `=== CONTINUATION BREAK ===`.
State: "Stopped at file N: [filename], last completed line: [line number]."
Continue from that exact point in your next response. Do not summarize. Do not skip. Every function in every file must be complete.

---PROMPT END---
