# Optimized Claude Opus 4.6 Prompt
## Task: Production-Ready Virtual Try-On System (VITON-HD Compatible)

---

## HOW TO USE THIS PROMPT

Copy everything inside the `---PROMPT START---` and `---PROMPT END---` markers below and paste it directly into Claude Opus 4.6.

---

---PROMPT START---

You are a world-class deep learning engineer and computer vision researcher with deep expertise in image synthesis, generative models, and virtual try-on systems. You have thoroughly studied the VITON-HD paper (Han et al., 2021), CatVTON, DCI-VTON, HR-VITON, and related garment transfer literature. Your task is to architect and implement — from scratch, in your own original code — a **production-ready, commercially deployable, high-accuracy virtual try-on system** that operates on the VITON-HD dataset structure.

---

## ABSOLUTE CONSTRAINTS (READ BEFORE ANYTHING ELSE)

1. **NO copied code** from any public repository (VITON-HD GitHub, CatVTON, DCI-VTON, etc.). All code must be original implementations inspired by conceptual understanding of the research.
2. **NO new module names** that replicate official names verbatim (e.g., do not name classes `GMM`, `ALIASGenerator`, `SegmentationNetwork` exactly — use your own naming convention throughout).
3. The dataset is **already preprocessed and structured** in the VITON-HD Zalando format. **Do NOT include any preprocessing, OpenPose inference, Human Parsing inference, or data preparation code.** Assume all dataset artifacts are ready on disk.
4. Every component must be **fully integrated** — no orphaned modules, no placeholder `pass` statements, no `TODO` stubs in production paths. Every function must be complete and callable end-to-end.
5. The system must run on **NVIDIA A100 GPU** with PyTorch Lightning as the primary framework (PyTorch 2.x). Use `torch.compile` where beneficial.
6. Deliver a **Jupyter Notebook (.ipynb)** as the primary execution interface alongside the modular `.py` source files. The notebook must be fully executable top-to-bottom in a cloud Jupyter environment (e.g., Google Colab Pro+, Lambda Labs, RunPod).

---

## DATASET STRUCTURE (ALREADY ON DISK — DO NOT PREPROCESS)

The VITON-HD dataset is structured as follows. Your dataloader must consume **all available modalities** listed below, as each one directly improves accuracy:

```
viton_hd/
├── train/
│   ├── image/              # Person RGB images, 1024×768, PNG
│   ├── image-parse-v3/     # Human parsing segmentation maps (20-class LIP palette), PNG
│   ├── openpose-img/       # OpenPose rendered keypoint heatmap images, PNG
│   ├── openpose-json/      # OpenPose raw JSON (18 keypoints x,y,confidence per person)
│   ├── cloth/              # Garment RGB images, 1024×768, PNG
│   ├── cloth-mask/         # Binary garment masks, PNG (white=garment, black=background)
│   ├── agnostic-v3.2/      # Agnostic person representation (upper body region masked), PNG
│   └── agnostic-mask/      # Binary mask of agnostic region, PNG
└── test/
    └── (same structure as train/)
```

**Modality usage rationale you must implement:**
- `image` → Ground truth target for reconstruction losses during training; reference person RGB during inference
- `image-parse-v3` → 20-class segmentation used to build agnostic body representation and define garment region boundaries
- `openpose-json` → 18 keypoint skeleton used to build spatial body structure (limb heatmaps, skeleton graphs)
- `openpose-img` → Rendered pose heatmap as auxiliary visual conditioning channel
- `cloth` → Source garment texture input
- `cloth-mask` → Used to isolate garment features and guide warping field boundaries
- `agnostic-v3.2` → Cloth-agnostic person body (torso region replaced/masked) — primary person conditioning input
- `agnostic-mask` → Binary mask defining the try-on target region for compositing

---

## ARCHITECTURE OVERVIEW

Study how VITON-HD, HR-VITON, CatVTON, and DCI-VTON solve the virtual try-on problem conceptually:

- **VITON-HD** uses a two-stage pipeline: (1) a geometric matching module that warps the garment to align with the person's body pose, and (2) an appearance generator (ALIAS) that synthesizes the final try-on image with attention-guided feature normalization. Key insight: misalignment errors in warping are handled by the generator through spatially-adaptive normalization conditioned on the warped garment.
- **HR-VITON** improves upon VITON-HD by fusing segmentation prediction and warping into a single unified stage, reducing error propagation between stages.
- **CatVTON** takes a diffusion-model approach where garment and person are concatenated as conditioning for a UNet denoiser, eliminating explicit warping. Key insight: the attention mechanism in diffusion transformers handles implicit alignment.
- **DCI-VTON** introduces disentangled control — separately controlling garment structure (shape) and texture, using a ControlNet-style conditioning. Key insight: decoupling shape deformation from texture synthesis allows finer control.

**Your architecture must synthesize the best of these approaches** into a cohesive, original pipeline with the following named modules (use these exact names in your implementation):

### Module 1: `BodyStructureEncoder`
- **Purpose:** Extract a rich, multi-modal body representation from the person inputs
- **Inputs:** agnostic image (3ch) + agnostic mask (1ch) + pose heatmap image (3ch) + skeleton tensor built from OpenPose JSON keypoints (18-channel Gaussian heatmaps) + parsing segmentation map (1ch, class indices or one-hot)
- **Architecture inspiration (implement originally):** 
  - A multi-branch encoder similar to how VITON-HD encodes pose and segmentation separately, then fuses. But implement using a **Swin Transformer V2 backbone** for the agnostic image branch and **lightweight CNN branches** for the mask, pose, and skeleton modalities.
  - Cross-modal attention fusion layer (inspired by DCI-VTON's disentanglement head) that produces a unified body feature map `F_body` at 1/4, 1/8, and 1/16 resolution scales.
  - Output: multi-scale feature pyramid `{F_body_4, F_body_8, F_body_16}`

### Module 2: `GarmentFeatureExtractor`
- **Purpose:** Extract multi-scale garment texture and structure features
- **Inputs:** cloth RGB (3ch) + cloth mask (1ch)
- **Architecture inspiration:**
  - Dual-stream CNN encoder: one stream for texture (RGB-only), one for shape (mask-guided)
  - Feature correlation volume between texture and shape streams (inspired by DCI-VTON's disentanglement and VITON-HD's cloth encoder)
  - Output: `{F_cloth_4, F_cloth_8, F_cloth_16}` multi-scale feature maps + a global style vector `z_cloth` (from global average pool → MLP)

### Module 3: `AdaptiveWarpingModule`
- **Purpose:** Geometrically align the garment to the person's body using a learnable dense deformation field
- **Inputs:** `F_cloth_8` + `F_body_8` (matched resolution)
- **Architecture inspiration (implement the conceptual logic of VITON-HD's GMM and HR-VITON's unified warping, but with your own architecture):**
  - Compute a 4D correlation volume between body and cloth feature maps (like PWC-Net / RAFT optical flow style correlation)
  - A **Thin Plate Spline (TPS) regression head**: predict a set of control point offsets (e.g., 5×5 = 25 control points) from the correlation volume. Then apply differentiable TPS transformation to warp the cloth image and cloth mask.
  - Additionally, predict a **dense offset field** (H/4 × W/4 × 2) using a small UNet on top of the TPS-warped features, for local refinement (second-order correction, inspired by HR-VITON's refinement step).
  - Apply the composed deformation (TPS + dense offset) to the full-resolution cloth and cloth-mask using `grid_sample`.
  - Outputs: `cloth_warped` (3ch), `cloth_mask_warped` (1ch), `deformation_field` (for regularization loss)

### Module 4: `ConditionalSynthesizer`
- **Purpose:** Generate the final photorealistic try-on image by fusing warped garment with body representation
- **Architecture inspiration (implement the conceptual logic of VITON-HD's ALIAS generator and CatVTON's attention-based fusion, but with your own architecture):**
  - **Encoder-Decoder UNet** with:
    - Input channels: agnostic_image (3) + pose_heatmap (3) + cloth_warped (3) + cloth_mask_warped (1) + parsing_map (1) = 11 channels total
    - Encoder: 5 downsampling stages using ResBlocks + Spectral Normalization
    - Skip connections from encoder to decoder (standard UNet skip)
    - **SPADE-style normalization layers** in the decoder conditioned on `cloth_warped` and `parsing_map` (inspired by VITON-HD's ALIAS spatially adaptive normalization — implement SPADE from scratch, do not import from external libraries)
    - **Self-attention layers** at 1/8 and 1/16 resolution in bottleneck (inspired by CatVTON's attention alignment)
    - Decoder outputs at full resolution
  - **Multi-scale discriminator** (PatchGAN style, 2 scales) for optional adversarial training
  - Outputs: `I_synthesized` (3ch, full resolution)

### Module 5: `CompositorHead`
- **Purpose:** Produce the final output by intelligently blending the synthesized result with the original person image, preserving non-garment regions (face, hair, hands, legs) with pixel-perfect accuracy
- **Inputs:** `I_synthesized` + original `person_image` + `agnostic_mask` + `cloth_mask_warped`
- **Architecture:**
  - A small CNN (4 ResBlocks) that predicts a soft alpha blending mask `alpha` (1ch, sigmoid output) from the concatenated inputs
  - Final output: `I_final = alpha * I_synthesized + (1 - alpha) * person_image`
  - This ensures non-garment regions are always pixel-perfect from the original image
  - Output: `I_final` (3ch) — the final try-on result

---

## LOSS FUNCTIONS

Implement all losses from scratch (do not import `lpips` as a black box — explain what you're computing):

1. **L1 Reconstruction Loss:** `L1(I_final, I_gt)` — pixel-wise L1 between output and ground truth person image
2. **Perceptual Loss (VGG-based LPIPS-style):** Extract features from VGG-19 layers `relu1_1, relu2_1, relu3_1, relu4_1, relu5_1` for both `I_final` and `I_gt`. Compute weighted L1 in feature space. Implement the VGG feature extractor yourself using `torchvision.models.vgg19(pretrained=True)` with frozen weights.
3. **SSIM Loss:** `1 - SSIM(I_final, I_gt)`. Implement SSIM from scratch using 2D Gaussian window convolution.
4. **Warp Regularization Loss:** Second-order smoothness on the `deformation_field` — compute the gradient of the deformation field and penalize large second derivatives. This prevents chaotic warping.
5. **Mask Supervision Loss:** BCE loss between `cloth_mask_warped` and a warped version of the ground truth garment region (obtained from parsing map — class indices corresponding to upper-body garment region in LIP-20 are classes 5 and 6).
6. **GAN Loss (optional, toggled via config):** Hinge GAN loss on `I_final` using the multi-scale PatchGAN discriminator.

**Total loss:**
```
L_total = λ1*L_L1 + λ2*L_perceptual + λ3*L_SSIM + λ4*L_warp_reg + λ5*L_mask + λ6*L_GAN
```
Default weights: `λ1=1.0, λ2=0.1, λ3=0.1, λ4=40.0, λ5=1.0, λ6=0.5`

---

## FULL PROJECT FILE STRUCTURE

Generate ALL of the following files with complete, working code:

```
virtual_tryon/
├── configs/
│   └── default.yaml              # All hyperparameters, paths, loss weights, training settings
├── data/
│   └── dataset.py                # VITONHDDataset class — loads all 8 modalities, augmentation
├── models/
│   ├── __init__.py
│   ├── body_encoder.py           # BodyStructureEncoder (Swin V2 + CNN multi-branch + cross-attention fusion)
│   ├── garment_extractor.py      # GarmentFeatureExtractor (dual-stream CNN)
│   ├── warping_module.py         # AdaptiveWarpingModule (correlation + TPS + dense offset + grid_sample)
│   ├── synthesizer.py            # ConditionalSynthesizer (SPADE UNet + self-attention)
│   ├── compositor.py             # CompositorHead (alpha prediction CNN)
│   ├── discriminator.py          # MultiScalePatchDiscriminator
│   └── tps.py                    # Differentiable Thin Plate Spline implementation (from scratch)
├── losses/
│   ├── __init__.py
│   ├── perceptual.py             # VGG perceptual loss (implemented from scratch)
│   ├── ssim.py                   # SSIM loss (implemented from scratch)
│   └── warp_reg.py               # Warp regularization loss
├── training/
│   ├── lightning_module.py       # PyTorch Lightning LightningModule — full train/val/test step
│   └── trainer_setup.py          # Trainer config: A100 settings, mixed precision, callbacks
├── inference/
│   └── infer.py                  # CLI inference script: python infer.py --person p.jpg --cloth c.jpg --output result.jpg
├── utils/
│   ├── viz.py                    # Visualization utilities for TensorBoard logging
│   └── metrics.py                # SSIM, FID, LPIPS metric computation for validation
├── train.py                      # Main training entry point
├── requirements.txt              # Exact pinned versions of all dependencies
└── VirtualTryOn_Notebook.ipynb   # Complete Jupyter Notebook for end-to-end execution
```

---

## DATASET LOADER SPECIFICATIONS (`data/dataset.py`)

The `VITONHDDataset` class must:

1. Accept `split` argument (`'train'` or `'test'`), `data_root` path, and an `augment` bool
2. Load a **paired list** from `{data_root}/{split}/image/` — list all `.jpg`/`.png` files to get person IDs, then match garment files by same filename prefix
3. For each `__getitem__`, load and return a dict with ALL of the following keys:
   - `person_image`: RGB float tensor [3, H, W], normalized to [-1, 1]
   - `agnostic_image`: RGB float tensor [3, H, W], normalized to [-1, 1]  
   - `agnostic_mask`: float tensor [1, H, W], values {0.0, 1.0}
   - `parsing_map`: long tensor [H, W] with class indices 0–19 (do NOT one-hot here)
   - `pose_image`: RGB float tensor [3, H, W], normalized to [0, 1]
   - `skeleton_heatmaps`: float tensor [18, H, W] — 18 Gaussian heatmaps generated from OpenPose JSON keypoints (sigma=6px Gaussian centered at each keypoint location)
   - `cloth_image`: RGB float tensor [3, H, W], normalized to [-1, 1]
   - `cloth_mask`: float tensor [1, H, W], values {0.0, 1.0}
   - `filename`: str (for inference logging)

4. Augmentation (only when `augment=True` and `split='train'`):
   - Random horizontal flip applied **consistently** to ALL spatial tensors simultaneously
   - Color jitter on `person_image` and `cloth_image` only (brightness=0.2, contrast=0.2, saturation=0.2)
   - **No random crops or resizes** — preserve the 1024×768 resolution exactly

5. `skeleton_heatmaps` generation: parse the JSON file at `openpose-json/{filename}.json`, extract the `pose_keypoints_2d` array (54 values = 18 keypoints × [x, y, confidence]), create 18 zero-initialized float32 tensors of shape [H, W], for each keypoint with confidence > 0.1, draw a 2D Gaussian centered at (x*W, y*H) with sigma=6 pixels using efficient vectorized operations (not Python loops).

---

## TRAINING PIPELINE SPECIFICATIONS (`training/lightning_module.py`)

Implement a `VirtualTryOnModule(LightningModule)` class that:

1. **`__init__`:** Instantiate all 5 model modules + all losses + optimizer configs. Accept a `cfg` (OmegaConf DictConfig) argument.
2. **`forward(batch)`:** Full forward pass:
   ```
   F_body = BodyStructureEncoder(agnostic, agnostic_mask, pose_image, skeleton_heatmaps, parsing_map)
   F_cloth = GarmentFeatureExtractor(cloth_image, cloth_mask)
   cloth_warped, cloth_mask_warped, deformation_field = AdaptiveWarpingModule(F_body, F_cloth, cloth_image, cloth_mask)
   I_synthesized = ConditionalSynthesizer(agnostic, pose_image, cloth_warped, cloth_mask_warped, parsing_map)
   I_final = CompositorHead(I_synthesized, person_image, agnostic_mask, cloth_mask_warped)
   ```
3. **`training_step`:** Compute all losses, log each individually to TensorBoard, return `L_total`
4. **`validation_step`:** Compute losses on val batch; log 4 sample result grids to TensorBoard (grid of: person | cloth | warped_cloth | synthesized | final_result)
5. **`configure_optimizers`:**
   - Generator optimizer: Adam, lr=1e-4, betas=(0.5, 0.999), with cosine LR schedule with warmup (1000 steps)
   - Discriminator optimizer (if GAN enabled): Adam, lr=4e-4, betas=(0.5, 0.999)
   - Return both optimizers with `frequency` parameters for GAN training (1:1 ratio)
6. **Mixed precision:** Use `Trainer(precision='bf16-mixed')` for A100 BF16 training
7. **Gradient clipping:** `gradient_clip_val=1.0`
8. **Checkpointing:** Save top-3 checkpoints by `val/ssim` metric; also save last checkpoint every epoch

---

## TRAINER SETUP (`training/trainer_setup.py`)

Configure `pl.Trainer` with:
- `accelerator='gpu'`, `devices=1` (single A100)
- `precision='bf16-mixed'`
- `max_epochs` from config (default: 200)
- `log_every_n_steps=50`
- `val_check_interval=0.5` (validate twice per epoch)
- `TensorBoardLogger` with structured log directory
- `ModelCheckpoint` callback
- `LearningRateMonitor` callback
- `GradientAccumulationScheduler` if batch size < 8 (accumulate to effective batch size 8)

---

## INFERENCE PIPELINE (`inference/infer.py`)

```bash
python inference/infer.py \
  --person path/to/person.jpg \
  --cloth path/to/cloth.jpg \
  --checkpoint path/to/best.ckpt \
  --config configs/default.yaml \
  --output tryon_result.jpg
```

The inference script must:
1. Load and preprocess inputs to match dataset normalization — resize to 1024×768 if needed
2. For inference, construct placeholder tensors for `agnostic_image`, `agnostic_mask`, `parsing_map`, `pose_image`, `skeleton_heatmaps` from the person image **using simple heuristics** (since we have no OpenPose/parsing at inference):
   - `agnostic_mask`: use a fixed rectangular mask covering torso region (rows H*0.15 to H*0.75, cols W*0.2 to W*0.8) — document this limitation clearly in comments
   - `agnostic_image`: apply `agnostic_mask` to zero out torso from person image
   - `parsing_map`: all zeros (background) — the model is robust to this during inference
   - `pose_image`: gray image (0.5 fill) as neutral pose conditioning
   - `skeleton_heatmaps`: all zeros (18-channel)
   - **Document this clearly:** for best results in production, provide actual parsed/posed inputs. The system still produces reasonable results with these heuristics.
3. Run `model.eval()` with `torch.no_grad()` and `torch.cuda.amp.autocast(dtype=torch.bfloat16)`
4. Denormalize output and save as high-quality JPEG

---

## CONFIGURATION SYSTEM (`configs/default.yaml`)

```yaml
data:
  data_root: "./viton_hd"
  image_height: 1024
  image_width: 768
  num_workers: 8
  batch_size: 4

model:
  body_encoder:
    swin_model: "microsoft/swin-v2-base-patch4-window12-192-22k"
    output_channels: 256
  garment_extractor:
    base_channels: 64
    output_channels: 256
  warping:
    num_control_points: 25       # 5x5 TPS grid
    correlation_max_displacement: 8
  synthesizer:
    base_channels: 64
    attention_resolutions: [16, 8]
    use_spade: true
  compositor:
    base_channels: 32

training:
  max_epochs: 200
  lr_generator: 1.0e-4
  lr_discriminator: 4.0e-4
  warmup_steps: 1000
  use_gan: true
  gradient_clip: 1.0
  effective_batch_size: 8

losses:
  lambda_l1: 1.0
  lambda_perceptual: 0.1
  lambda_ssim: 0.1
  lambda_warp_reg: 40.0
  lambda_mask: 1.0
  lambda_gan: 0.5

logging:
  log_dir: "./logs"
  tensorboard: true
  log_images_every_n_steps: 500
  save_top_k: 3

inference:
  device: "cuda"
  precision: "bf16"
```

---

## JUPYTER NOTEBOOK SPECIFICATIONS (`VirtualTryOn_Notebook.ipynb`)

The notebook must contain fully executable cells organized in these sections:

### Section 0: Environment Setup
- Install all dependencies via `!pip install ...` commands with exact version pins
- Clone/download model weights (Swin V2, VGG19) via `torch.hub` or `transformers`
- Verify GPU availability and print CUDA/PyTorch versions

### Section 1: Dataset Verification
- Mount/set data_root path
- Load one batch using `VITONHDDataset`
- Display all 8 modalities as a matplotlib figure grid with labels
- Print tensor shapes for all modalities

### Section 2: Model Architecture Inspection
- Instantiate the full `VirtualTryOnModule`
- Print parameter count per module (body_encoder, garment_extractor, etc.)
- Run a forward pass on a single batch and print output shapes
- Visualize the TPS deformation field as a grid overlay

### Section 3: Training
- Set up TensorBoardLogger and trainer
- Run `trainer.fit(model, train_dataloader, val_dataloader)`
- Embed TensorBoard widget: `%load_ext tensorboard` / `%tensorboard --logdir logs/`

### Section 4: Evaluation & Visualization
- Load best checkpoint
- Run on test split
- Display qualitative results: 5-column grid (person | garment | warped garment | synthesized | final result)
- Compute and display SSIM and LPIPS metrics on test set

### Section 5: Single Image Inference
- Upload `person.jpg` and `cloth.jpg` via `files.upload()` (Colab) or direct path
- Run inference and display result inline
- Save result with `PIL.Image`

---

## REQUIREMENTS.TXT

Generate a `requirements.txt` with exact pinned versions for all dependencies:
- `torch==2.2.1+cu121`
- `torchvision==0.17.1+cu121`
- `pytorch-lightning==2.2.1`
- `transformers==4.39.3`
- `timm==0.9.16`
- `omegaconf==2.3.0`
- `tensorboard==2.16.2`
- `Pillow==10.3.0`
- `numpy==1.26.4`
- `matplotlib==3.8.4`
- `tqdm==4.66.2`
- `scipy==1.13.0`
- `einops==0.7.0`
- `albumentations==1.4.3`
- Add any others your implementation requires with pinned versions

---

## CODE QUALITY STANDARDS

Every file must meet these standards:
1. **Type hints** on all function signatures using `torch.Tensor`, `Dict`, `Tuple`, `Optional`, etc.
2. **Docstrings** on every class and public method describing inputs, outputs, and shapes
3. **Shape comments** on every major tensor operation: `# [B, C, H, W]`
4. **No `print` statements** in production code — use Python `logging` module
5. **No hardcoded paths** anywhere except `configs/default.yaml`
6. **`__all__`** defined in every `__init__.py`
7. `if __name__ == '__main__':` blocks with smoke-test code in every model file (instantiate, run single forward pass, print output shapes)

---

## CRITICAL INTEGRATION NOTES

These integration requirements prevent the "chaos" of multi-model systems:

1. **Unified feature resolution contract:** All modules must agree on spatial resolutions. Define a `FEATURE_RESOLUTIONS` dict in `models/__init__.py`: `{4: (H//4, W//4), 8: (H//8, W//8), 16: (H//16, W//16)}` and import it everywhere. Never hardcode spatial sizes.

2. **Consistent normalization contract:** Define normalization constants once in `utils/constants.py`: `MEAN = [0.5, 0.5, 0.5]`, `STD = [0.5, 0.5, 0.5]` for RGB images. Import everywhere. Mask tensors are always in [0, 1]. Parsing maps are always class indices (long tensor).

3. **Batch-first everywhere:** All tensors are `[B, ...]` shaped. Never squeeze the batch dimension internally. The `CompositorHead` must handle batch inputs correctly.

4. **`cloth_warped` is the central artifact:** It flows from `AdaptiveWarpingModule` into both `ConditionalSynthesizer` (as generation conditioning) and `CompositorHead` (as blending input). Ensure its gradient flows are not stopped anywhere (no `.detach()` on `cloth_warped` unless explicitly configuring a two-stage training regime, which must be documented in config).

5. **Discriminator receives `I_final.detach()`** during discriminator update step, and `I_final` (not detached) during generator update step. Implement this correctly in `training_step` with `optimizer_idx` gating.

6. **Memory management:** The 1024×768 full-resolution pipeline is memory-intensive on A100 (80GB). Add `torch.cuda.empty_cache()` after validation steps. Use gradient checkpointing (`torch.utils.checkpoint.checkpoint`) in the `ConditionalSynthesizer` encoder if memory is tight. Add memory profiling comments estimating approximate VRAM usage per batch.

---

## OUTPUT DELIVERABLES

Generate the following in order, completely and without truncation:

1. `requirements.txt` — complete, pinned
2. `configs/default.yaml` — complete
3. `utils/constants.py` — normalization constants, feature resolution contract
4. `utils/viz.py` — TensorBoard image grid logging utilities
5. `utils/metrics.py` — SSIM, FID (using clean-fid), LPIPS metric computation
6. `models/tps.py` — Full differentiable TPS implementation
7. `models/body_encoder.py` — Full BodyStructureEncoder
8. `models/garment_extractor.py` — Full GarmentFeatureExtractor
9. `models/warping_module.py` — Full AdaptiveWarpingModule
10. `models/synthesizer.py` — Full ConditionalSynthesizer with SPADE (implemented from scratch)
11. `models/discriminator.py` — Full MultiScalePatchDiscriminator
12. `models/compositor.py` — Full CompositorHead
13. `models/__init__.py` — Exports + `FEATURE_RESOLUTIONS` dict
14. `losses/perceptual.py` — VGG perceptual loss
15. `losses/ssim.py` — SSIM loss from scratch
16. `losses/warp_reg.py` — Warp regularization
17. `losses/__init__.py`
18. `data/dataset.py` — Full VITONHDDataset with all 8 modalities
19. `training/lightning_module.py` — Full LightningModule
20. `training/trainer_setup.py` — Trainer configuration
21. `train.py` — Entry point
22. `inference/infer.py` — CLI inference script
23. `VirtualTryOn_Notebook.ipynb` — Complete, fully executable Jupyter Notebook (valid JSON format)

**Do not stop generating until all 23 files are complete. If you are approaching a response length limit, continue in your next response. Label each file clearly with its path as a header.**

---PROMPT END---
