# VITON-HD VIRTUAL TRY-ON SYSTEM — PRODUCTION PROMPT v7.0
## Challenge-Hardened | Numerically Stable | Memory-Optimal | Commercial-Grade

---

```
╔══════════════════════════════════════════════════════════════════════════════╗
║       VITON-HD VIRTUAL TRY-ON SYSTEM — PRODUCTION PROMPT v7.0              ║
║  Challenge-Hardened | Numerically Stable | Memory-Optimal | All 11 Mods    ║
╚══════════════════════════════════════════════════════════════════════════════╝

You are tasked with generating a COMPLETE, PRODUCTION-READY, COMMERCIALLY VIABLE
virtual try-on system from scratch. Every file must be fully implemented — no
`pass`, no `TODO`, no placeholder functions, no ellipsis (...) to abbreviate.
Code that cannot run on the first attempt is a hard failure.

Read this entire prompt before writing a single line of code.

═══════════════════════════════════════════════════════════════════════════════
SECTION 0 — ABSOLUTE CONSTRAINTS (VIOLATIONS ARE FATAL)
═══════════════════════════════════════════════════════════════════════════════

| # | Constraint                                               | Consequence           |
|---|----------------------------------------------------------|-----------------------|
| 1 | NO copied code from ANY open-source repository           | IP/legal liability    |
| 2 | NO exact class/function names from official repos        | Copyright risk        |
| 3 | ALL 37 files complete — zero truncation                  | Non-functional system |
| 4 | ALL functions fully implemented — no pass/TODO           | Runtime crash         |
| 5 | VITON-HD 11-modality structure preserved exactly         | Dataset load failure  |
| 6 | UNIFIED-25 label space mandatory — never raw LIP-20      | 60h refactor debt     |
| 7 | WARP WARM-UP: UNet new-channel weights frozen for 2 ep   | Warp never converges  |
| 8 | After warm-up: FULL JOINT training — no per-module freeze| Catastrophic forgetting|
| 9 | A100 80GB feasible — every module memory-annotated       | OOM, impossible train |
|10 | DatasetValidator MUST pass before any training begins    | Silent data corruption|
|11 | All tensor shapes explicitly asserted in forward()       | Silent shape bugs     |
|12 | TPS solver ALWAYS in FP32 regardless of training dtype   | NaN deformation field |
|13 | ip_scale initialized to 0.1, clamped to 3.0             | Attention instability |
|14 | EMA applied to ALL trainable parameters (not UNet only)  | Suboptimal inference  |
|15 | No preprocessing code needed — VITON-HD format assumed   | Scope violation       |
|16 | Jupyter Notebook executes cell-by-cell with no errors    | Non-reproducible      |

If context limit is reached mid-file: output exactly
  "=== CONTINUE: {filename} line {line_number} ==="
then continue from that exact line. Never summarize. Never skip. Never ellipsize.

═══════════════════════════════════════════════════════════════════════════════
SECTION 1 — ARCHITECTURE RATIONALE
═══════════════════════════════════════════════════════════════════════════════

## Why This Architecture (Production, Not Research Demo)

Commercial try-on has two failure modes:
  1. Pure GAN systems: sharp but geometrically wrong, artifacts on complex poses
  2. Pure diffusion: excellent quality but garment details hallucinated, texture drift

Your system addresses both with:
  - EXPLICIT TPS WARPING → garment placed anatomically correctly
  - LATENT DIFFUSION → photorealistic synthesis, no GAN artifacts
  - IP-ADAPTER → semantic garment identity preservation via CLIP tokens
  - DENSEPOSE + OPENPOSE + PARSE → comprehensive body geometry
  - WARP WARM-UP → prevents diffusion from learning before warp stabilizes
  - CONFIDENCE-WEIGHTED DENSEPOSE → robust to noisy/missing IUV maps

## Target Metrics (VITON-HD Test Set)

| Metric | Epoch 50 | Epoch 100 | Epoch 150 | Reference (IDM-VTON) |
|--------|----------|-----------|-----------|----------------------|
| FID ↓  | ≤ 9.0    | ≤ 7.0     | ≤ 6.0     | 6.29                 |
| LPIPS↓ | ≤ 0.09   | ≤ 0.07    | ≤ 0.06    | 0.0692               |
| SSIM ↑ | ≥ 0.85   | ≥ 0.88    | ≥ 0.90    | 0.8896               |

═══════════════════════════════════════════════════════════════════════════════
SECTION 2 — VITON-HD DATASET (11 MODALITIES — ALL USED)
═══════════════════════════════════════════════════════════════════════════════

## 2.1 Directory Structure (Exact)

viton_hd/
├── train/
│   ├── image/                    # [MOD-1]  Person RGB, 1024×768, JPG
│   ├── image-parse-v3/           # [MOD-2]  LIP-20 parse, PNG palette
│   ├── openpose-img/             # [MOD-3]  Rendered skeleton heatmap
│   ├── openpose-json/            # [MOD-4]  18 keypoints + confidence, JSON
│   ├── cloth/                    # [MOD-5]  Garment RGB, 1024×768, JPG
│   ├── cloth-mask/               # [MOD-6]  Binary garment mask, PNG
│   ├── agnostic-v3.2/            # [MOD-7]  Body-masked person, PNG
│   ├── agnostic-mask/            # [MOD-8]  Binary agnostic mask, PNG
│   ├── image-densepose/          # [MOD-9]  IUV map [R=part_id, G=U, B=V]
│   ├── warp-cloth/               # [MOD-10] Pre-warped cloth (GMM), optional
│   └── warp-cloth-mask/          # [MOD-11] Pre-warped cloth mask, optional
├── test/                         # Identical 11-subdir structure
├── train_pairs.txt
└── test_pairs.txt

## 2.2 Modality Usage Table

| Mod  | Shape            | Consumer                          | Purpose                        |
|------|-----------------|-----------------------------------|--------------------------------|
| MOD-1| [B,3,1024,768]  | BodyConditionEncoder Branch-A     | Agnostic conditioning source   |
| MOD-2| [B,1,1024,768]  | ParseMapEmbedder (after remap)    | Semantic region understanding  |
| MOD-3| [B,3,1024,768]  | BodyConditionEncoder Branch-B     | Skeleton heatmap visual        |
| MOD-4| [B,36] float32  | BodyConditionEncoder Branch-B     | Precise joint locations        |
| MOD-5| [B,3,1024,768]  | GarmentFeatureExtractor + IP-Adap | Appearance + identity          |
| MOD-6| [B,1,1024,768]  | GarmentFeatureExtractor + Warp    | Garment shape                  |
| MOD-7| [B,3,1024,768]  | BodyConditionEncoder Branch-A     | Pose-preserving body signal    |
| MOD-8| [B,1,1024,768]  | DiffusionUNet input ch 8          | Inpainting target region       |
| MOD-9| [B,3,1024,768]  | BodyConditionEncoder Branch-D     | 3D surface geometry            |
|MOD-10| [B,3,1024,768]  | WarpModule (auxiliary loss only)  | Geometric warp supervision     |
|MOD-11| [B,1,1024,768]  | WarpModule (auxiliary loss only)  | Warp mask supervision          |

═══════════════════════════════════════════════════════════════════════════════
SECTION 3 — UNIFIED-25 LABEL SPACE (MANDATORY)
═══════════════════════════════════════════════════════════════════════════════

## 3.1 Complete Class Table

UNIFIED25_CLASSES = {
    0:  "Background",
    1:  "Hat",
    2:  "Hair",
    3:  "Face",
    4:  "Neck-Scarf",
    5:  "Upper-Cloth",      # ← Phase 1 PRIMARY ACTIVE CLASS
    6:  "Kurta",            # Reserved — Indian textiles future
    7:  "Dress",            # Reserved — womenswear future
    8:  "Dupatta",          # Reserved — Indian textiles future
    9:  "Pants-Salwar",     # Reserved — lower-body future
    10: "Torso-Skin",
    11: "Coat",
    12: "Left-Arm",
    13: "Right-Arm",
    14: "Left-Leg",
    15: "Right-Leg",
    16: "Left-Shoe",
    17: "Right-Shoe",
    18: "Socks",
    19: "Skirt",            # Reserved
    20: "Sunglasses",
    21: "Gloves",
    22: "Left-Bag",
    23: "Right-Bag",
    24: "Belt",
}

GARMENT_CLASSES_UPPER = [5]    # Phase 1 only; extend by config, never by code change
DENSEPOSE_MIN_COVERAGE = 0.15  # Samples below this use confidence-weighted zero

## 3.2 LIP-20 → UNIFIED-25 Mapping (Exact)

LIP20_TO_UNIFIED25 = {
    0:  0,   # Background  → Background
    1:  1,   # Hat         → Hat
    2:  2,   # Hair        → Hair
    3:  21,  # Glove       → Gloves
    4:  20,  # Sunglasses  → Sunglasses
    5:  5,   # Upper-cloth → Upper-Cloth   ← CRITICAL: pixel count MUST be identical
    6:  7,   # Dress       → Dress
    7:  11,  # Coat        → Coat
    8:  18,  # Socks       → Socks
    9:  9,   # Pants       → Pants-Salwar
    10: 10,  # Torso-skin  → Torso-Skin
    11: 4,   # Scarf       → Neck-Scarf
    12: 19,  # Skirt       → Skirt
    13: 3,   # Face        → Face
    14: 12,  # Left-arm    → Left-Arm
    15: 13,  # Right-arm   → Right-Arm
    16: 14,  # Left-leg    → Left-Leg
    17: 15,  # Right-leg   → Right-Leg
    18: 16,  # Left-shoe   → Left-Shoe
    19: 17,  # Right-shoe  → Right-Shoe
}

## 3.3 remap_labels Implementation (utils/label_mapper.py)

def remap_labels(
    parse_map: torch.Tensor,   # [H, W] int64, values in [0, 19]
    mapping: dict,
    target_vocab_size: int = 25
) -> torch.Tensor:
    """
    Remap segmentation map from source to target label space.
    - Output dtype: torch.int64
    - Source classes not in mapping → 0 (background)
    - Output values guaranteed in [0, target_vocab_size)
    - Shape preserved: [H,W] → [H,W]
    
    VALIDATION (called by DatasetValidator test #5):
      raw_count_5  = (parse_lip20 == 5).sum()
      remapped_5   = (parse_u25   == 5).sum()
      assert raw_count_5 == remapped_5, "Class-5 pixel count must be identical"
    """
    max_source = max(mapping.keys()) + 1
    lut = torch.zeros(max_source, dtype=torch.int64, device=parse_map.device)
    for src, tgt in mapping.items():
        lut[src] = tgt
    clamped  = parse_map.clamp(0, max_source - 1)
    remapped = lut[clamped]
    assert remapped.max() < target_vocab_size, (
        f"Remapped class {remapped.max().item()} ≥ {target_vocab_size}"
    )
    return remapped

═══════════════════════════════════════════════════════════════════════════════
SECTION 4 — COMPLETE ARCHITECTURE (CHALLENGE-REFINED)
═══════════════════════════════════════════════════════════════════════════════

## 4.1 System Data Flow

INPUT BATCH (11 modalities from VITON-HD)
       │
       ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 1: BODY CONDITION ENCODING                                        │
│                                                                           │
│  Branch-A: SwinV2-Small(agnostic_img + agnostic_mask) → F_agn_4, F_agn_8│
│  Branch-B: PoseCNN(openpose_img) + MLP(keypoint_coords) → F_pose_8      │
│  Branch-C: ParseEmbedCNN(parse_u25, vocab=25) → F_parse_8               │
│  Branch-D: DensePoseCNN(iuv) × confidence_weight → F_dense_8_weighted   │
│                                                                           │
│  Cross-Attention Fusion → F_body = {F_b4, F_b8, F_b16}                  │
└──────────────────────────┬───────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 2: GARMENT FEATURE EXTRACTION                                     │
│                                                                           │
│  TextureCNN: ConvNeXt-Tiny(cloth_image) → F_g4, F_g8, F_g16             │
│  ShapeCNN: LightCNN(cloth_mask + augmented_cloth) → F_shape_8           │
│  GlobalPool → z_cloth [B, 512]                                           │
│  Fusion → F_garment_8 [B, 256, 128, 96]                                 │
└──────────────────────────┬───────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 3: PART-AWARE GEOMETRIC WARPING (2-phase)                         │
│                                                                           │
│  Phase 3a [Epochs 0-1, WARM-UP]: Train warp only                        │
│    PartSegmenter(F_b8) → 5 part masks (pseudo-label from parse)          │
│    LocalCorrelation(F_b8, F_g8, D=8) [BF16] → corr [B, 289, 128, 96]   │
│    WarpFlowPredictor → flow_fields [B, 5, 2, 128, 96]                    │
│    DifferentiableTPS [FP32 ALWAYS] → 5 TPS grids (init=identity)        │
│    Identity penalty L_identity → encourages near-zero early displacement  │
│    WarpBlender → cloth_warped, cloth_mask_warped, deformation_field      │
│                                                                           │
│  Phase 3b [Epochs 2+]: Full joint training with identity penalty decayed │
└──────────────────────────┬───────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 4: LATENT SPACE PREPARATION                                       │
│                                                                           │
│  FrozenVAE.encode(cloth_warped) → cloth_latent [B,4,128,96]             │
│  GarmentLatentAdapter(cloth_latent) → cloth_latent_adapted              │
│  FrozenVAE.encode(agnostic_image) → masked_person_latent                │
│  FrozenVAE.encode(person_image) → person_latent_clean (target)          │
└──────────────────────────┬───────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 5: IP-ADAPTER CONDITIONING                                        │
│                                                                           │
│  FrozenCLIP(cloth_image) → image_features [B, 257, 1024]                │
│  ImageProjectMLP → ip_tokens [B, 16, 768]                               │
│  ip_scale = 0.1 init, clamped to [0.0, 3.0]                             │
│  CFG dropout: 10% samples use null_emb instead of ip_tokens             │
└──────────────────────────┬───────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 6: 17-CHANNEL DIFFUSION SYNTHESIS                                 │
│                                                                           │
│  Channel  0- 3: noise_latent        [B,4,128,96]                        │
│  Channel  4- 7: masked_person_lat   [B,4,128,96]                        │
│  Channel  8:    agnostic_mask_ds    [B,1,128,96] (8× bilinear)          │
│  Channel  9-12: cloth_latent_adp    [B,4,128,96]                        │
│  Channel  13:   cloth_mask_warped_ds[B,1,128,96] (8× nearest)           │
│  Channel 14-16: parse_embedded      [B,3,128,96]                        │
│                                                                           │
│  SD 1.5 Inpainting UNet (17-ch) + IPAdapterAttnProcessor                │
│  EMA decay=0.9999 on ALL trainable params (not UNet only)               │
└──────────────────────────┬───────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  STAGE 7: REGION COMPOSITING                                             │
│                                                                           │
│  FrozenVAE.decode(denoised_latent) → I_synth [B,3,1024,768]             │
│  RegionCompositor: learned alpha + softened-agnostic BCE supervision     │
│  I_final = alpha * I_synth + (1-alpha) * person_image                   │
│  alpha constrained: zero OUTSIDE agnostic_mask region (hard prior)      │
└──────────────────────────────────────────────────────────────────────────┘

## 4.2 Module-by-Module Specification (Challenge-Refined)

### MODULE A: BodyConditionEncoder (models/body_encoder.py)
Memory budget: ~2.1 GB

Branch-A: SwinV2-Small Backbone
  Input:  concat(agnostic_image [B,3,...], agnostic_mask [B,1,...]) → [B,4,1024,768]
  Backbone: SwinV2-Small pretrained ImageNet (timm: swinv2_small_window8_256)
            Fine-tune ALL layers — no freezing
  Augmentation on agnostic: Random cutout patches (5% of pixels zeroed, p=0.3)
    Purpose: Forces model to rely on context, reduces overfitting on small dataset
  Output: F_agn_4 [B,128,256,192], F_agn_8 [B,256,128,96]

Branch-B: PoseCNN
  Input: openpose_img [B,3,1024,768] (MOD-3), keypoint_coords [B,36] from MOD-4
  Augmentation on keypoint_coords: Gaussian noise σ=0.005 (normalized coords)
    Purpose: Makes pose estimation robust to imprecise keypoints
  Heatmap stream:
    Conv2d(3→64, 7, stride=2, pad=3) → GN8 → GELU
    Conv2d(64→128, 3, stride=2, pad=1) → GN16 → GELU
    Conv2d(128→256, 3, stride=2, pad=1) → GN32 → GELU
    → F_pose_heatmap [B,256,128,96]
  Keypoint stream:
    MLP: Linear(36→128) → GELU → Linear(128→256*12)
    Reshape → [B,256,1,12] → broadcast add to F_pose_heatmap [B,256,128,96]
    Purpose: Provides precise location priors even when heatmap is coarse
  Output: F_pose_8 [B,256,128,96]

Branch-C: ParseMapEmbedCNN
  Input: parse_unified25 [B,1,1024,768] int64 (UNIFIED-25, not raw LIP-20)
  Embedding: nn.Embedding(num_embeddings=25, embedding_dim=64)
  ChannelAttention: sigmoid gate on per-class frequency → reweights embedding
    (Classes with 0% pixel frequency in batch get near-zero weight)
  Strided CNN: 64→64→64→32→3 channels, total stride=8 → [B,3,128,96]
  Full features: 64→256 via intermediate projection → F_parse_8 [B,256,128,96]
  Output: F_parse_8 [B,256,128,96]

Branch-D: DensePoseCNN — CONFIDENCE-WEIGHTED (Challenge 3 mitigation)
  Input: densepose_iuv [B,3,1024,768] (MOD-9), use_densepose [B] bool
  
  CONFIDENCE-WEIGHTED FUSION (replaces binary on/off):
  
    Step 1: Compute per-sample coverage score
      part_ids = densepose_iuv[:,0]  # R channel = part ID
      coverage = (part_ids > 0).float().mean(dim=[1,2])  # [B] scalar per sample
    
    Step 2: Compute confidence weight (soft, not binary)
      confidence = torch.clamp(coverage / DENSEPOSE_MIN_COVERAGE, 0.0, 1.0)  # [B]
      # This smoothly scales from 0 (no coverage) to 1 (full coverage)
      # Avoids hard threshold that wastes partial DensePose information
    
    Step 3: Part embedding + UV encoding
      part_emb = nn.Embedding(25, 32)(part_ids.long())   # [B,32,H,W]
      uv_enc   = Conv2d(2, 64)(densepose_iuv[:,1:])      # [B,64,H,W]
      combined = concat(part_emb, uv_enc, dim=1)         # [B,96,H,W]
      F_dense  = strided_cnn(combined)                   # [B,256,128,96]
    
    Step 4: Apply confidence weight
      conf_weight = confidence.view(B, 1, 1, 1)          # broadcast
      F_dense_8   = F_dense * conf_weight                # zero if no coverage
                                                         # partial if partial
  
  Output: F_dense_8 [B,256,128,96]  (confidence-weighted, never hard-zero)

Cross-Attention Fusion:
  Q: from F_agn_8 → reshape [B,256,12288]
  KV: from concat(F_pose_8, F_parse_8, F_dense_8) → reshape [B,256,3*12288]
  MultiheadAttention(embed_dim=256, num_heads=8, dropout=0.1)
  Residual + LayerNorm → F_body_8 [B,256,128,96]
  
  Output:
    F_b4  [B,128,256,192]  (transposed conv + skip F_agn_4)
    F_b8  [B,256,128, 96]  (= F_body_8)
    F_b16 [B,512, 64,  48] (strided conv from F_body_8)
  
  ASSERT ALL SHAPES:
    assert F_b4.shape  == (B, 128, 256, 192)
    assert F_b8.shape  == (B, 256, 128,  96)
    assert F_b16.shape == (B, 512,  64,  48)

### MODULE B: GarmentFeatureExtractor (models/garment_extractor.py)
Memory budget: ~1.4 GB

TextureEncoder: ConvNeXt-Tiny (timm: convnext_tiny, pretrained=True, fine-tune all)
  Input augmentations on cloth_image ONLY (not applied to agnostic/pose):
    - Random color jitter: brightness=0.15, contrast=0.15, saturation=0.10, hue=0.05
    - Random affine: rotation=±5°, scale=0.95-1.05, shear=±3°
      Purpose: Simulates different garment photography conditions
      Applied only to cloth_image, NOT to cloth_mask (use same transform)
      NOTE: Same affine transform applied jointly to cloth_image + cloth_mask
  Output: F_g4 [B,96,256,192], F_g8 [B,192,128,96], F_g16 [B,384,64,48]

ShapeEncoder: LightweightCNN
  Input: cloth_mask [B,1,1024,768] (affine-augmented same as cloth_image)
  Architecture: 1→16→32→64→128 channels, stride-8, GN+GELU throughout
  Output: F_shape_8 [B,128,128,96]

GlobalPool:
  F_g8 → AdaptiveAvgPool2d(1) → Flatten → Linear(192,512) → GELU
  Output: z_cloth [B,512]

Fusion:
  Concat(F_g8, F_shape_8) [B,320,128,96] → Conv2d(320,256,1) → F_garment_8
  ASSERT: F_garment_8.shape == (B, 256, 128, 96)
  ASSERT: z_cloth.shape == (B, 512)

### MODULE C: DifferentiableTPS (models/tps.py) — CHALLENGE-HARDENED
Memory budget: ~0.3 GB

CRITICAL IMPLEMENTATION NOTES (Challenge 1 mitigations):

class DifferentiableTPS(nn.Module):
  """
  Thin-plate spline warping — implemented from scratch.
  Key production hardening:
    1. Control points initialized to IDENTITY (no-warp) grid
    2. FP32 solve regardless of training dtype
    3. Regularized K matrix (lambda_reg=1e-5) before solve
    4. Grid clamped to [-1.1, 1.1] to prevent extreme extrapolation
    5. Identity penalty loss to anchor early training
  """
  
  def __init__(self, n_cp: int = 25, lambda_reg: float = 1e-5):
    self.n_cp = n_cp  # 5×5 control points
    self.lambda_reg = lambda_reg
    
    # IDENTITY INITIALIZATION (Challenge 1 mitigation):
    # Create regular 5×5 grid in [-0.8, 0.8] as source control points
    # Target initialized to SAME positions → identity transform at epoch 0
    # This prevents TPS instability before warping features are meaningful
    lin = torch.linspace(-0.8, 0.8, 5)
    grid_y, grid_x = torch.meshgrid(lin, lin, indexing='ij')
    self.register_buffer('ctrl_pts_src_default',
        torch.stack([grid_x.flatten(), grid_y.flatten()], dim=1))  # [25,2]
  
  def forward(
      self,
      ctrl_pts_src: torch.Tensor,   # [B, 25, 2] normalized coords in [-1,1]
      ctrl_pts_tgt: torch.Tensor,   # [B, 25, 2] displaced coords
      output_size: tuple             # (H, W)
  ) -> torch.Tensor:                 # [B, H, W, 2] for F.grid_sample
    
    B = ctrl_pts_src.shape[0]
    
    # Step 1: RBF kernel matrix (radial basis functions)
    #   K_ij = phi(||p_i - p_j||) where phi(r) = r² log(r + eps)
    diff = ctrl_pts_src.unsqueeze(2) - ctrl_pts_src.unsqueeze(1)  # [B,25,25,2]
    dist = diff.norm(dim=-1)                                        # [B,25,25]
    K = dist**2 * torch.log(dist + 1e-8)                           # [B,25,25]
    
    # Step 2: P matrix [B,25,3] = [ones, x_coords, y_coords]
    ones = torch.ones(B, self.n_cp, 1, device=ctrl_pts_src.device,
                      dtype=ctrl_pts_src.dtype)
    P = torch.cat([ones, ctrl_pts_src], dim=-1)  # [B,25,3]
    
    # Step 3: Full system L [B,28,28]
    zeros_33 = torch.zeros(B, 3, 3, device=K.device, dtype=K.dtype)
    top    = torch.cat([K, P],                dim=-1)  # [B,25,28]
    bottom = torch.cat([P.transpose(1,2), zeros_33], dim=-1)  # [B,3,28]
    L = torch.cat([top, bottom], dim=1)  # [B,28,28]
    
    # Step 4: REGULARIZE and SOLVE IN FP32 (CRITICAL)
    I_25 = torch.eye(self.n_cp, device=K.device, dtype=K.dtype).unsqueeze(0)
    K_reg = K + self.lambda_reg * I_25
    L_reg = L.clone()
    L_reg[:, :self.n_cp, :self.n_cp] = K_reg
    
    Y_top    = ctrl_pts_tgt                                       # [B,25,2]
    Y_bottom = torch.zeros(B, 3, 2, device=K.device, dtype=K.dtype)
    Y = torch.cat([Y_top, Y_bottom], dim=1)                      # [B,28,2]
    
    # ALWAYS solve in FP32 — critical for numerical stability in BF16 training
    coeffs = torch.linalg.solve(L_reg.float(), Y.float())        # [B,28,2]
    coeffs = coeffs.to(ctrl_pts_src.dtype)
    
    # Step 5: Evaluate TPS at all output grid points
    H, W = output_size
    gy, gx = torch.meshgrid(
        torch.linspace(-1, 1, H, device=ctrl_pts_src.device),
        torch.linspace(-1, 1, W, device=ctrl_pts_src.device),
        indexing='ij'
    )
    grid_pts = torch.stack([gx.flatten(), gy.flatten()], dim=1)  # [H*W,2]
    grid_pts = grid_pts.unsqueeze(0).expand(B, -1, -1)           # [B,H*W,2]
    
    # RBF for grid points vs control points
    diff2 = grid_pts.unsqueeze(2) - ctrl_pts_src.unsqueeze(1)    # [B,H*W,25,2]
    dist2 = diff2.norm(dim=-1)                                    # [B,H*W,25]
    phi   = dist2**2 * torch.log(dist2 + 1e-8)                   # [B,H*W,25]
    
    ones2 = torch.ones(B, H*W, 1, device=grid_pts.device, dtype=grid_pts.dtype)
    P2 = torch.cat([ones2, grid_pts], dim=-1)  # [B,H*W,3]
    
    basis = torch.cat([phi, P2], dim=-1)        # [B,H*W,28]
    warped_grid = basis @ coeffs                # [B,H*W,2]
    warped_grid = warped_grid.view(B, H, W, 2)
    
    # Step 6: Clamp to prevent extreme extrapolation artifacts
    warped_grid = warped_grid.clamp(-1.1, 1.1)
    
    return warped_grid

  def identity_penalty(
      self,
      ctrl_pts_src: torch.Tensor,   # [B,25,2]
      ctrl_pts_tgt: torch.Tensor    # [B,25,2]
  ) -> torch.Tensor:
    """
    L2 penalty on displacement from identity. Decays during training.
    Anchors TPS to no-warp at epoch 0 when correlation features are noisy.
    Loss = mean(||tgt - src||²)
    """
    displacement = ctrl_pts_tgt - ctrl_pts_src
    return (displacement ** 2).mean()

### MODULE D: PartAwareWarpingModule (models/warping.py)
Memory budget: ~1.8 GB (correlation volume dominates)

Sub-module D.1: PartSegmenter
  Input: F_b8 [B,256,128,96]
  Architecture: 3-layer decoder → Conv2d(?,5,1) → softmax
  Output: part_masks [B,5,128,96]
  Supervision: L_part_seg from parse_unified25 (soft pseudo-labels)
  5 parts:
    0: Torso-front  (UNIFIED-25: 5=Upper-Cloth, 10=Torso-Skin)
    1: Left-sleeve  (UNIFIED-25: 12=Left-Arm)
    2: Right-sleeve (UNIFIED-25: 13=Right-Arm)
    3: Lower-front  (UNIFIED-25: 9, 14, 15)
    4: Lower-back   (UNIFIED-25: 16, 17)

Sub-module D.2: LocalCorrelationVolume — BF16 MEMORY OPTIMIZATION (Challenge 2)
  Inputs: F_b8, F_garment_8  both [B,256,128,96]
  max_displacement D = 8 (reduce to 6 if OOM)
  
  BF16 OPTIMIZATION: Run correlation in BF16 (not FP32) — safe since it's
    just normalized dot products, not a linear system solve.
    torch.autocast context: enabled for this operation when training BF16.
  
  Algorithm:
    # L2 normalize (numerically critical step — do in FP32 for safety)
    f1 = F.normalize(F_b8.float(), dim=1).to(F_b8.dtype)
    f2 = F.normalize(F_garment_8.float(), dim=1).to(F_garment_8.dtype)
    
    # Pad f2 for local search
    f2_pad = F.pad(f2, [D, D, D, D])  # [B,C,H+2D,W+2D]
    
    # Unfold to [B, C*(2D+1)², H*W]
    f2_unfold = F.unfold(f2_pad, kernel_size=2*D+1, stride=1)
    f2_unfold = f2_unfold.view(B, C, (2*D+1)**2, H*W)
    f1_flat   = f1.view(B, C, H*W)
    
    # Correlation (einsum, batched)
    corr = torch.einsum('bcn,bcqn->bqn', f1_flat, f2_unfold)   # [B,289,H*W]
    corr = corr.view(B, (2*D+1)**2, H, W)                       # [B,289,128,96]
    corr = corr / math.sqrt(C)                                   # scale normalize
  
  Output: corr_vol [B,289,128,96]
  Memory: 289 * 128 * 96 * B * 2 bytes (BF16) ≈ 284 MB for B=4

Sub-module D.3: WarpFlowPredictor
  Input: corr_vol [B,289,128,96], z_cloth [B,512], part_masks [B,5,128,96]
  SharedEncoder: Conv(289+5→256→128) + residual blocks
  z_cloth projection: Linear(512→128) → unsqueeze → broadcast-add
  Per-part heads: 5× [Conv(128→64→2)]
  Output: flow_fields [B,5,2,128,96]

Sub-module D.4: DifferentiableTPS (from models/tps.py)
  Used: one per part → 5× TPS instances sharing weights (reduces parameters)
  Source control points: regular 5×5 grid
  Target: source + flow_field predictions from D.3
  Output: 5 warp grids at stride-8 → upsample to [B,5,1024,768,2]

Sub-module D.5: WarpBlender
  Softmax over part_masks (dim=1) → normalized blend weights
  For each part p:
    warped_p = F.grid_sample(cloth_image, tps_grids[:,p], align_corners=True,
                              mode='bilinear', padding_mode='border')
    warped_mask_p = F.grid_sample(cloth_mask, tps_grids[:,p], align_corners=True,
                                   mode='nearest', padding_mode='zeros')
  Weighted blend:
    cloth_warped      = sum_p(part_masks[:,p:p+1] * warped_p)
    cloth_mask_warped = sum_p(part_masks[:,p:p+1] * warped_mask_p)

Full output dict (ASSERT ALL SHAPES):
  {
    "cloth_warped":      [B,3,1024,768],
    "cloth_mask_warped": [B,1,1024,768],
    "deformation_field": [B,2, 128,  96],  # for smoothness loss
    "part_masks_full":   [B,5,1024, 768],  # upsampled for visualization
    "ctrl_pts_src":      [B,5, 25,    2],  # for identity penalty loss
    "ctrl_pts_tgt":      [B,5, 25,    2],  # for identity penalty loss
  }

### MODULE E: GarmentLatentAdapter (models/garment_adapter.py)
Memory: ~0.1 GB

Input: cloth_warped [B,3,1024,768]

Step 1: Frozen VAE encode (NO GRAD — always)
  with torch.no_grad():
    latent = frozen_vae.encode(cloth_warped).latent_dist.sample()
    latent = latent * 0.18215  # SD scaling factor
  latent: [B,4,128,96]

Step 2: 1×1 Adaptation (trainable)
  nn.Sequential(
      nn.Conv2d(4, 4, 1, bias=True),
      nn.GroupNorm(4, 4),
      nn.GELU(),
      nn.Conv2d(4, 4, 1, bias=True),
  )
  cloth_latent_adapted: [B,4,128,96]

ASSERT: cloth_latent_adapted.shape == (B, 4, 128, 96)

### MODULE F: IPAdapterProjection (models/ip_adapter.py)
Memory: ~0.9 GB

CRITICAL INITIALIZATIONS (Challenge 4 mitigations):
  ip_scale = nn.Parameter(torch.tensor(0.1))  # NOT 1.0 — start weak
  CLAMP in forward: ip_scale.data.clamp_(0.0, 3.0) before use
  null_emb = nn.Parameter(torch.zeros(1, 16, 768))  # CFG null embedding

FrozenCLIPEncoder:
  Load: openai/clip-vit-large-patch14
  ALL parameters: requires_grad = False
  Input: cloth_image → bicubic resize to [B,3,224,224] with antialias=True
  Output: last_hidden_state [B,257,1024]  (CLS + 256 patch tokens — USE BOTH)

TrainableProjection:
  # Use CLS + spatial patch tokens for richer texture signal
  image_features_mean = clip_out.last_hidden_state.mean(dim=1)  # [B,1024]
  ip_tokens_flat = ImageProjectMLP(image_features_mean)          # [B,16*768]
  ip_tokens = ip_tokens_flat.view(B, 16, 768)                    # [B,16,768]

CFG Dropout (training only, p=0.1):
  drop_mask = torch.rand(B, 1, 1, device=ip_tokens.device) < 0.1
  null = self.null_emb.expand(B, -1, -1)
  ip_tokens = torch.where(drop_mask, null, ip_tokens)

K/V Projection (trainable):
  ip_keys   = self.ip_to_k(ip_tokens)   # [B,16,768]
  ip_values = self.ip_to_v(ip_tokens)   # [B,16,768]

Attention Scale Application (in IPAdapterAttnProcessor):
  clamped_scale = self.ip_scale.clamp(0.0, 3.0)
  hidden_states = hidden_standard + clamped_scale * hidden_ip

Monitoring (logged every 100 steps):
  log("model/ip_scale", self.ip_scale.item())
  # If ip_scale stays near 3.0 for >500 steps → lower ip_adapter LR by 50%

### MODULE G: ParseMapEmbedder (models/parse_embedder.py)
Memory: ~0.05 GB

embedding = nn.Embedding(num_embeddings=25, embedding_dim=64)
# Weight init: normal(0, 0.01) — smaller than default for stability

ChannelAttention gate:
  # Compute class frequency in current batch
  freq = torch.zeros(B, 25, device=parse.device)
  for c in range(25):
    freq[:,c] = (parse_map == c).float().mean(dim=[1,2])  # [B]
  freq_mean = freq.mean(dim=0)  # [25] global batch frequency
  gate = torch.sigmoid(nn.Linear(25,25)(freq_mean))  # [25] learned gate
  # Modulate embedding lookup by gate (broadcast over spatial)

spatial_encoder = nn.Sequential(
    nn.Conv2d(64, 64, 3, stride=2, padding=1),   # [B,64,512,384]
    nn.GroupNorm(8, 64), nn.GELU(),
    nn.Conv2d(64, 64, 3, stride=2, padding=1),   # [B,64,256,192]
    nn.GroupNorm(8, 64), nn.GELU(),
    nn.Conv2d(64, 32, 3, stride=2, padding=1),   # [B,32,128, 96]
    nn.GroupNorm(8, 32), nn.GELU(),
    nn.Conv2d(32,  3, 1),                          # [B, 3,128, 96]
)

ASSERT: output.shape == (B, 3, 128, 96)

### MODULE H: DiffusionSynthesisUNet (models/diffusion_unet.py)
Memory: ~6.5 GB (largest module)

Base: runwayml/stable-diffusion-inpainting
Original conv_in: Conv2d(9, 320, 3, 1, 1)
Modified conv_in: Conv2d(17, 320, 3, 1, 1)

Weight init strategy:
  old_weight = pretrained_state['conv_in.weight']    # [320,9,3,3]
  new_conv = nn.Conv2d(17, 320, 3, 1, 1)
  new_conv.weight.data[:, :9]  = old_weight          # Preserve pretrained
  new_conv.weight.data[:, 9:]  = torch.randn(320,8,3,3) * 0.01  # Near-zero init
  new_conv.bias.data           = pretrained_state['conv_in.bias']

WARP WARM-UP (Constraint #7 — implemented in LightningModule):
  During epochs 0-1:
    - Freeze ALL UNet parameters EXCEPT conv_in (new channels 9-16)
    - This allows warp to learn geometry before diffusion trains on it
    - UNet still participates via pretrained channels 0-8 (denoising)
  From epoch 2:
    - Unfreeze ALL UNet parameters → full joint training
    - Do NOT re-freeze any module after this point

IPAdapterAttnProcessor:
  Replaces every cross-attention processor in UNet
  
  class IPAdapterAttnProcessor:
    def __call__(self, attn_module, hidden_states, encoder_hidden_states, ...):
      ip_keys, ip_values, ip_scale_param = encoder_hidden_states  # unpacked tuple
      
      # Standard self-attention (no text conditioning)
      query = attn_module.to_q(hidden_states)
      key   = attn_module.to_k(hidden_states)
      value = attn_module.to_v(hidden_states)
      attn_standard = scaled_dot_product_attention(query, key, value)
      
      # IP cross-attention
      ip_k  = attn_module.to_k(ip_keys)   # [B,16,head_dim]
      ip_v  = attn_module.to_v(ip_values) # [B,16,head_dim]
      attn_ip = scaled_dot_product_attention(query, ip_k, ip_v)
      
      # Combine with clamped scale
      clamped = ip_scale_param.clamp(0.0, 3.0)
      output  = attn_standard + clamped * attn_ip
      
      return attn_module.to_out[0](output)

EMA (Challenge 9 — ALL trainable params, not UNet only):
  # Covers: body_encoder, garment_extractor, warping, garment_adapter,
  #         ip_adapter projection, parse_embedder, diffusion_unet, compositor
  ema = ExponentialMovingAverage(
      [p for p in model.parameters() if p.requires_grad],
      decay=0.9999
  )
  # Update every 10 training steps (in on_train_batch_end)
  # At inference: ALWAYS use EMA weights (context manager)
  
  ASSERTION in inference code:
    # EMA and live weights must differ if training > 100 steps
    ema_sample = list(ema.shadow_params)[0]
    live_sample = list(model.parameters())[0]
    assert not torch.allclose(ema_sample, live_sample), \
        "EMA weights identical to live weights — EMA may not be updating"

### MODULE I: RegionCompositor (models/compositor.py)
Memory: ~0.3 GB — ENHANCED (Challenge 10 mitigation)

DESIGN DECISION: Use learned compositor WITH direct supervision via softened
agnostic mask BCE. This gives a clear training signal without requiring ground-
truth alpha masks.

Architecture:
  Input: concat(I_synth [B,3,...], person_image [B,3,...], agnostic_mask [B,1,...])
         → [B,7,1024,768]
  
  fusion_net = nn.Sequential(
      nn.Conv2d(7, 32, 3, padding=1), nn.GroupNorm(8, 32), nn.GELU(),
      nn.Conv2d(32, 32, 3, padding=1), nn.GroupNorm(8, 32), nn.GELU(),
      nn.Conv2d(32, 1, 1),  # → raw alpha logit [B,1,H,W]
  )

forward(I_synth, person_image, agnostic_mask):
  concat_inp = torch.cat([I_synth, person_image, agnostic_mask], dim=1)
  alpha_logit = self.fusion_net(concat_inp)    # [B,1,1024,768]
  alpha = torch.sigmoid(alpha_logit)           # [B,1,1024,768]
  
  # HARD PRIOR: zero alpha outside agnostic_mask region
  # This prevents compositor from modifying face, hair, background
  alpha = alpha * agnostic_mask
  
  I_final = alpha * I_synth + (1 - alpha) * person_image
  
  ASSERT I_final.shape == (B, 3, 1024, 768)
  return I_final, alpha, alpha_logit  # logit returned for BCE supervision

Compositor Loss (L_comp — direct supervision):
  # Softened agnostic mask as pseudo ground-truth alpha target
  # Softening: dilate mask slightly, apply gaussian blur → soft edges
  soft_mask = gaussian_blur(agnostic_mask, sigma=3.0)  # [B,1,H,W]
  soft_mask = soft_mask.clamp(0.0, 1.0)
  
  # BCE loss on alpha logit vs softened mask
  # Weighted: upweight boundary pixels where accuracy matters most
  boundary_weight = 1.0 + 2.0 * edge_detect(agnostic_mask)  # [B,1,H,W]
  L_comp = (boundary_weight * F.binary_cross_entropy_with_logits(
      alpha_logit, soft_mask, reduction='none'
  )).mean()
  
  # This gives compositor a direct training signal from epoch 1
  # without requiring ground-truth alpha maps

═══════════════════════════════════════════════════════════════════════════════
SECTION 5 — LOSS FUNCTIONS (CHALLENGE-REFINED)
═══════════════════════════════════════════════════════════════════════════════

## 5.1 Complete Loss Taxonomy

Total Loss = λ_denoise   * L_denoise     # SNR-weighted noise prediction
           + λ_x0_perc   * L_x0_perc    # VGG-19 perceptual on x0 prediction
           + λ_ssim      * L_ssim       # Gaussian SSIM on x0 prediction
           + λ_warp_s    * L_warp_s     # TPS 2nd-order smoothness (Laplacian)
           + λ_warp_m    * L_warp_m     # Warp mask BCE vs MOD-11
           + λ_warp_pt   * L_warp_pt    # Pre-warped cloth L1 vs MOD-10
           + λ_identity  * L_identity   # TPS identity penalty (decays to 0)
           + λ_part_seg  * L_part_seg   # Part seg soft pseudo-supervision
           + λ_comp      * L_comp       # Compositor BCE with softened mask

## 5.2 Dynamic Loss Weight Schedule (Challenge 5 — Refined)

def get_loss_weights(epoch: int) -> dict:
  """
  3-phase schedule optimized for challenge mitigations:
  
  WARM-UP (0-1): Warp-only phase. UNet new channels training.
    - Identity penalty HIGH → TPS stays near identity
    - Warp pretrain HIGH → MOD-10 bootstraps geometry
    - Denoise VERY LOW → UNet contribution minimal
    
  STABILIZATION (2-20): Full joint training begins.
    - Identity penalty DECAYS linearly to 0 by epoch 20
    - Warp losses still dominant
    - Denoise gradually increases
    
  BALANCED (20-80): Main training phase.
    - Identity penalty: 0 (fully decayed)
    - Warp pretrain: 0 (fully decayed by epoch 20)
    - All losses balanced per quality metric targets
    
  QUALITY (80-150): Diffusion and quality metrics dominate.
    - Warp regularization maintained (not zero — prevents drift)
    - Perceptual + SSIM upweighted for final polish
  """
  
  if epoch <= 1:        # WARM-UP: warp only (UNet new channels only)
    identity_w = 5.0
    warp_pt_w  = 3.0
    return {
        'lambda_denoise':  0.2,
        'lambda_x0_perc':  0.0,
        'lambda_ssim':     0.0,
        'lambda_warp_s':   80.0,
        'lambda_warp_m':   3.0,
        'lambda_warp_pt':  warp_pt_w,
        'lambda_identity': identity_w,
        'lambda_part_seg': 1.0,
        'lambda_comp':     0.1,
    }
  
  elif epoch <= 20:     # STABILIZATION: identity decays, warp dominant
    t           = (epoch - 2) / 18.0                         # 0 → 1
    identity_w  = 5.0 * max(0.0, 1.0 - t)                   # 5 → 0
    warp_pt_w   = 2.0 * max(0.0, 1.0 - (epoch - 2) / 18.0)  # 2 → 0
    return {
        'lambda_denoise':  0.5 + 0.5 * t,   # 0.5 → 1.0
        'lambda_x0_perc':  0.02,
        'lambda_ssim':     0.02,
        'lambda_warp_s':   60.0,
        'lambda_warp_m':   2.0,
        'lambda_warp_pt':  warp_pt_w,
        'lambda_identity': identity_w,
        'lambda_part_seg': 0.5,
        'lambda_comp':     0.3,
    }
  
  elif epoch <= 80:     # BALANCED
    return {
        'lambda_denoise':  1.0,
        'lambda_x0_perc':  0.05,
        'lambda_ssim':     0.05,
        'lambda_warp_s':   40.0,
        'lambda_warp_m':   1.0,
        'lambda_warp_pt':  0.0,
        'lambda_identity': 0.0,
        'lambda_part_seg': 0.5,
        'lambda_comp':     0.5,
    }
  
  else:                 # QUALITY
    return {
        'lambda_denoise':  1.2,
        'lambda_x0_perc':  0.08,
        'lambda_ssim':     0.08,
        'lambda_warp_s':   25.0,
        'lambda_warp_m':   0.5,
        'lambda_warp_pt':  0.0,
        'lambda_identity': 0.0,
        'lambda_part_seg': 0.3,
        'lambda_comp':     0.5,
    }

## 5.3 Per-Loss Implementations

### L_denoise (losses/diffusion_loss.py)
SNR-weighted (Min-SNR, snr_gamma=5.0):
  snr      = alphas_cumprod / (1 - alphas_cumprod)          # [B]
  weights  = min(snr, snr_gamma) / snr                      # [B]
  loss     = (weights * mse(eps_pred, eps_target, 'none').mean([1,2,3])).mean()
  Purpose: Prevents high-noise timesteps from dominating learning signal.

### L_x0_perc (losses/perceptual.py)
VGG-19 feature matching at relu1_2, relu2_2, relu3_3, relu4_3
ALL VGG weights FROZEN (requires_grad=False)
Inputs normalized to VGG expected range before feature extraction
Layer weights: 1/32, 1/16, 1/8, 1/4 (finer features weighted more)

### L_ssim (losses/ssim_loss.py)
loss = 1 - SSIM(pred, target)
Gaussian window size=11, sigma=1.5
C1=(0.01×2)², C2=(0.03×2)²
Inputs normalized to [0,1] internally

### L_warp_s (losses/warp_losses.py)
2nd-order Laplacian on deformation_field [B,2,H,W]
  d2u_dx2 = u[:,   :, 1:-1, :] * 2 - u[:,:,:-2,:] - u[:,:,2:,:]
  d2u_dy2 = u[:,:,:,1:-1   ] * 2 - u[:,:,:,:-2]  - u[:,:,:,2:]
  loss = (d2u_dx2**2).mean() + (d2u_dy2**2).mean() (both flow channels)

### L_warp_m (losses/warp_losses.py)
BCE(cloth_mask_warped_logit, warp_mask_target)
Only computed when warp_mask_target is not None (MOD-11 present).
Returns 0.0 tensor when MOD-11 absent.

### L_warp_pt (losses/warp_losses.py)
L1 on masked region: loss = (|cloth_warped - warp_cloth_gt| × mask).mean()
Returns 0.0 tensor when warp_cloth_gt is None.

### L_identity (losses/warp_losses.py — NEW)
From DifferentiableTPS.identity_penalty():
  loss = mean(||ctrl_pts_tgt - ctrl_pts_src||²) over all 5 parts
Purpose: Anchors TPS to near-identity early in training when correlation
  features are not yet meaningful.
Schedule: 5.0 → 0.0, fully decayed by epoch 20.

### L_part_seg (losses/warp_losses.py)
Soft pseudo-labels from UNIFIED-25 parse → 5 warp parts mapping:
  Part 0: classes [5, 10] → torso
  Part 1: class  [12]     → left sleeve
  Part 2: class  [13]     → right sleeve
  Part 3: classes [9,14,15]→ lower front
  Part 4: classes [16,17] → lower back
Temperature-scaled BCE (T=2.0) — acknowledges approximate mapping.
part_masks_full upsampled to 1024×768 before comparing to parse.

### L_comp (losses/warp_losses.py — ENHANCED)
From RegionCompositor, softened agnostic mask BCE:
  soft_mask = gaussian_blur(agnostic_mask, sigma=3.0).clamp(0,1)
  boundary_weight = 1.0 + 2.0 * edge_detect(agnostic_mask)
  loss = (boundary_weight × BCE(alpha_logit, soft_mask)).mean()

═══════════════════════════════════════════════════════════════════════════════
SECTION 6 — DATASET LOADING (CHALLENGE-REFINED)
═══════════════════════════════════════════════════════════════════════════════

## 6.1 VITONHDDataset (data/dataset_vitonhd.py)

Required output keys and specs:
  'person_image':      float32 [3,1024,768], [-1,1]
  'parse_lip20':       int64   [1,1024,768], [0,19]
  'parse_unified25':   int64   [1,1024,768], [0,24]
  'openpose_img':      float32 [3,1024,768], [-1,1]
  'keypoint_coords':   float32 [36]         normalized [0,1], zeros if no person
  'cloth_image':       float32 [3,1024,768], [-1,1]  (after augmentation)
  'cloth_image_raw':   float32 [3,1024,768], [-1,1]  (pre-augmentation, for CLIP)
  'cloth_mask':        float32 [1,1024,768], [0,1]
  'agnostic_image':    float32 [3,1024,768], [-1,1]
  'agnostic_mask':     float32 [1,1024,768], [0,1]   (binary)
  'densepose_iuv':     float32 [3,1024,768], [0,1]
  'densepose_coverage':float32 scalar        (per-sample, not boolean)
  'warp_cloth':        float32 [3,1024,768] or None
  'warp_cloth_mask':   float32 [1,1024,768] or None
  'person_id':         str
  'cloth_id':          str

IMPORTANT: cloth_image_raw is sent to CLIP encoder (unaugmented).
          cloth_image (augmented) is sent to garment_extractor.
          This prevents color jitter from confusing semantic CLIP features.

Augmentation (training only — applied JOINTLY where noted):

  JOINT augmentation (same random state applied to ALL spatial mods):
    Horizontal flip (p=0.5):
      Applied to: person_image, parse maps, openpose_img, agnostic_image,
                  agnostic_mask, densepose_iuv, cloth_image, cloth_mask,
                  warp_cloth (if present), warp_cloth_mask (if present)
      Keypoint flip: x_new = 1.0 - x_old, swap left/right joint pairs:
        (2,5), (3,6), (4,7), (8,11), (9,12), (10,13), (14,17), (15,18), (16,19)
        [OpenPose 18-joint pairing by body symmetry]

  CLOTH-ONLY augmentation (applied to cloth_image + cloth_mask jointly):
    Random affine (p=0.5):
      rotation: ±5°, scale: 0.95-1.05, shear: ±3°
      interpolation: bilinear for cloth_image, nearest for cloth_mask
    Color jitter on cloth_image ONLY (not cloth_mask):
      brightness=0.15, contrast=0.15, saturation=0.10, hue=0.05
    NOTE: cloth_image_raw is set BEFORE these augmentations → untouched

  AGNOSTIC augmentation (applied to agnostic_image only):
    Random cutout: 1-3 patches, each 5% of image area, zeroed out (p=0.3)
    Purpose: Prevents model from over-relying on visible torso features

  KEYPOINT augmentation (applied to keypoint_coords only):
    Gaussian noise σ=0.005 on each normalized coordinate (p=0.5)
    Clamp to [0,1] after adding noise

Menswear filter (when cfg.data.apply_menswear_filter=True):
  def _is_menswear_candidate(parse_lip20):
    upper_freq = (parse_lip20 == 5).float().mean()
    dress_freq  = (parse_lip20 == 6).float().mean()
    return upper_freq > 0.20 and dress_freq < 0.05
  
  Applied during __init__ before building self.samples list.
  Log at INFO: f"Menswear filter: {kept}/{total} samples retained ({pct:.1%})"

DensePose coverage (per-sample float, not boolean):
  part_ids = densepose_rgb[:,:,0]  (R channel after ToTensor)
  coverage = (part_ids > 0).float().mean().item()
  sample['densepose_coverage'] = coverage
  # Used by Branch-D for confidence weighting (not hard threshold)

## 6.2 DatasetValidator (data/validators.py)

10 checks — ALL fully implemented:

1. _check_directory_structure()          [CRITICAL]
   Verify all 11 subdirs exist in train/ and test/.

2. _check_pair_lists()                   [CRITICAL]
   Load both pair files, verify all referenced files exist.
   Expected: train ≈ 11647, test ≈ 2032. Warn if off by >5%.

3. _check_image_dimensions(n=200)        [CRITICAL]
   Sample 200 images from each of image/, cloth/, agnostic-v3.2/, image-densepose/.
   Assert all are (1024, 768). Report exact count and % of mismatches.

4. _check_parse_class_distribution(n=500) [CRITICAL]
   Compute LIP-20 class frequency histogram over 500 samples.
   Assert class 5 (upper-cloth) appears in >80% of samples.
   Assert no class values outside [0,19].

5. _check_label_mapping_correctness(n=100) [CRITICAL]
   For 100 samples: remap LIP-20 → UNIFIED-25, verify:
     - class 5 pixel count IDENTICAL before/after remapping (exact integer match)
     - All output values in [0,24]
     - No information loss: assert remapped.sum() > 0 when raw.sum() > 0

6. _check_densepose_coverage(n=500)      [WARNING if mean < 0.20]
   Report: mean, std, min, max, % below 0.15.
   Warn if mean < 0.20, ERROR if mean < 0.10.

7. _check_openpose_quality(n=200)        [WARNING]
   Parse JSONs, check person detected, ≥15 of 18 joints above confidence 0.3.
   Report detection rate.

8. _check_agnostic_mask_coverage(n=200) [WARNING]
   Assert agnostic mask covers 10-45% of image (upper-body range).
   Report distribution.

9. _check_warp_cloth_availability()      [INFO]
   Report % of samples with MOD-10 and MOD-11.
   These are optional auxiliary — not required for training.

10. _check_cloth_mask_quality(n=200)     [WARNING]
    Verify binary values (only 0 and 1), non-zero coverage > 5%.

Output: ValidationReport JSON saved to logs/validation_report_{split}_{ts}.json
  Status: "PASS" | "PASS_WITH_WARNINGS" | "FAIL"
  "FAIL" on any CRITICAL failure → raise DatasetValidationError before training.

═══════════════════════════════════════════════════════════════════════════════
SECTION 7 — TRAINING SYSTEM (CHALLENGE-REFINED)
═══════════════════════════════════════════════════════════════════════════════

## 7.1 Configuration (configs/default.yaml)

project:
  name: "vitonhd_tryon_v1"
  version: "1.0.0"
  seed: 42

data:
  data_root: "./viton_hd"
  batch_size: 4
  num_workers: 8
  pin_memory: true
  apply_menswear_filter: true
  densepose_min_coverage: 0.15

model:
  unified_parse_classes: 25
  active_garment_classes: [5]
  
  body_encoder:
    backbone: "swinv2_small_window8_256"
    pretrained: true
  
  garment_extractor:
    backbone: "convnext_tiny"
    pretrained: true
  
  warping:
    num_parts: 5
    tps_control_points: 25
    tps_reg_lambda: 1.0e-5
    correlation_max_displacement: 8   # reduce to 6 if OOM

  ip_adapter:
    clip_model: "openai/clip-vit-large-patch14"
    num_tokens: 16
    unet_dim: 768
    cfg_dropout: 0.1
    ip_scale_init: 0.1               # Challenge 4: start weak
    ip_scale_max: 3.0                # Challenge 4: clamp ceiling

  parse_embedder:
    vocab_size: 25
    embed_dim: 64
    output_channels: 3

  diffusion:
    base_model: "runwayml/stable-diffusion-inpainting"
    unet_in_channels: 17
    vae_scaling_factor: 0.18215
    num_inference_steps: 50
    guidance_scale: 2.5
    ema_decay: 0.9999
    ema_update_every: 10
    ema_scope: "all"                  # Challenge 9: all params, not UNet only
    snr_gamma: 5.0
    warp_warmup_epochs: 2             # Challenge 1/5: warp-only phase

training:
  max_epochs: 150
  optimizer: "AdamW"
  
  # Per-module LRs (Challenge 5: per-module gradient clipping)
  lr_warp: 1.0e-4
  lr_diffusion: 5.0e-5
  lr_body_encoder: 5.0e-5
  lr_garment_extractor: 5.0e-5
  lr_ip_adapter: 1.0e-4
  lr_parse_embedder: 1.0e-4
  lr_compositor: 1.0e-4
  lr_garment_adapter: 1.0e-4
  weight_decay: 1.0e-2
  
  # Per-module gradient clip norms (Challenge 5)
  grad_clip_warp: 1.0
  grad_clip_diffusion: 1.0
  grad_clip_body_encoder: 2.0
  grad_clip_global: 5.0              # Global safety clip after per-module clips
  
  scheduler: "cosine_with_warmup"
  warmup_steps: 500
  
  accumulate_grad_batches: 4         # effective batch = 16
  val_check_interval: 0.5
  num_val_inference_steps: 50
  log_images_every_n_val_steps: 5
  save_top_k: 5
  monitor_metric: "val/lpips"
  monitor_mode: "min"

hardware:
  precision: "bf16-mixed"
  accelerator: "gpu"
  devices: 1
  compile: false
  xformers: true

logging:
  log_dir: "./logs"
  checkpoint_dir: "./checkpoints"
  tensorboard: true
  num_images_to_log: 8

## 7.2 LightningModule (training/lightning_module.py) — Key Sections

class VirtualTryOnLightningModule(LightningModule):
  
  def __init__(self, cfg):
    self.model = VirtualTryOnSystem(cfg)
    self.cfg   = cfg
    
    # EMA: ALL trainable parameters (Challenge 9)
    self.ema = ExponentialMovingAverage(
        [p for p in self.model.parameters() if p.requires_grad],
        decay=cfg.model.diffusion.ema_decay
    )
    
    # Loss modules
    self.perceptual_loss = VGGPerceptualLoss()  # all frozen
    
    # Metrics
    self.lpips_fn = lpips.LPIPS(net='vgg')
    self.ssim_fn  = StructuralSimilarityIndexMeasure(data_range=2.0)
    
    # Warp warm-up state
    self._warp_warmup_done = False
  
  def on_train_epoch_start(self):
    # WARP WARM-UP: Manage freezing (Challenges 1 and 5)
    epoch = self.current_epoch
    warmup_epochs = self.cfg.model.diffusion.warp_warmup_epochs  # = 2
    
    if epoch < warmup_epochs and not self._warp_warmup_done:
      # Freeze everything EXCEPT warping modules and UNet new channels
      self._freeze_for_warp_warmup()
      self.print(f"Epoch {epoch}: WARP WARM-UP — UNet frozen except conv_in new ch")
    
    elif epoch >= warmup_epochs and not self._warp_warmup_done:
      # Unfreeze ALL parameters → full joint training
      self._unfreeze_all()
      self._warp_warmup_done = True
      self.print(f"Epoch {epoch}: WARM-UP COMPLETE — Full joint training begins")
    
    # Log current loss weights
    weights = get_loss_weights(epoch)
    for k, v in weights.items():
      self.log(f"loss_weights/{k}", float(v))
  
  def _freeze_for_warp_warmup(self):
    # Freeze: diffusion_unet (except conv_in channels 9-16), body_encoder,
    #         garment_extractor, ip_adapter, parse_embedder, compositor
    # Keep unfrozen: warping, garment_adapter, unet.conv_in (new channels only)
    for name, param in self.model.named_parameters():
      if 'warping' in name or 'garment_adapter' in name:
        param.requires_grad = True
      elif 'unet.conv_in' in name:
        # Only new channels 9-16 grad — handled by gradient masking hook
        param.requires_grad = True
        self._register_conv_in_hook(param)
      else:
        param.requires_grad = False
  
  def _register_conv_in_hook(self, conv_in_weight):
    # Hook: zero gradients for channels 0-8 (pretrained channels stay frozen)
    def mask_grad(grad):
      grad_clone = grad.clone()
      grad_clone[:, :9] = 0.0  # zero pretrained channel gradients
      return grad_clone
    conv_in_weight.register_hook(mask_grad)
  
  def _unfreeze_all(self):
    for param in self.model.parameters():
      param.requires_grad = True
    # Remove all hooks
    for module in self.model.modules():
      module._backward_hooks.clear()
  
  def training_step(self, batch, batch_idx):
    B = batch['person_image'].shape[0]
    t = torch.randint(0, 1000, (B,), device=self.device, dtype=torch.long)
    
    outputs = self.model(batch, t)
    weights = get_loss_weights(self.current_epoch)
    losses  = self._compute_all_losses(outputs, batch, weights)
    
    # PER-MODULE GRADIENT CLIPPING (Challenge 5)
    # Applied manually AFTER backward (in optimizer_step or via hook)
    # See training/callbacks.py PerModuleGradientClipCallback
    
    for name, val in losses.items():
      self.log(f"train/{name}", val, on_step=True, on_epoch=True,
               prog_bar=(name == 'total'), sync_dist=True)
    
    # Monitor ip_scale every 100 steps
    if batch_idx % 100 == 0:
      self.log("model/ip_scale", self.model.ip_adapter.ip_scale.item())
      self._monitor_ip_scale_stability()
    
    # Monitor warp: if deformation_field std < 0.01 by epoch 10 → warn
    if self.current_epoch == 10 and batch_idx == 0:
      def_std = outputs['deformation_field'].std().item()
      if def_std < 0.01:
        self.print(f"WARNING: deformation_field.std()={def_std:.4f} < 0.01. "
                   f"Warp may not be learning. Consider reducing lr_diffusion.")
    
    return losses['total']
  
  def _monitor_ip_scale_stability(self):
    scale = self.model.ip_adapter.ip_scale.item()
    if scale >= 2.9:
      # If saturated for too long, reduce ip_adapter LR
      self.print(f"WARNING: ip_scale near ceiling ({scale:.3f}). "
                 f"Consider reducing lr_ip_adapter.")
  
  def on_train_batch_end(self, outputs, batch, batch_idx):
    if batch_idx % self.cfg.model.diffusion.ema_update_every == 0:
      self.ema.update()
  
  def validation_step(self, batch, batch_idx):
    with self.ema.average_parameters():
      I_final = self.model.generate(batch, num_steps=self.cfg.training.num_val_inference_steps)
    
    I_n      = (I_final + 1) / 2  # → [0,1]
    target_n = (batch['person_image'] + 1) / 2
    
    self.log('val/lpips', self.lpips_fn(I_final, batch['person_image']).mean())
    self.log('val/ssim',  self.ssim_fn(I_n, target_n))
    
    if batch_idx < self.cfg.logging.num_images_to_log:
      self._log_image_grid(batch, I_final, batch_idx)
  
  def configure_optimizers(self):
    # Separate param groups with different LRs (Challenge 5)
    param_groups = [
      {'params': self.model.warping.parameters(),           'lr': self.cfg.training.lr_warp,             'name': 'warp'},
      {'params': self.model.unet.parameters(),              'lr': self.cfg.training.lr_diffusion,        'name': 'diffusion'},
      {'params': self.model.body_encoder.parameters(),      'lr': self.cfg.training.lr_body_encoder,     'name': 'body_enc'},
      {'params': self.model.garment_extractor.parameters(), 'lr': self.cfg.training.lr_garment_extractor,'name': 'garment_ext'},
      {'params': self.model.ip_adapter.image_proj.parameters() +
                 list(self.model.ip_adapter.ip_to_k.parameters()) +
                 list(self.model.ip_adapter.ip_to_v.parameters()),
                                                            'lr': self.cfg.training.lr_ip_adapter,       'name': 'ip_adapter'},
      {'params': self.model.parse_embedder.parameters(),    'lr': self.cfg.training.lr_parse_embedder,   'name': 'parse_emb'},
      {'params': self.model.compositor.parameters(),        'lr': self.cfg.training.lr_compositor,       'name': 'compositor'},
      {'params': self.model.garment_adapter.parameters(),   'lr': self.cfg.training.lr_garment_adapter,  'name': 'garment_adp'},
    ]
    optimizer  = torch.optim.AdamW(param_groups, weight_decay=self.cfg.training.weight_decay)
    scheduler  = get_cosine_schedule_with_warmup(optimizer,
                     num_warmup_steps=self.cfg.training.warmup_steps,
                     num_training_steps=self._estimate_total_steps())
    return {'optimizer': optimizer, 'lr_scheduler': {'scheduler': scheduler, 'interval': 'step'}}

═══════════════════════════════════════════════════════════════════════════════
SECTION 8 — CHALLENGE MITIGATIONS IMPLEMENTATION CHECKLIST
═══════════════════════════════════════════════════════════════════════════════

The following items are derived from the 10 identified challenges.
Each MUST be implemented exactly as specified:

CHALLENGE 1 — TPS NUMERICAL INSTABILITY:
  [x] lambda_reg = 1e-5 added to K diagonal BEFORE torch.linalg.solve
  [x] solve() ALWAYS called on .float() tensor, cast back after
  [x] Output grid clamped to [-1.1, 1.1]
  [x] Control points initialized to identity (regular 5×5 grid)
  [x] L_identity penalty: high early (5.0), linear decay to 0 by epoch 20
  [x] 2-epoch warp warm-up: diffusion new channels only, warp + UNet conv_in learn

CHALLENGE 2 — CORRELATION VOLUME MEMORY:
  [x] Correlation computed in BF16 (not FP32) — safe for normalized dot products
  [x] max_displacement config knob (default 8, reduce to 6 if OOM)
  [x] Memory budget documented: ~284 MB BF16 vs ~567 MB FP32 at B=4

CHALLENGE 3 — DENSEPOSE FAILURES:
  [x] Confidence-weighted fusion (not binary on/off)
  [x] coverage = (part_ids > 0).float().mean() stored per-sample as float
  [x] F_dense_8 = F_dense_raw × confidence_weight.view(B,1,1,1)
  [x] Coverage visualized in Notebook Cell 8 (histogram + threshold line)

CHALLENGE 4 — IP-ADAPTER SCALE INSTABILITY:
  [x] ip_scale initialized to 0.1 (not 1.0)
  [x] ip_scale clamped to [0.0, 3.0] BEFORE every attention computation
  [x] ip_scale value logged every 100 training steps
  [x] Warning logged if ip_scale ≥ 2.9 for extended period
  [x] CFG dropout 10%: 10% of training samples use null_emb
  [x] cloth_image_raw (unaugmented) sent to CLIP; cloth_image (augmented) to extractor

CHALLENGE 5 — JOINT TRAINING STABILITY:
  [x] 2-epoch warp warm-up: selective freezing with gradient hook on conv_in
  [x] Full unfreeze at epoch 2 — NO further freezing ever
  [x] Per-module gradient clipping (not just global clip)
  [x] Per-module LR schedule (8 distinct param groups)
  [x] deformation_field.std() monitored at epoch 10 — warn if < 0.01
  [x] ip_scale saturation monitoring

CHALLENGE 6 — OVERFITTING ON SMALL DATASET:
  [x] Agnostic cutout augmentation (3-5 patches, p=0.3)
  [x] Keypoint Gaussian noise (σ=0.005, p=0.5)
  [x] Cloth affine augmentation (applied jointly to cloth + cloth_mask)
  [x] Cloth color jitter (applied to cloth_image, NOT cloth_mask, NOT cloth_image_raw)
  [x] Horizontal flip applied jointly to all spatial modalities (same random state)
  [x] weight_decay=0.01 on all param groups

CHALLENGE 7 — INFERENCE SPEED:
  [x] 50-step DPM-Solver++ for quality validation
  [x] Notebook Cell 20: measure latency at 50/20/10 steps
  [x] Config: num_inference_steps adjustable without code change
  [x] Architecture comment: distillation path documented in inference/infer.py

CHALLENGE 8 — PARSE QUALITY:
  [x] Part segmenter trained jointly with warp (not fixed to parse classes)
  [x] Soft pseudo-supervision (temperature T=2.0) acknowledges approximate mapping
  [x] DatasetValidator check #4: parse class distribution validates quality
  [x] Validator discards samples with class 5 area < 5% of image

CHALLENGE 9 — EMA SCOPE:
  [x] EMA wraps ALL trainable parameters (body_encoder, garment_extractor, warping,
      garment_adapter, ip_adapter proj, parse_embedder, unet, compositor)
  [x] EMA NOT applied to frozen params (frozen_vae, frozen_clip)
  [x] Assertion in inference: EMA != live weights after 100+ steps
  [x] EMA weights exclusively used at validation and inference

CHALLENGE 10 — COMPOSITOR SUPERVISION:
  [x] Learned compositor CNN (not hard agnostic mask passthrough)
  [x] Direct supervision via softened-agnostic-mask BCE (L_comp)
  [x] Boundary-weighted BCE (upweight pixels near mask edge)
  [x] Hard prior: alpha = 0 OUTSIDE agnostic_mask (multiply after sigmoid)
  [x] alpha_logit returned for loss; alpha returned for visualization

═══════════════════════════════════════════════════════════════════════════════
SECTION 9 — COMPLETE FILE STRUCTURE (37 FILES)
═══════════════════════════════════════════════════════════════════════════════

Generate ALL 37 files in the order specified in Section 14.

virtual_tryon/
│
├── configs/
│   ├── default.yaml                  # [FILE-01] Full OmegaConf config
│   └── constants.py                  # [FILE-02] UNIFIED-25, all constants
│
├── data/
│   ├── __init__.py                   # [FILE-03]
│   ├── dataset_vitonhd.py            # [FILE-04] VITONHDDataset (all 11 mods + augment)
│   ├── datamodule.py                 # [FILE-05] LightningDataModule
│   └── validators.py                 # [FILE-06] VITONHDValidator (10 checks)
│
├── models/
│   ├── __init__.py                   # [FILE-07]
│   ├── tps.py                        # [FILE-08] DifferentiableTPS (identity init, fp32)
│   ├── body_encoder.py               # [FILE-09] BodyConditionEncoder (confidence-weighted dp)
│   ├── garment_extractor.py          # [FILE-10] GarmentFeatureExtractor
│   ├── warping.py                    # [FILE-11] PartAwareWarpingModule (BF16 corr)
│   ├── garment_adapter.py            # [FILE-12] GarmentLatentAdapter
│   ├── parse_embedder.py             # [FILE-13] ParseMapEmbedder (vocab=25, gated)
│   ├── ip_adapter.py                 # [FILE-14] IPAdapterProjection (scale=0.1 init)
│   ├── diffusion_unet.py             # [FILE-15] DiffusionSynthesisUNet (17-ch, ip-attn)
│   ├── compositor.py                 # [FILE-16] RegionCompositor (softened BCE)
│   └── tryon_system.py               # [FILE-17] VirtualTryOnSystem (top-level)
│
├── losses/
│   ├── __init__.py                   # [FILE-18]
│   ├── diffusion_loss.py             # [FILE-19] SNR-weighted denoising loss
│   ├── perceptual.py                 # [FILE-20] VGG-19 perceptual loss
│   ├── ssim_loss.py                  # [FILE-21] Differentiable SSIM
│   └── warp_losses.py                # [FILE-22] smooth + mask + pretrain + identity + partseg + comp
│
├── training/
│   ├── __init__.py                   # [FILE-23]
│   ├── lightning_module.py           # [FILE-24] VirtualTryOnLightningModule (warp warmup)
│   ├── trainer_setup.py              # [FILE-25] Trainer + callbacks builder
│   ├── callbacks.py                  # [FILE-26] WarpViz + LossWeightLogger + PerModuleGradClip
│   └── ema.py                        # [FILE-27] ExponentialMovingAverage (all params)
│
├── inference/
│   ├── __init__.py                   # [FILE-28]
│   └── infer.py                      # [FILE-29] VirtualTryOnInference (EMA assertion)
│
├── utils/
│   ├── __init__.py                   # [FILE-30]
│   ├── label_mapper.py               # [FILE-31] remap_labels + LIP20_TO_UNIFIED25
│   └── visualization.py              # [FILE-32] grids, deform overlays, coverage histograms
│
├── tests/
│   ├── test_dataset.py               # [FILE-33] Dataset + menswear filter + mapping tests
│   ├── test_model_shapes.py          # [FILE-34] End-to-end shape verification
│   └── test_training_step.py         # [FILE-35] Loss components + NaN check + warmup logic
│
├── train.py                          # [FILE-36] Main entry (validator → trainer.fit)
│
└── VirtualTryOn_Notebook.ipynb       # [FILE-37] 20-cell executable notebook
```

═══════════════════════════════════════════════════════════════════════════════
SECTION 10 — JUPYTER NOTEBOOK SPECIFICATION (20 CELLS)
═══════════════════════════════════════════════════════════════════════════════

All 20 cells must execute sequentially with no errors.

Cell 1:  Environment Check
  torch, torchvision, lightning, diffusers, transformers, timm versions
  GPU name, CUDA version, VRAM total

Cell 2:  Dataset Validation
  VITONHDValidator.validate(data_root, split='train')
  Display colored pass/fail table of all 10 checks

Cell 3:  Sample Visualization (All 11 Modalities)
  Load 1 sample from VITONHDDataset
  3×4 subplot grid (11 images + 1 empty), titled per modality
  Print all tensor shapes, dtypes, value ranges

Cell 4:  Label Mapping Verification
  Load 1 parse map, apply LIP20_TO_UNIFIED25 via remap_labels
  Side-by-side color-coded visualization: LIP-20 | UNIFIED-25
  Print class-5 pixel count before and after (must be identical)
  Print all unique UNIFIED-25 values present

Cell 5:  Model Instantiation & Parameter Count
  Load cfg, instantiate VirtualTryOnSystem(cfg)
  Print per-module parameter counts (trainable / frozen)
  Print total system parameters

Cell 6:  Synthetic Forward Pass (Shape Verification)
  Create B=2 synthetic batch with correct shapes/dtypes
  Run VirtualTryOnSystem.forward(batch, t) in no-grad mode
  Assert ALL output shapes per specification
  Print timing for one forward pass

Cell 7:  Warp Warm-Up Demonstration
  Show which parameters are frozen/unfrozen at epoch 0 vs epoch 2
  Run forward with epoch=0 config (warp only training)
  Compare output statistics to epoch=2 (full joint)

Cell 8:  DensePose Coverage Analysis
  Sample 500 training images
  Compute coverage for each
  Histogram plot with 0.15 threshold line marked
  Print: mean, std, % below threshold

Cell 9:  TPS Visualization (Identity → Warped)
  Load real sample
  Run PartAwareWarpingModule only
  4-panel: cloth_image | cloth_warped | deformation_field | part_masks colored
  Print: deformation_field.std() (should be > 0.01 after warm-up)

Cell 10: IP-Adapter Scale Monitoring Demo
  Initialize ip_scale = 0.1
  Simulate 100 synthetic batches (dummy training loop)
  Plot ip_scale evolution
  Show clamp enforcement at 3.0 (if scale tries to exceed it)

Cell 11: Loss Function Verification
  Create random predictions with correct shapes
  Compute each of the 9 loss components
  Verify all are finite scalars
  Print loss weight schedule table for all 150 epochs (formatted as dataframe)

Cell 12: Per-Module Gradient Norms
  Run one training_step with real batch
  After backward, print gradient norm per param group
  Verify no NaN/Inf gradients
  Show per-module gradient clipping in action

Cell 13: Training Launch
  DataModule, LightningModule, Trainer instantiation
  trainer.fit(module, datamodule)
  (Full 150-epoch training)

Cell 14: Training Curves
  Load TensorBoard logs via pandas or direct file parsing
  Plot: total loss + all 9 components vs epoch (2 rows, 5 cols)
  Plot: loss weight schedule overlay on loss curves
  Plot: val/lpips, val/ssim, val/fid vs epoch
  Plot: learning rates per group
  Plot: ip_scale vs training steps

Cell 15: Load Best Checkpoint (EMA)
  Load best checkpoint from checkpoints/ dir
  Verify EMA weights loaded
  Assert EMA ≠ live weights (sanity check)
  Set model.eval()

Cell 16: Inference Visualization (8 Test Pairs)
  Run VirtualTryOnInference on 8 test pairs
  3-column grid: Person | Garment | Try-On Result
  Save as high-quality PNG (300 DPI)

Cell 17: Quantitative Metrics
  Compute LPIPS, SSIM on full 2032-pair test set
  Compute FID using clean-fid
  Print results table vs IDM-VTON benchmarks
  Assert FID ≤ 6.5 (soft — warn if not met)

Cell 18: Compositor Analysis
  Visualize alpha mask output for 4 samples
  Show: agnostic_mask | softened_mask | learned_alpha | boundary_weights
  Verify alpha is 0 outside agnostic_mask region

Cell 19: Ablation Study (Warp vs No-Warp)
  Run 50 test pairs with identity warp (ctrl_pts_tgt = ctrl_pts_src)
  Run same 50 with trained warp
  Side-by-side LPIPS box plots
  Quantify warp improvement

Cell 20: Deployment Benchmarks
  Measure: latency per image at 50/20/10 steps (A100)
  Measure: peak GPU memory at inference (B=1)
  Print: minimum hardware requirements
  Estimate: commercial API throughput (images/minute)
  Note: 4-8 step distillation path for <2s inference (future work)

═══════════════════════════════════════════════════════════════════════════════
SECTION 11 — REQUIREMENTS (PINNED VERSIONS)
═══════════════════════════════════════════════════════════════════════════════

# requirements.txt
torch==2.3.0
torchvision==0.18.0
torchaudio==2.3.0
diffusers==0.27.2
transformers==4.40.2
accelerate==0.30.0
lightning==2.2.5
torchmetrics==1.4.0
timm==1.0.3
lpips==0.1.4
clean-fid==0.1.35
piq==0.8.0
omegaconf==2.3.0
hydra-core==1.3.2
Pillow==10.3.0
numpy==1.26.4
scipy==1.13.0
opencv-python==4.9.0.80
matplotlib==3.8.4
tensorboard==2.17.0
torch_ema==0.3
tqdm==4.66.4
rich==13.7.1
einops==0.8.0

═══════════════════════════════════════════════════════════════════════════════
SECTION 12 — MEMORY BUDGET (A100 80GB)
═══════════════════════════════════════════════════════════════════════════════

Module                             | VRAM (Training B=4, BF16)
-----------------------------------|---------------------------
Frozen VAE (FP16, no_grad)         |  1.2 GB
Frozen CLIP (FP16, no_grad)        |  0.9 GB
SwinV2-Small body encoder          |  2.1 GB
ConvNeXt-Tiny garment extractor    |  1.4 GB
TPS + warping modules              |  0.3 GB
Correlation volume (BF16)          |  0.3 GB  ← halved from FP32
GarmentLatentAdapter               |  0.1 GB
ParseMapEmbedder                   |  0.1 GB
IP-Adapter projection              |  0.2 GB
SD 1.5 UNet (17-ch)                |  6.5 GB
RegionCompositor                   |  0.3 GB
Activations (BF16, B=4)            |  7.5 GB
Gradients                          |  8.5 GB
AdamW optimizer states (2 moments) |  6.0 GB
EMA shadow params                  |  3.0 GB  ← all params, not UNet only
TOTAL (estimated peak)             | ~38.4 GB ← well within 80 GB

═══════════════════════════════════════════════════════════════════════════════
SECTION 13 — PerModuleGradientClipCallback (callbacks.py)
═══════════════════════════════════════════════════════════════════════════════

class PerModuleGradientClipCallback(Callback):
  """
  Implements per-module gradient clipping before the global clip.
  
  Rationale (Challenge 5): Without per-module clipping, a large diffusion
  loss gradient can dwarf warp gradients, preventing the warping module
  from learning. Per-module clipping ensures each module updates
  proportionally to its own learning signal.
  """
  
  def on_before_optimizer_step(self, trainer, pl_module, optimizer):
    cfg = pl_module.cfg.training
    
    # Per-module clips
    module_clips = {
        'warp':         (pl_module.model.warping,            cfg.grad_clip_warp),
        'diffusion':    (pl_module.model.unet,               cfg.grad_clip_diffusion),
        'body_encoder': (pl_module.model.body_encoder,        cfg.grad_clip_body_encoder),
    }
    
    for name, (module, max_norm) in module_clips.items():
      params = [p for p in module.parameters() if p.grad is not None]
      if params:
        norm = nn.utils.clip_grad_norm_(params, max_norm)
        pl_module.log(f"grad_norm/{name}", norm)
    
    # Final global safety clip
    all_params = [p for p in pl_module.model.parameters() if p.grad is not None]
    global_norm = nn.utils.clip_grad_norm_(all_params, cfg.grad_clip_global)
    pl_module.log("grad_norm/global", global_norm)

═══════════════════════════════════════════════════════════════════════════════
SECTION 14 — GENERATION ORDER
═══════════════════════════════════════════════════════════════════════════════

Generate files in this exact order. Complete each file fully before starting the next.

BATCH 1 — Foundation:
  [FILE-01] configs/default.yaml
  [FILE-02] configs/constants.py
  [FILE-30] utils/__init__.py
  [FILE-31] utils/label_mapper.py
  [FILE-32] utils/visualization.py

BATCH 2 — Data:
  [FILE-03] data/__init__.py
  [FILE-04] data/dataset_vitonhd.py
  [FILE-05] data/datamodule.py
  [FILE-06] data/validators.py

BATCH 3 — Models (bottom-up dependency order):
  [FILE-08] models/tps.py
  [FILE-13] models/parse_embedder.py
  [FILE-12] models/garment_adapter.py
  [FILE-09] models/body_encoder.py
  [FILE-10] models/garment_extractor.py
  [FILE-11] models/warping.py
  [FILE-14] models/ip_adapter.py
  [FILE-15] models/diffusion_unet.py
  [FILE-16] models/compositor.py
  [FILE-17] models/tryon_system.py
  [FILE-07] models/__init__.py

BATCH 4 — Losses:
  [FILE-19] losses/diffusion_loss.py
  [FILE-20] losses/perceptual.py
  [FILE-21] losses/ssim_loss.py
  [FILE-22] losses/warp_losses.py
  [FILE-18] losses/__init__.py

BATCH 5 — Training:
  [FILE-27] training/ema.py
  [FILE-26] training/callbacks.py
  [FILE-24] training/lightning_module.py
  [FILE-25] training/trainer_setup.py
  [FILE-23] training/__init__.py

BATCH 6 — Inference + Tests + Entry:
  [FILE-29] inference/infer.py
  [FILE-28] inference/__init__.py
  [FILE-33] tests/test_dataset.py
  [FILE-34] tests/test_model_shapes.py
  [FILE-35] tests/test_training_step.py
  [FILE-36] train.py

BATCH 7 — Notebook (last — depends on all above):
  [FILE-37] VirtualTryOn_Notebook.ipynb

═══════════════════════════════════════════════════════════════════════════════
SECTION 15 — THE SINGLE MOST IMPORTANT RULE
═══════════════════════════════════════════════════════════════════════════════

Every line of code you write must run on the first attempt.

This means:
  - All imports at top of every file (no forward references)
  - All helper classes defined before they are used
  - All config keys referenced in code exist in configs/default.yaml
  - All file paths match the directory structure in Section 9 exactly
  - All tensor shape assertions in every forward() method
  - requirements.txt versions installable together without conflicts
  - Notebook cells executable sequentially without manual intervention

When uncertain: implement the simpler, more conservative version.
A working simple system beats a broken complex one every time.

CONTINUATION PROTOCOL:
  If context limit reached mid-file:
    Output: "=== CONTINUE: {filename} line {line_number} ==="
  If reached between files:
    Output: "=== NEXT: {filename} ==="
  List completed files clearly.
  Resume exactly where stopped. Zero summarization. Zero omission.

═══════════════════════════════════════════════════════════════════════════════

BEGIN GENERATION NOW. Start with [FILE-01] configs/default.yaml.
```
