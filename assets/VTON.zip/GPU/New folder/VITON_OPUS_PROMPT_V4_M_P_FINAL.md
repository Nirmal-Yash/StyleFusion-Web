# VITON-HD Virtual Try-On — Claude Opus 4.6 Prompt (v4.0-M-P FINAL)
## Menswear + Pair Try-On | VITON-HD Upper + DressCode-Lower | No Format Change
### Supersedes v4.0 — Simplified, Menswear-Optimized, Pair-Try-On Capable

---

## HOW TO USE

Copy everything between `---PROMPT START---` and `---PROMPT END---` and paste directly into Claude Opus 4.6.
If Opus hits a context limit it will output `=== CONTINUATION BREAK ===` with the exact file and line — continue in the next message from that point.

---

---PROMPT START---

You are a world-class deep learning engineer and computer vision researcher with expert-level mastery of latent diffusion models, geometric warping, adapter-based conditioning, multi-dataset training, and virtual try-on systems. You have deeply studied VITON-HD, HR-VITON, GP-VTON, StableVITON, IDM-VTON, DCI-VTON, CatVTON, GarDiff, FIA-VTON, Re-CatVTON, PSAD, and DressCode. You understand not only what each architecture proposes, but **why each design decision was made, what it trades off, and how failures manifest in practice**.

Your task is to architect and implement — entirely in original code, with no code copied from any repository — a **production-ready, commercially deployable, menswear virtual try-on system** capable of:

1. **Upper-body try-on** (Mode A) — shirts, kurtas, jackets from the VITON-HD dataset
2. **Lower-body try-on** (Mode B) — trousers, pants, shorts from DressCode lower_body
3. **Pair try-on** (Mode C) — sequential upper + lower composition (full outfit)

This is a **menswear-optimized system**. Female-specific garment categories (saree, dupatta, lehenga) are excluded. The system is designed for practical commercial deployment in menswear e-commerce.

---

## ABSOLUTE CONSTRAINTS

1. **NO copied code** from any public repository. All code is fully original.
2. **NO exact module names** from official implementations (no `GMM`, `ALIASGenerator`, `TryonNet`, etc.).
3. Dataset is **already preprocessed and on disk**. Do NOT write OpenPose or human parsing inference code. A `PREPROCESSING_SPEC.md` reference document is a required deliverable.
4. Every function must be **complete and runnable** — no `pass` stubs, no `TODO` in production paths.
5. Framework: **PyTorch 2.x + PyTorch Lightning 2.x**.
6. Hardware: **NVIDIA A100 (80GB VRAM)**. Include VRAM estimates in comments.
7. Deliver a **Jupyter Notebook (.ipynb)** as primary execution interface.
8. All dataset loading must include **JSON schema validation, class histogram verification, and tensor dimension asserts** before training begins.

---

## PART 1: THE PAIR TRY-ON PROBLEM — WHY TWO DATASETS ARE REQUIRED

### 1.1 The Fundamental Limitation of VITON-HD Alone

VITON-HD contains **only upper-body garments** — shirts, tops, and jackets worn by frontal-view persons. It provides no lower-body garments (no trousers, no shorts), no full-body garment pairs, and all person images show only the torso region with lower body cropped or partially visible. It is structurally incapable of training a lower-body or pair try-on model.

This is not a configuration issue — it is a data issue. You cannot train a lower-body warp module with zero lower-body training samples.

### 1.2 The Solution: DressCode Lower-Body (No Format Change)

**DressCode** (Morelli et al., 2022) provides lower-body garment pairs (trousers, pants, shorts) in **the same folder structure and image resolution as VITON-HD** (1024×768, same preprocessing pipeline). Adding DressCode lower_body requires zero changes to the dataset format or preprocessing pipeline — the data loader reads from two roots with identical internal structure.

Research validation of this approach:
- FITMI validates on both DressCode and VITON-HD benchmarks, using "an automatic dataset integration mechanism that selects the appropriate dataset based on the category argument (upper, lower, or dresses)."
- PSAD achieves SOTA with sequential multi-garment composition: "first with an upper-body garment, and then with a lower-body item."

### 1.3 Pair Try-On: Sequential Two-Pass Composition

Mode C (pair try-on) is implemented as **two sequential diffusion passes**:

```
STEP 1: Upper-body pass (Mode A internally)
  person_image + shirt_cloth → I_upper (intermediate person wearing shirt)

STEP 2: Lower-body pass (Mode B internally)
  I_upper + pants_cloth → I_final (person wearing shirt + pants)
```

The intermediate `I_upper` is not an image saved to disk — it is decoded from latent space after Step 1, then re-encoded and fed as the "person image" input to Step 2. This sequential composition is proven by PSAD and avoids the complexity of a simultaneous multi-garment UNet (which would require matched multi-garment training data).

**Key implementation requirement:** The `TryOnModeRouter` orchestrates this two-pass logic. The `DiffusionSynthesisUNet` architecture is identical for Mode A and B (17 channels). Mode C simply calls Mode A → Mode B in sequence with the intermediate output as the new person input for Step 2.

---

## PART 2: DATASET SPECIFICATION

### 2.1 VITON-HD (Upper-Body Shirts — Primary Dataset)

```
viton_hd/
├── train/
│   ├── image/               # [M1]  Person RGB, 1024×768, PNG/JPG
│   ├── image-parse-v3/      # [M2]  LIP-20 segmentation map, PNG (palette)
│   ├── openpose-img/        # [M3]  OpenPose rendered heatmap, PNG
│   ├── openpose-json/       # [M4]  OpenPose JSON: pose_keypoints_2d (54 values)
│   ├── cloth/               # [M5]  Garment RGB, 1024×768, PNG/JPG
│   ├── cloth-mask/          # [M6]  Binary garment mask, PNG
│   ├── agnostic-v3.2/       # [M7]  Cloth-agnostic person (upper body masked), PNG
│   ├── agnostic-mask/       # [M8]  Binary agnostic region mask, PNG
│   ├── image-densepose/     # [M9]  DensePose IUV map (R=part_id, G=U, B=V), PNG
│   ├── warp-cloth/          # [M10] Pre-warped cloth (VITON-HD GMM output), PNG
│   └── warp-cloth-mask/     # [M11] Pre-warped cloth mask, PNG
└── test/
    └── (identical structure)
```

**Statistics:** ~11,647 training pairs, ~2,032 test pairs. Category: upper-body only.

**M9 — DensePose IUV:** 3-channel PNG, uint8. R=body part index (0–24), G=U coordinate (0–255), B=V coordinate (0–255). Load as float32 [3, H, W], normalized to [0, 1].

**M10–M11 — Pre-Warped Cloth:** Used only as a warm-start warp supervision signal during training epochs 1–10. Weight `λ_warp_pretrain` decays linearly from 2.0 at epoch 1 to 0.0 at epoch 10. Not used in DressCode batches (absent → zero loss contribution).

### 2.2 DressCode Lower-Body (Trousers/Pants — Secondary Dataset)

```
dresscode/
└── lower_body/
    ├── images/              # [M1]  Person RGB, 1024×768 (same format as VITON-HD image/)
    ├── cloth/               # [M5]  Garment RGB, 1024×768 (identical format)
    ├── cloth_mask/          # [M6]  Binary garment mask (identical format)
    ├── dense/               # [M9]  DensePose IUV maps (same IUV format)
    ├── keypoints/           # [M4]  OpenPose JSON (identical format to VITON-HD)
    ├── label_maps/          # [M2]  ATR-18 segmentation maps (different scheme → mapped at load)
    ├── skeletons/           # [M3]  OpenPose rendered skeleton (identical format)
    └── pairs.txt            # Pair definitions: "person_id\tcloth_id" per line
```

**Statistics:** ~4,500 training pairs, ~1,025 test pairs. Category: lower-body only.

**ATR-18 vs LIP-20:** DressCode uses the ATR-18 parsing scheme. The dataset loader maps ATR-18 → UNIFIED-20 at load time. The model always receives UNIFIED-20 labels.

**Agnostic Modalities (Missing — Derived at Load Time):**
DressCode does NOT provide `agnostic-v3.2` or `agnostic-mask`. Derive them:
```python
# Agnostic mask for lower body = union of lower garment classes from ATR-18 map
# ATR-18 lower-body garment classes: 5=skirt, 6=pants → UNIFIED-20 lower classes
lower_garment_mask = (parsed_map_unified20 == GARMENT_CLASSES_LOWER[0]) | \
                     (parsed_map_unified20 == GARMENT_CLASSES_LOWER[1]) | ...
# Also include lower limbs (to match VITON-HD agnostic convention)
arm_and_leg_mask = (parsed_map_unified20 == LEFT_LEG) | (parsed_map_unified20 == RIGHT_LEG)
agnostic_mask = lower_garment_mask | arm_and_leg_mask  # [1, H, W] binary

# Agnostic image = person image with agnostic region zeroed
fill = person_image.mean()  # per-image mean pixel value (not global)
agnostic_image = person_image * (1.0 - agnostic_mask) + fill * agnostic_mask
```

**`warp-cloth` / `warp-cloth-mask` absent:** Not provided by DressCode. Set `λ_warp_pretrain = 0` for all DressCode batches (handled automatically via the `use_pretrained_warp` flag per dataset config).

### 2.3 Pair File Format

For Mode C inference, a pair file specifies a person image with both an upper and lower garment:

```
# pair_tryon.txt format (tab-separated):
# person_image_path   upper_cloth_path   lower_cloth_path
000001.jpg            shirt_001.jpg      pants_042.jpg
000002.jpg            shirt_003.jpg      pants_017.jpg
```

The inference script accepts `--pair_file pair_tryon.txt` for batch Mode C inference.

---

## PART 3: SEMANTIC LABEL UNIFICATION (UNIFIED-20)

### 3.1 Rationale for UNIFIED-20 (Not UNIFIED-25)

The full v4.0 prompt defined UNIFIED-25 including 5 female-specific classes (dupatta, saree-drape, lehenga-skirt, kurta, jewelry-neck). This system is menswear-only. Removing these 5 classes yields UNIFIED-20 — simpler embeddings, less sparse label space, faster convergence.

### 3.2 LIP-20 Class Definitions (VITON-HD Input)
```
0:Background  1:Hat       2:Hair      3:Glove     4:Sunglasses
5:Upper-cloth 6:Dress     7:Coat      8:Socks     9:Pants
10:Left-leg   11:Right-leg 12:Left-shoe 13:Right-shoe 14:Left-arm
15:Right-arm  16:Scarf    17:Skirt    18:Jumpsuits 19:Face
```

### 3.3 ATR-18 Class Definitions (DressCode Input)
```
0:Background  1:Hat       2:Hair      3:Sunglasses 4:Upper-cloth
5:Skirt       6:Pants     7:Dress     8:Belt       9:Left-arm
10:Right-arm  11:Left-leg 12:Right-leg 13:Left-shoe 14:Right-shoe
15:Left-bag   16:Right-bag 17:Face
```

### 3.4 UNIFIED-20 Internal Label Space (Model Always Receives This)
```
0:Background   1:Hat         2:Hair         3:Face
4:Sunglasses   5:Upper-cloth 6:Coat/Jacket  7:Dress
8:Pants        9:Skirt       10:Left-arm    11:Right-arm
12:Left-leg    13:Right-leg   14:Left-shoe   15:Right-shoe
16:Socks       17:Belt        18:Neck/Scarf  19:Glove/Bag
```

### 3.5 Complete Mapping Tables (implement in `utils/label_mapper.py`)

```python
# LIP20_TO_UNIFIED20: index = LIP-20 class, value = UNIFIED-20 class
LIP20_TO_UNIFIED20 = torch.tensor([
    0,   # 0  Background  → 0  Background
    1,   # 1  Hat         → 1  Hat
    2,   # 2  Hair        → 2  Hair
    19,  # 3  Glove       → 19 Glove/Bag
    4,   # 4  Sunglasses  → 4  Sunglasses
    5,   # 5  Upper-cloth → 5  Upper-cloth
    7,   # 6  Dress       → 7  Dress
    6,   # 7  Coat        → 6  Coat/Jacket
    16,  # 8  Socks       → 16 Socks
    8,   # 9  Pants       → 8  Pants
    12,  # 10 Left-leg    → 12 Left-leg
    13,  # 11 Right-leg   → 13 Right-leg
    14,  # 12 Left-shoe   → 14 Left-shoe
    15,  # 13 Right-shoe  → 15 Right-shoe
    10,  # 14 Left-arm    → 10 Left-arm
    11,  # 15 Right-arm   → 11 Right-arm
    18,  # 16 Scarf       → 18 Neck/Scarf
    9,   # 17 Skirt       → 9  Skirt
    7,   # 18 Jumpsuits   → 7  Dress (closest equivalent)
    3,   # 19 Face        → 3  Face
], dtype=torch.long)  # shape [20]

# ATR18_TO_UNIFIED20: index = ATR-18 class, value = UNIFIED-20 class
ATR18_TO_UNIFIED20 = torch.tensor([
    0,   # 0  Background  → 0  Background
    1,   # 1  Hat         → 1  Hat
    2,   # 2  Hair        → 2  Hair
    4,   # 3  Sunglasses  → 4  Sunglasses
    5,   # 4  Upper-cloth → 5  Upper-cloth
    9,   # 5  Skirt       → 9  Skirt
    8,   # 6  Pants       → 8  Pants
    7,   # 7  Dress       → 7  Dress
    17,  # 8  Belt        → 17 Belt
    10,  # 9  Left-arm    → 10 Left-arm
    11,  # 10 Right-arm   → 11 Right-arm
    12,  # 11 Left-leg    → 12 Left-leg
    13,  # 12 Right-leg   → 13 Right-leg
    14,  # 13 Left-shoe   → 14 Left-shoe
    15,  # 14 Right-shoe  → 15 Right-shoe
    19,  # 15 Left-bag    → 19 Glove/Bag
    19,  # 16 Right-bag   → 19 Glove/Bag
    3,   # 17 Face        → 3  Face
], dtype=torch.long)  # shape [18]
```

Implement the vectorized remap function:
```python
def remap_labels(parse_map: torch.Tensor, mapping: torch.Tensor) -> torch.Tensor:
    """
    Remap parse map from source label scheme to UNIFIED-20.
    Args:
        parse_map: [H, W] long tensor, source scheme indices
        mapping: [N_source] long tensor
    Returns:
        [H, W] long tensor, UNIFIED-20 indices
    """
    assert parse_map.max() < len(mapping), \
        f"Label {parse_map.max()} out of range for mapping of length {len(mapping)}"
    return mapping[parse_map]
```

### 3.6 Garment Region Classes (UNIFIED-20)

```python
# Used for: agnostic mask construction, warp mask supervision, try-on region definition

GARMENT_CLASSES_UPPER = [5, 6]          # Upper-cloth, Coat/Jacket
GARMENT_CLASSES_LOWER = [8, 9]          # Pants, Skirt
GARMENT_CLASSES_DRESS = [7]             # Dress (full-body single garment)

# For agnostic mask: garment region + adjacent body parts to erase
AGNOSTIC_CLASSES_UPPER = [5, 6, 7, 10, 11]      # upper-cloth, coat, dress, arms
AGNOSTIC_CLASSES_LOWER = [8, 9, 12, 13, 14, 15] # pants, skirt, legs, shoes

GARMENT_CLASSES_BY_MODE = {
    'A': GARMENT_CLASSES_UPPER,
    'B': GARMENT_CLASSES_LOWER,
    'C': GARMENT_CLASSES_UPPER + GARMENT_CLASSES_LOWER,  # both
}
```

---

## PART 4: PREPROCESSING SPECIFICATION DOCUMENT

Generate `PREPROCESSING_SPEC.md` as a **standalone reference document** (not executable code). This enables any user to reproduce the preprocessing pipeline from raw person/garment images. The document must contain the following sections:

### Section 1: Tool Inventory
Full table of all tools required, versions, install commands, and GPU requirements:

| Tool | Version | Purpose | Install |
|------|---------|---------|---------|
| OpenPose | 1.7.0 (BODY_18 model) | 18-keypoint skeleton estimation | Build from source (CUDA 11.x) |
| SCHP | latest commit | Human parsing: LIP-20 (VITON-HD) | `pip install -e git+https://github.com/PeikeLi/Self-Correction-Human-Parsing` |
| DensePose (detectron2) | 0.6 | IUV surface maps | `pip install detectron2==0.6+cu113` |
| Pillow | 10.3.0 | Image I/O | `pip install Pillow==10.3.0` |
| numpy | 1.26.4 | Array ops | `pip install numpy==1.26.4` |

### Section 2: Per-Modality Processing Commands

For each modality (M1–M11 for VITON-HD, M1–M7 for DressCode), document:
- **Input files consumed**
- **Exact CLI command with all flags** (copy-paste ready)
- **Output path and format**
- **Validation check** (what to verify before moving to next step)
- **Common failure modes** (what goes wrong and how to fix)

Include entries for all of:

**M3+M4 (OpenPose skeleton):**
```bash
# IMPORTANT: Use COCO body model (18 keypoints = 54 values), NOT BODY_25 (25 kps = 75 values)
# BODY_25 is the default and WILL PRODUCE WRONG OUTPUT. Always specify --model_pose COCO.
cd /path/to/openpose && \
./build/examples/openpose/openpose.bin \
  --image_dir /data/viton_hd/train/image/ \
  --write_images /data/viton_hd/train/openpose-img/ \
  --write_json /data/viton_hd/train/openpose-json/ \
  --model_pose COCO \
  --display 0 --render_pose 1 --hand 0 --face 0 \
  --net_resolution "-1x368"
# Validation: JSON must have exactly 54 values in pose_keypoints_2d (18 × 3)
# Common failure: default BODY_25 produces 75 values → JSON schema validation FAILS at training
```

**M2 (SCHP Human Parsing — LIP-20 for VITON-HD):**
```bash
python run_parsing.py \
  --input /data/viton_hd/train/image/ \
  --output /data/viton_hd/train/image-parse-v3/ \
  --dataset LIP \
  --model_restore checkpoints/final.pth
# Output: palette-encoded PNG. Each pixel is a class index (0-19) stored as palette color.
# Validation: Load with PIL, convert to numpy, verify unique values subset of {0..19}
```

**M6 for DressCode (ATR-18 parsing):**
```bash
python run_parsing.py \
  --input /data/dresscode/lower_body/images/ \
  --output /data/dresscode/lower_body/label_maps/ \
  --dataset ATR \
  --model_restore checkpoints/atr.pth
# ATR model produces 18-class maps, NOT LIP-20. The dataset loader maps ATR→UNIFIED-20.
```

**M9 (DensePose IUV):**
```bash
cd /path/to/detectron2/projects/DensePose && \
python apply_net.py show \
  configs/densepose_rcnn_R_50_FPN_s1x.yaml \
  densepose_rcnn_R_50_FPN_s1x.pkl \
  dp_u dp_v dp_i \
  --input /data/viton_hd/train/image/ \
  --output /data/viton_hd/train/image-densepose/ \
  --opts MODEL.DEVICE cuda
# Output format: R=part_id (0-24), G=U_coord (0-255), B=V_coord (0-255), uint8 PNG
# Validation: R channel values must all be in [0,24]. Non-zero pixels > 20% of image.
# DressCode: run same command on dresscode/lower_body/images/ → dresscode/lower_body/dense/
```

**M7+M8 Agnostic Construction (VITON-HD):**
```bash
# Not a model — derived from parse map + person image
python construct_agnostic.py \
  --image_dir /data/viton_hd/train/image/ \
  --parse_dir /data/viton_hd/train/image-parse-v3/ \
  --out_agnostic /data/viton_hd/train/agnostic-v3.2/ \
  --out_mask /data/viton_hd/train/agnostic-mask/ \
  --scheme lip20 \
  --erase_classes 5,6,7,10,15 \
  --fill_value mean_pixel
# LIP-20 classes 5(upper-cloth), 6(dress), 7(coat), 10(left-arm), 15(right-arm) are erased.
# fill_value=mean_pixel uses per-image average (not global) for fill. Gray fill (128) also works.
# Validation: mask should cover 15-45% of image pixels for typical upper-body garments.
```

**DressCode Agnostic Construction (derived, not provided):**
```bash
python construct_agnostic.py \
  --image_dir /data/dresscode/lower_body/images/ \
  --parse_dir /data/dresscode/lower_body/label_maps/ \
  --out_agnostic /data/dresscode/lower_body/agnostic/ \
  --out_mask /data/dresscode/lower_body/agnostic_mask/ \
  --scheme atr18 \
  --erase_classes 6,11,12,13,14 \
  --fill_value mean_pixel
# ATR-18 classes 6(pants), 11(left-leg), 12(right-leg), 13(left-shoe), 14(right-shoe) erased.
# Validation: mask should cover 30-60% of pixels for lower-body garments (larger region).
```

### Section 3: Dataset Validation Checklist (Run Before Training)
```
Run: python validate_dataset.py --config configs/multi_dataset.yaml

VITON-HD train expected output:
  [PASS] 11,647 valid pairs
  [PASS] 11 modalities present for all pairs
  [PASS] All images: 1024×768 RGB
  [PASS] parse_map: unique values ⊆ {0..19} (LIP-20, before mapping)
  [PASS] DensePose: mean body coverage > 20%
  [PASS] Agnostic mask: 15-45% coverage per image
  [PASS] Skeleton: mean conf > 0.1 keypoints ≥ 10

DressCode lower_body train expected output:
  [PASS] ~4,500 valid pairs (verify pairs.txt count)
  [PASS] 7 modalities present (no warp-cloth — expected)
  [PASS] parse_map: unique values ⊆ {0..17} (ATR-18, before mapping)
  [PASS] DensePose: mean lower-body coverage > 35%
  [PASS] Agnostic mask: 30-60% coverage per image

Any [FAIL] generates failed_pairs.txt for manual inspection.
```

### Section 4: Pairing Strategy for Menswear
```
VITON-HD: paired images provided (person already wearing cloth in image).
  Pair list: image/{stem}.jpg ↔ cloth/{stem}.jpg  (same stem = paired)
  Unpaired (test): pairs.txt lists cross-person cloth assignments.

DressCode lower_body: pairs.txt format:
  "000001_0.jpg\t000001_1.jpg"
  _0 suffix = person image, _1 suffix = cloth image.
  Parse pairs.txt to build (person_path, cloth_path) list.
```

---

## PART 5: ARCHITECTURE (MENSWEAR-OPTIMIZED)

All v3.0 architectural decisions are inherited and confirmed. The following specifics apply to v4.0-M-P:

### 5.1 Pipeline Overview

```
INPUTS (per batch item):
  person_image [3,H,W]        agnostic_image [3,H,W]      agnostic_mask [1,H,W]
  parsing_map [H,W] (UNIFIED-20)  pose_image [3,H,W]      skeleton_heatmaps [18,H,W]
  cloth_image [3,H,W]         cloth_mask [1,H,W]          densepose_iuv [3,H,W]
  warp_cloth [3,H,W]*         warp_cloth_mask [1,H,W]*
  tryon_mode: 'A' | 'B' | 'C'
  (* = VITON-HD only)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STAGE 0: CONDITIONING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ParseMapEmbedder (vocab=20)
    parsing_map → parse_embedded [3, H/8, W/8]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STAGE 1: GEOMETRIC ALIGNMENT (jointly trained)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BodyConditionEncoder (Swin V2 + CNN + EmbedCNN + DensePose)
    → {F_body_4, F_body_8, F_body_16}

  GarmentFeatureExtractor (ConvNeXt + Shape CNN)
    → {F_cloth_4, F_cloth_8, F_cloth_16} + z_cloth

  PartAwareWarpingModule (5-part TPS, fixed for menswear)
    → cloth_warped, cloth_mask_warped, deformation_field, part_masks

  GarmentLatentAdapter (1×1 Conv2d)
    VAE.encode(cloth_warped) → cloth_warped_latent [4, H/8, W/8]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STAGE 2: LATENT DIFFUSION SYNTHESIS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  [FROZEN] VAE, CLIP Image Encoder
  IPAdapterProjection (pretrained h94/IP-Adapter SD v1.5)
    → garment_context [16, 768]

  DiffusionSynthesisUNet (SD v1.5 Inpainting, 17-ch input)
    Input: noisy_latent(4) + masked_img_latent(4) + agnostic_mask_latent(1)
           + cloth_warped_latent(4) + cloth_mask_warped(1) + parse_embedded(3)
    Cross-attn: garment_context (IP-Adapter tokens)
    → predicted_noise [4, H/8, W/8]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
COMPOSITOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  RegionCompositor → I_final [3, H, W]
  EMA shadow UNet (inference only)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MODE C (PAIR): TWO SEQUENTIAL PASSES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PASS 1 (Mode A internally):
    person_image + shirt_cloth → I_upper [3, H, W]

  PASS 2 (Mode B internally):
    I_upper (as new person_image) + pants_cloth → I_final [3, H, W]
    agnostic_mask for Pass 2 is re-derived from I_upper parse estimate
    (or from dataset's lower-body agnostic mask when available)
```

### 5.2 BodyConditionEncoder — Mode-Aware DensePose Conditioning

The `BodyConditionEncoder` uses DensePose IUV in a **mode-aware** manner:

- **Mode A (upper):** DensePose Branch D attends to upper-body part indices (DENSEPOSE_UPPER_BODY_PARTS = [1,2,3,4,5,6]). Apply a part-index filter: `densepose_upper = densepose_iuv * (part_mask_upper.float())` before feeding to Branch D.
- **Mode B (lower):** Attend to lower-body part indices (DENSEPOSE_LOWER_BODY_PARTS = [7,8,9,10,11,12]). Apply `densepose_lower = densepose_iuv * (part_mask_lower.float())`.
- **Mode C:** Use full DensePose (no filter) in Pass 1. Use lower-body filtered DensePose in Pass 2.

Implementation:
```python
def filter_densepose_by_mode(
    densepose_iuv: torch.Tensor,  # [B, 3, H, W]
    mode: str,
    device: torch.device
) -> torch.Tensor:
    """Filter DensePose IUV to retain only relevant body part regions for the try-on mode."""
    part_channel = densepose_iuv[:, 0:1, :, :]  # R channel = part index (normalized [0,1])
    part_index = (part_channel * 24).round().long()  # de-normalize to [0,24]

    if mode == 'A':
        valid_parts = torch.tensor(DENSEPOSE_UPPER_BODY_PARTS, device=device)
    elif mode == 'B':
        valid_parts = torch.tensor(DENSEPOSE_LOWER_BODY_PARTS, device=device)
    else:
        return densepose_iuv  # Mode C uses full map

    mask = (part_index.unsqueeze(-1) == valid_parts).any(dim=-1)  # [B, 1, H, W]
    return densepose_iuv * mask.float()
```

### 5.3 PartAwareWarpingModule — Fixed 5-Part (Menswear)

5-part segmentation is fixed for this system. The 5 parts and their menswear semantics:

| Part | Upper-body (Mode A) | Lower-body (Mode B) |
|------|--------------------|--------------------|
| 0 | Torso / chest | Hip / waistband region |
| 1 | Left sleeve | Left thigh |
| 2 | Right sleeve | Right thigh |
| 3 | Lower front hem | Left leg |
| 4 | Lower back hem | Right leg |

The warp module uses the same architecture for both modes — the semantic meaning of each part shifts based on the garment geometry. The part segmenter CNN learns the correct geometric decomposition from the training data for each category. No explicit part-label switching is needed.

### 5.4 TryOnModeRouter (`models/tryon_mode_router.py`)

Responsible for orchestrating Mode C two-pass composition:

```python
class TryOnModeRouter:
    """
    Routes batch items to the correct try-on pipeline based on tryon_mode.
    For Mode C, orchestrates two sequential single-garment passes.
    """

    def forward_single_pass(
        self,
        batch: Dict[str, torch.Tensor],
        mode: str,  # 'A' or 'B'
        body_encoder,
        garment_extractor,
        warp_module,
        garment_adapter,
        parse_embedder,
        ip_adapter,
        diffusion_unet,
        compositor,
        vae,
        scheduler,
        num_steps: int,
    ) -> Dict[str, torch.Tensor]:
        """Execute one full pass of the pipeline for a single garment."""
        # (full implementation — not a stub)
        ...

    def forward_pair(
        self,
        person_image: torch.Tensor,
        shirt_cloth: torch.Tensor,
        shirt_cloth_mask: torch.Tensor,
        pants_cloth: torch.Tensor,
        pants_cloth_mask: torch.Tensor,
        batch_upper: Dict[str, torch.Tensor],  # full batch for upper pass
        batch_lower: Dict[str, torch.Tensor],  # full batch for lower pass
        all_modules: dict,
        num_steps: int,
    ) -> torch.Tensor:
        """
        Mode C: two sequential passes.

        Pass 1: person_image + shirt → I_upper
          - batch_upper contains agnostic_mask for upper body
          - Output: I_upper [B, 3, H, W]

        Pass 2: I_upper + pants → I_final
          - Replace person_image with I_upper in batch_lower
          - Replace agnostic fields with lower-body versions
          - batch_lower['person_image'] = I_upper  (detach for inference)
          - Output: I_final [B, 3, H, W]
        """
        ...
```

**Critical implementation detail for Mode C training:**
During training, Mode C samples are presented as two separate batch items (one upper, one lower) to avoid doubling memory consumption. True pair composition (passing I_upper into Pass 2) is only done at **inference time**. At training time, upper and lower garment passes are trained independently from ground truth. This is the same training strategy used by PSAD.

Configure this via `cfg.training.mode_c_training = 'independent'` (default, recommended) vs `'sequential'` (pairs only, 2× memory, enable only if paired outfit data available).

### 5.5 Diffusion UNet — 17 Channels for All Single-Garment Modes

Unlike the v4.0 prompt which proposed 21 channels for Mode C, this system uses **17 channels for ALL modes (A, B, and C)**. Mode C composition happens sequentially at inference — the UNet always receives one garment at a time. This avoids the complexity of a mode-switching UNet and maintains a single set of pretrained weights.

```
UNet input channels (all modes): 17
  Channels 0-3:   noisy_image_latent         [4] — from diffusion process
  Channels 4-7:   masked_image_latent         [4] — VAE.encode(agnostic_image)
  Channel  8:     agnostic_mask_latent        [1] — agnostic_mask downsampled to latent res
  Channels 9-12:  cloth_warped_latent         [4] — from GarmentLatentAdapter
  Channel  13:    cloth_mask_warped_latent    [1] — cloth_mask_warped downsampled
  Channels 14-16: parse_embedded              [3] — from ParseMapEmbedder

Pretrained SD Inpainting base: 9 channels (0-8)
New channels (9-16): initialized with σ=0.02 (small random, NOT zero)
```

---

## PART 6: DATASET LOADER VALIDATION SYSTEM

### 6.1 JSON Schema Validation (`utils/schema_validator.py`)

Implement `SchemaValidator` class with:

```python
OPENPOSE_SCHEMA = {
    "type": "object",
    "required": ["people"],
    "properties": {
        "people": {
            "type": "array",
            "minItems": 1,
            "items": {
                "required": ["pose_keypoints_2d"],
                "properties": {
                    "pose_keypoints_2d": {
                        "type": "array",
                        "minItems": 54, "maxItems": 54,
                        "items": {"type": "number"}
                    }
                }
            }
        }
    }
}
```

Validation is run **once per training run at startup** (not per-sample during training to avoid I/O overhead). The validator scans a random 10% sample of JSONs, raises `DatasetValidationError` if any fail schema check, logs warnings for structural anomalies.

### 6.2 Class Histogram Verification (`utils/dataset_validator.py`)

`DatasetValidator.run(dataset, sample_frac=0.05)` scans 5% of parse maps after UNIFIED-20 mapping and verifies:
- All values in [0, 19] (UNIFIED-20 range)
- Background (class 0) present in > 95% of samples
- Face (class 3) present in > 70% of samples
- Upper-cloth (class 5) present in > 60% of VITON-HD samples
- Pants (class 8) present in > 60% of DressCode-lower samples
- No index ≥ 20 (catches mapping bugs immediately)

Output: structured validation report printed to stdout and saved to `logs/dataset_validation_{split}.txt`.

### 6.3 Tensor Dimension Assertions (per `__getitem__`)

```python
def _assert_sample_shapes(self, sample: Dict, H: int, W: int) -> None:
    """
    Assert every tensor in the sample dict has the expected shape and dtype.
    Called at end of every __getitem__. Raises AssertionError with stem name if fails.
    """
    EXPECTED_SHAPES = {
        'person_image':       ((3, H, W),   torch.float32),
        'agnostic_image':     ((3, H, W),   torch.float32),
        'agnostic_mask':      ((1, H, W),   torch.float32),
        'parsing_map':        ((H, W),      torch.int64),
        'pose_image':         ((3, H, W),   torch.float32),
        'skeleton_heatmaps':  ((18, H, W),  torch.float32),
        'cloth_image':        ((3, H, W),   torch.float32),
        'cloth_mask':         ((1, H, W),   torch.float32),
        'densepose_iuv':      ((3, H, W),   torch.float32),
        'pseudo_part_labels': ((H, W),      torch.int64),
    }
    OPTIONAL_SHAPES = {
        'warp_cloth':         ((3, H, W),   torch.float32),
        'warp_cloth_mask':    ((1, H, W),   torch.float32),
    }
    stem = sample.get('filename', 'unknown')
    for key, (shape, dtype) in {**EXPECTED_SHAPES, **OPTIONAL_SHAPES}.items():
        if key not in sample:
            if key in EXPECTED_SHAPES:
                raise AssertionError(f"Required key '{key}' missing for sample '{stem}'")
            continue
        actual_shape = tuple(sample[key].shape)
        actual_dtype = sample[key].dtype
        assert actual_shape == shape, \
            f"[{stem}] '{key}': expected shape {shape}, got {actual_shape}"
        assert actual_dtype == dtype, \
            f"[{stem}] '{key}': expected dtype {dtype}, got {actual_dtype}"

    # Range checks
    assert sample['parsing_map'].min() >= 0 and sample['parsing_map'].max() < 20, \
        f"[{stem}] parsing_map out of UNIFIED-20 range: [{sample['parsing_map'].min()}, {sample['parsing_map'].max()}]"
    assert sample['cloth_mask'].min() >= 0.0 and sample['cloth_mask'].max() <= 1.0, \
        f"[{stem}] cloth_mask out of [0,1] range"
    assert not torch.isnan(sample['person_image']).any(), \
        f"[{stem}] NaN detected in person_image"
```

---

## PART 7: COMPLETE FILE STRUCTURE (v4.0-M-P)

```
virtual_tryon/
├── configs/
│   ├── default.yaml                     # VITON-HD upper-body (Mode A baseline)
│   ├── dresscode_lower.yaml             # DressCode lower-body (Mode B)
│   └── multi_dataset.yaml               # VITON-HD + DressCode-lower (Mode A+B+C)
│
├── data/
│   ├── dataset_vitonhd.py               # VITONHDDataset (11 modalities, Mode A)
│   ├── dataset_dresscode_lower.py       # DressCodeLowerDataset (7+agnostic derived, Mode B)
│   └── unified_datamodule.py            # VirtualTryOnDataModule (multi-dataset, weighted)
│
├── models/
│   ├── __init__.py                      # Exports + FEATURE_RESOLUTIONS + all constants
│   ├── tps.py                           # Differentiable TPS (FP32 solve, K regularization)
│   ├── body_encoder.py                  # BodyConditionEncoder (4 branches + mode-aware DensePose)
│   ├── garment_extractor.py             # GarmentFeatureExtractor (ConvNeXt + Shape CNN)
│   ├── warping.py                       # PartAwareWarpingModule (5-part, fixed)
│   ├── garment_adapter.py               # GarmentLatentAdapter
│   ├── parse_embedder.py                # ParseMapEmbedder (vocab=20, UNIFIED-20)
│   ├── ip_adapter.py                    # IPAdapterProjection (pretrained h94/IP-Adapter)
│   ├── diffusion_unet.py                # DiffusionSynthesisUNet (17-ch, all modes)
│   ├── compositor.py                    # RegionCompositor
│   └── tryon_mode_router.py             # TryOnModeRouter (Mode A/B/C orchestration)
│
├── losses/
│   ├── __init__.py
│   ├── perceptual.py                    # VGG-19 perceptual loss (from scratch)
│   ├── ssim.py                          # SSIM loss (Gaussian window, from scratch)
│   ├── warp_losses.py                   # L_warp_smooth + L_warp_mask + L_part_seg + L_warp_pretrain
│   └── diffusion_loss.py                # L_denoise + L_x0_perceptual + L_SSIM + L_composite
│
├── utils/
│   ├── constants.py                     # UNIFIED-20 defs, all class lists, all norms
│   ├── label_mapper.py                  # LIP20→UNIFIED20, ATR18→UNIFIED20 tables + remap_labels()
│   ├── schema_validator.py              # JSON schema validation + DatasetValidationError
│   ├── dataset_validator.py             # DatasetValidator (histogram + coverage)
│   ├── viz.py                           # TensorBoard visualization utilities
│   └── metrics.py                       # SSIM, FID (clean-fid), LPIPS for eval
│
├── training/
│   ├── lightning_module.py              # VirtualTryOnModule (joint training, LR annealing, EMA)
│   └── trainer_setup.py                 # pl.Trainer: A100, bf16, callbacks
│
├── inference/
│   ├── infer.py                         # CLI: Mode A / B / C, pair_file support
│   └── preprocess_utils.py              # Mask2Former + DWPose auto-preprocess (Mode B fallback)
│
├── train.py                             # Entry point
├── requirements.txt                     # Pinned exact versions
├── PREPROCESSING_SPEC.md                # Standalone preprocessing reference doc
└── VirtualTryOn_Notebook.ipynb          # Complete Jupyter Notebook (valid JSON)
```

---

## PART 8: CONFIGURATION SYSTEM

### `configs/default.yaml`
```yaml
data:
  datasets:
    - name: viton_hd
      root: "./viton_hd"
      label_scheme: lip20
      weight: 1.0
      use_pretrained_warp: true
      default_tryon_mode: A
  image_height: 1024
  image_width: 768
  num_workers: 8
  batch_size: 4
  pin_memory: true
  validate_before_training: true
  validation_sample_frac: 0.05

tryon_mode: A

model:
  unified_parse_classes: 20    # UNIFIED-20
  body_encoder:
    backbone: swin_v2_base_patch4_window12_192_22k
    pretrained: true
    output_channels: 256
    use_densepose: true
  garment_extractor:
    backbone: convnext_base
    pretrained: true
    output_channels: 256
  warping:
    num_parts: 5
    num_control_points: 25
    correlation_max_displacement: 8
    tps_reg_lambda: 1.0e-5
  diffusion:
    base_model: "runwayml/stable-diffusion-inpainting"
    clip_model: "openai/clip-vit-large-patch14"
    ip_adapter_weights: "h94/IP-Adapter"
    unet_in_channels: 17       # Fixed for all modes
    scheduler_train: ddpm
    scheduler_inference: dpm_solver_pp
    num_inference_steps: 50
    num_inference_steps_fast: 20
    guidance_scale: 2.5
    cfg_dropout_prob: 0.1
    ip_num_tokens: 16
  compositor:
    base_channels: 32

training:
  max_epochs: 200
  lr_warp: 1.0e-4
  lr_diffusion: 5.0e-5
  lr_compositor: 1.0e-4
  weight_decay: 1.0e-2
  warmup_steps: 500
  gradient_clip: 1.0
  gradient_checkpointing: true
  effective_batch_size: 8
  warp_pretrain_decay_epochs: 10
  mode_c_training: independent  # 'independent' (recommended) or 'sequential'

losses:
  lambda_denoise: 1.0
  lambda_x0_perc: 0.05
  lambda_ssim: 0.05
  lambda_warp_smooth: 40.0
  lambda_warp_mask: 1.0
  lambda_part_seg: 0.5
  lambda_composite: 0.5
  lambda_warp_pretrain: 2.0     # Decays to 0 by warp_pretrain_decay_epochs
  vgg_layers: [relu1_1, relu2_1, relu3_1, relu4_1]
  vgg_weights: [0.03125, 0.0625, 0.125, 0.25]

logging:
  log_dir: "./logs"
  tensorboard: true
  log_images_every_n_steps: 200
  save_top_k: 3
  val_image_samples: 4

inference:
  device: cuda
  precision: bf16
  num_denoising_steps: 50
  guidance_scale: 2.5
```

### `configs/multi_dataset.yaml` (Modes A + B + C)
```yaml
# Inherits default.yaml, adds DressCode-lower
data:
  datasets:
    - name: viton_hd
      root: "./viton_hd"
      label_scheme: lip20
      weight: 1.0
      use_pretrained_warp: true
      default_tryon_mode: A
    - name: dresscode_lower
      root: "./dresscode/lower_body"
      label_scheme: atr18
      weight: 0.8
      use_pretrained_warp: false   # DressCode has no warp-cloth
      default_tryon_mode: B
  tryon_modes_enabled: [A, B, C]
```

---

## PART 9: UPDATED CONSTANTS (`utils/constants.py`)

```python
# ─── Normalization ───────────────────────────────────────────
RGB_MEAN = [0.5, 0.5, 0.5]
RGB_STD  = [0.5, 0.5, 0.5]
CLIP_MEAN = [0.48145466, 0.4578275, 0.40821073]
CLIP_STD  = [0.26862954, 0.26130258, 0.27577711]

# ─── Spatial Resolutions (H=1024, W=768) ─────────────────────
FEATURE_RESOLUTIONS = {4: (256,192), 8: (128,96), 16: (64,48), 32: (32,24)}
LATENT_H, LATENT_W = 128, 96
LATENT_SCALE_FACTOR = 8
VAE_SCALING_FACTOR = 0.18215

# ─── UNIFIED-20 Label Space ───────────────────────────────────
N_UNIFIED20 = 20
GARMENT_CLASSES_UPPER   = [5, 6]       # Upper-cloth, Coat/Jacket
GARMENT_CLASSES_LOWER   = [8, 9]       # Pants, Skirt
GARMENT_CLASSES_DRESS   = [7]          # Dress
AGNOSTIC_CLASSES_UPPER  = [5, 6, 7, 10, 11]       # + arms
AGNOSTIC_CLASSES_LOWER  = [8, 9, 12, 13, 14, 15]  # + legs, shoes
GARMENT_CLASSES_BY_MODE = {'A': [5,6], 'B': [8,9], 'C': [5,6,8,9]}

# ─── Flip Augmentation ───────────────────────────────────────
KEYPOINT_FLIP_PAIRS = [(1,2),(3,4),(5,6),(7,8),(9,10),(11,12),(13,14),(15,16)]
PARSE_FLIP_PAIRS_UNIFIED20 = [(10,11), (12,13), (14,15)]  # arms, legs, shoes

# ─── TPS / Warping ───────────────────────────────────────────
TPS_REG_LAMBDA = 1e-5
CORR_MAX_DISPLACEMENT = 8
CORR_FEATURE_DIM = 256

# ─── DensePose Body Parts ────────────────────────────────────
DENSEPOSE_NUM_PARTS = 24
DENSEPOSE_UPPER_BODY_PARTS = [1, 2, 3, 4, 5, 6]   # torso, arms
DENSEPOSE_LOWER_BODY_PARTS = [7, 8, 9, 10, 11, 12] # hips, thighs, legs, feet

# ─── Diffusion ───────────────────────────────────────────────
EMA_DECAY = 0.9999
CFG_DROPOUT_PROB = 0.1
IP_NUM_TOKENS = 16
UNET_IN_CHANNELS = 17   # Fixed for all modes in this system
```

---

## PART 10: REQUIREMENTS.TXT

```
torch==2.2.1+cu121
torchvision==0.17.1+cu121
torchaudio==2.2.1+cu121
pytorch-lightning==2.2.1
diffusers==0.27.2
transformers==4.39.3
accelerate==0.28.0
timm==0.9.16
omegaconf==2.3.0
tensorboard==2.16.2
Pillow==10.3.0
numpy==1.26.4
matplotlib==3.8.4
tqdm==4.66.2
scipy==1.13.0
einops==0.7.0
albumentations==1.4.3
xformers==0.0.25
triton==2.2.0
safetensors==0.4.2
huggingface-hub==0.22.2
controlnet-aux==0.0.7
clean-fid==0.1.35
lpips==0.1.4
jsonschema==4.22.0
```

---

## PART 11: INFERENCE PIPELINE (`inference/infer.py`)

### Mode A (Single Shirt):
```bash
python inference/infer.py \
  --person person.jpg \
  --cloth shirt.jpg \
  --mode A \
  --checkpoint best.ckpt \
  --output result_shirt.jpg \
  --steps 50
```

### Mode B (Single Pants):
```bash
python inference/infer.py \
  --person person.jpg \
  --cloth pants.jpg \
  --mode B \
  --checkpoint best.ckpt \
  --output result_pants.jpg
```

### Mode C (Pair — Shirt + Pants):
```bash
python inference/infer.py \
  --person person.jpg \
  --cloth_upper shirt.jpg \
  --cloth_lower pants.jpg \
  --mode C \
  --checkpoint best.ckpt \
  --output result_outfit.jpg \
  --steps 50
```

### Mode C Batch (Pair File):
```bash
python inference/infer.py \
  --pair_file pairs.txt \
  --mode C \
  --checkpoint best.ckpt \
  --output_dir results/ \
  --steps 20
```

**Mode C implementation in infer.py:**
```python
if args.mode == 'C':
    # PASS 1: upper garment
    batch_upper = preprocess_inputs(person_image, cloth_upper, mode='A', cfg=cfg)
    I_upper = run_single_pass(batch_upper, model, scheduler, steps=args.steps)
    # PASS 2: lower garment on I_upper
    # Re-derive agnostic for lower body from I_upper if no lower agnostic provided
    agnostic_lower, agnostic_mask_lower = derive_lower_agnostic(I_upper, cfg)
    batch_lower = preprocess_inputs(I_upper, cloth_lower, mode='B', cfg=cfg,
                                    agnostic=agnostic_lower, agnostic_mask=agnostic_mask_lower)
    I_final = run_single_pass(batch_lower, model, scheduler, steps=args.steps)
    save_result(I_final, args.output)
```

**`derive_lower_agnostic` implementation** (auto-preprocess for Pass 2 of Mode C):
```python
def derive_lower_agnostic(
    I_upper: torch.Tensor,  # [1, 3, H, W], float, [-1,1]
    cfg: DictConfig
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Derive lower-body agnostic image and mask from I_upper without external parsing.
    Uses a simple horizontal region heuristic for the lower body (below 55% height).
    This is acceptable for Mode C Pass 2 because I_upper already has the shirt applied
    correctly, and the lower-body region is geometrically predictable.
    """
    H, W = I_upper.shape[2], I_upper.shape[3]
    lower_start = int(H * 0.55)  # Lower body starts at 55% image height
    agnostic_mask = torch.zeros(1, 1, H, W, device=I_upper.device)
    agnostic_mask[:, :, lower_start:, :] = 1.0
    fill = I_upper.mean()
    agnostic_image = I_upper * (1.0 - agnostic_mask) + fill * agnostic_mask
    return agnostic_image, agnostic_mask
```

**Note:** The horizontal heuristic is valid here specifically because it operates on `I_upper` (not the original person image), and the lower body in standard e-commerce person images follows a consistent layout. If full-quality Mode C is required, provide pre-computed lower-body agnostic via `--agnostic_lower` and `--agnostic_mask_lower` arguments.

**Mode B fallback for inference auto-preprocessing:**
Same as v3.0 — use `Mask2Former` + `DWposeDetector` when `--auto_preprocess` flag is set.

---

## PART 12: JUPYTER NOTEBOOK SECTIONS

### Section 0: Environment Setup
- Install all dependencies
- HuggingFace login for gated model downloads
- Download pretrained models (SD v1.5 Inpainting, Swin V2, ConvNeXt, IP-Adapter)
- `!nvidia-smi` — verify A100

### Section 1: Dataset Verification (Both Datasets)
- Check VITON-HD folder structure, count pairs
- Check DressCode lower_body folder structure, count pairs
- Load one batch from each dataset using respective Dataset class
- Verify all 11 VITON-HD modalities load correctly with correct shapes
- Verify 7 DressCode modalities load correctly (including derived agnostic)
- Display all modalities side-by-side for one sample from each dataset
- Run `DatasetValidator` — display histogram report for both datasets

### Section 2: Label Mapping Verification
- Load one VITON-HD parse map (LIP-20) and show raw class distribution
- Apply `LIP20_TO_UNIFIED20` mapping, show UNIFIED-20 distribution
- Load one DressCode parse map (ATR-18) and show raw class distribution
- Apply `ATR18_TO_UNIFIED20` mapping, show UNIFIED-20 distribution
- Compare: both should show similar class distributions in UNIFIED-20 space

### Section 3: Architecture Inspection
- Instantiate `VirtualTryOnModule(cfg)` from `multi_dataset.yaml`
- Print per-module parameter count
- Run forward pass for each mode (A, B) with dummy batch
- Show DensePose filtering effect: Mode A vs Mode B body part masks

### Section 4: Training (All Three Phases via Single Joint Run)
- Configure `VirtualTryOnDataModule` with VITON-HD + DressCode-lower
- Show batch sampling: verify Mode A and Mode B batches are interleaved
- `trainer.fit(model, datamodule)`
- Live TensorBoard monitoring

### Section 5: Evaluation per Mode
- Load best checkpoint
- Mode A evaluation: VITON-HD test set (2,032 pairs). Compute FID, SSIM, LPIPS.
- Mode B evaluation: DressCode lower_body test set (~1,025 pairs). Compute FID, SSIM, LPIPS.
- Mode C evaluation: 5 manually curated outfit pairs (person + shirt + pants). Qualitative display.
- Expected metrics:
  - Mode A (VITON-HD): FID ~5.5–6.5, SSIM ~0.87–0.90
  - Mode B (DressCode lower): FID ~6.0–7.0, SSIM ~0.85–0.88
  - Mode C (pair): FID ~6.5–7.5 (composition penalty acceptable)

### Section 6: Pair Try-On Demo (Mode C)
- Upload `person.jpg`, `shirt.jpg`, `pants.jpg` via `files.upload()`
- Run Mode C inference: Pass 1 (shirt) → Pass 2 (pants)
- Display 4-panel result: `[original | after_shirt | after_pants_final | outfit_composite]`
- Save as `outfit_result.png`

---

## PART 13: INTEGRATION VERIFICATION CHECKLIST

Before generating each file, verify all boxes checked:

**Label System:**
- [ ] `N_UNIFIED20 = 20` in constants.py — not 25
- [ ] `ParseMapEmbedder` uses `vocab_size=20`
- [ ] Both dataset loaders call `remap_labels(parse_map, LIP20_TO_UNIFIED20)` or `remap_labels(parse_map, ATR18_TO_UNIFIED20)` respectively
- [ ] `GARMENT_CLASSES_BY_MODE` used for agnostic mask construction in BOTH datasets
- [ ] `PARSE_FLIP_PAIRS_UNIFIED20` = `[(10,11), (12,13), (14,15)]` (arms, legs, shoes) used in flip augmentation

**Dataset Validation:**
- [ ] `DatasetValidator.run()` called in `VirtualTryOnDataModule.setup()` for BOTH datasets
- [ ] OpenPose JSON schema checks `minItems: 54, maxItems: 54` (COCO 18-kp format)
- [ ] `_assert_sample_shapes()` called at end of EVERY `__getitem__` in both dataset classes
- [ ] `DatasetValidationError` raised (not just logged) when hard constraint violated
- [ ] Validation report saved to `logs/dataset_validation_{dataset}_{split}.txt`

**DressCode Derived Agnostic:**
- [ ] Agnostic mask for DressCode uses `AGNOSTIC_CLASSES_LOWER` from UNIFIED-20 (post-mapping)
- [ ] Fill value for agnostic image is per-image mean pixel value (NOT global constant)
- [ ] DressCode `warp_cloth` and `warp_cloth_mask` absent → `sample` dict omits these keys (not zero tensors)
- [ ] `λ_warp_pretrain = 0` when `use_pretrained_warp=False` in dataset config

**Mode C:**
- [ ] `TryOnModeRouter.forward_pair()` fully implemented (not a stub)
- [ ] During training: Mode C = independent A + B passes (not chained)
- [ ] During inference: Mode C = chained (I_upper → Pass 2)
- [ ] `derive_lower_agnostic()` implemented in `inference/infer.py`
- [ ] `--pair_file` argument supported in CLI with batch Mode C execution
- [ ] UNet channels = 17 for ALL modes (A, B, C) — no mode-switching channel counts

**DensePose Mode-Aware Filtering:**
- [ ] `filter_densepose_by_mode()` imported from `models/body_encoder.py`
- [ ] Mode A: DENSEPOSE_UPPER_BODY_PARTS filter applied
- [ ] Mode B: DENSEPOSE_LOWER_BODY_PARTS filter applied
- [ ] Mode C Pass 1: no filter (full DensePose); Pass 2: lower filter
- [ ] Zero DensePose fallback when file absent (both datasets)

**All v3.0 checks:**
- [ ] FEATURE_RESOLUTIONS from constants — never hardcoded
- [ ] CLIP normalization ONLY inside `ip_adapter.py`
- [ ] TPS_REG_LAMBDA added to K before `torch.linalg.solve`; FP32 cast around solve
- [ ] Correlation normalized by `sqrt(CORR_FEATURE_DIM)` = `sqrt(256)`
- [ ] No `.detach()` on `cloth_warped` in training graph
- [ ] VAE params frozen; no backprop through VAE encode/decode
- [ ] EMA updated every 10 steps; used only at inference via EMA weight load
- [ ] No SPADE anywhere in diffusion UNet
- [ ] DPM-Solver++ (50 steps) for validation; DDPM scheduler for training noise only
- [ ] Joint training only — no freezing/unfreezing cycles at any epoch

---

## PART 14: COMPLETE OUTPUT DELIVERABLES

Generate all 33 files completely, in order, without truncation. Label each with full path as a Markdown `##` header.

**Configuration (3 files):**
1. `requirements.txt`
2. `configs/default.yaml`
3. `configs/multi_dataset.yaml`

**Documentation (1 file):**
4. `PREPROCESSING_SPEC.md`

**Utilities (6 files):**
5. `utils/constants.py`
6. `utils/label_mapper.py`
7. `utils/schema_validator.py`
8. `utils/dataset_validator.py`
9. `utils/viz.py`
10. `utils/metrics.py`

**Data Loaders (3 files):**
11. `data/dataset_vitonhd.py`
12. `data/dataset_dresscode_lower.py`
13. `data/unified_datamodule.py`

**Models (12 files):**
14. `models/tps.py`
15. `models/body_encoder.py`
16. `models/garment_extractor.py`
17. `models/warping.py`
18. `models/garment_adapter.py`
19. `models/parse_embedder.py`
20. `models/ip_adapter.py`
21. `models/diffusion_unet.py`
22. `models/compositor.py`
23. `models/tryon_mode_router.py`
24. `models/__init__.py`

**Losses (5 files):**
25. `losses/perceptual.py`
26. `losses/ssim.py`
27. `losses/warp_losses.py`
28. `losses/diffusion_loss.py`
29. `losses/__init__.py`

**Training & Inference (4 files):**
30. `training/lightning_module.py`
31. `training/trainer_setup.py`
32. `train.py`
33. `inference/infer.py`
34. `inference/preprocess_utils.py`

**Notebook (1 file):**
35. `VirtualTryOn_Notebook.ipynb` (valid JSON, fully executable)

**If you reach a context limit before completing all 35 files:**
Output `=== CONTINUATION BREAK ===`.
State: "Stopped at file N of 35: [filename]. Last completed function: [function_name], line [N]."
Continue from that exact point in the next response. Do not summarize. Do not skip any file. Every function in every file must be complete and runnable.

---PROMPT END---
