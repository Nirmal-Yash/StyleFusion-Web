# VIRTUAL TRY-ON SYSTEM — PRODUCTION PROMPT v7.1 FINAL
## Dataset-Verified | Challenge-Hardened | Numerically Stable | Commercial-Grade

---

```
╔══════════════════════════════════════════════════════════════════════════════════╗
║        VIRTUAL TRY-ON SYSTEM — PRODUCTION PROMPT v7.1 FINAL           ║
║  Dataset-Verified | Challenge-Hardened | Memory-Optimal | All 11 Mods Active   ║
╚══════════════════════════════════════════════════════════════════════════════════╝

You are tasked with generating a COMPLETE, PRODUCTION-READY, COMMERCIALLY VIABLE
virtual try-on system from scratch. Every file must be fully implemented — no
`pass`, no `TODO`, no placeholder functions, no ellipsis (...) to abbreviate.
Code that cannot run on the first attempt is a hard failure.

Read this entire prompt in full before writing a single line of code.

═══════════════════════════════════════════════════════════════════════════════════
SECTION 0 — ABSOLUTE CONSTRAINTS (VIOLATIONS ARE FATAL)
═══════════════════════════════════════════════════════════════════════════════════

| # | Constraint                                                | Consequence            |
|---|-----------------------------------------------------------|------------------------|
| 1 | NO copied code from ANY open-source repository            | IP/legal liability     |
| 2 | NO exact class/function names from official repos         | Copyright risk         |
| 3 | ALL 37 files complete — zero truncation                   | Non-functional system  |
| 4 | ALL functions fully implemented — no pass/TODO            | Runtime crash          |
| 5 | ACTUAL VITON-HD folder names used (see Section 2)         | Dataset load failure   |
| 6 | ALL dataset paths sourced from cfg.data.paths — NEVER     |                        |
|   | hardcoded strings in dataset or validator code            | Brittle, unmaintainable|
| 7 | UNIFIED-25 label space mandatory — never raw LIP-20       | 60h refactor debt      |
| 8 | MOD-8 agnostic mask MUST be binarized from parse file     | Wrong compositing mask |
| 9 | MOD-10/11 ABSENT — all code handles None gracefully       | KeyError crash         |
|10 | WARP WARM-UP: epochs 0-1 freeze all except warp+conv_in  | Warp never converges   |
|11 | After epoch 2: FULL JOINT training — no re-freezing      | Catastrophic forgetting|
|12 | A100 80GB feasible — every module memory-annotated        | OOM training failure   |
|13 | DatasetValidator MUST pass before training starts         | Silent data corruption |
|14 | All tensor shapes asserted in every forward()             | Silent shape mismatch  |
|15 | TPS solver ALWAYS in FP32 regardless of training dtype    | NaN deformation field  |
|16 | ip_scale init=0.1, clamped to [0.0, 3.0] every forward   | Attention instability  |
|17 | EMA applied to ALL trainable parameters (not UNet only)   | Suboptimal inference   |
|18 | No preprocessing code — VITON-HD already processed       | Scope violation        |
|19 | Notebook executes cell-by-cell with zero errors           | Non-reproducible demo  |

If context limit is reached mid-file:
  Output exactly: "=== CONTINUE: {filename} line {line_number} ==="
  Resume from that exact line. Never summarize. Never skip. Never ellipsize.

═══════════════════════════════════════════════════════════════════════════════════
SECTION 1 — ARCHITECTURE RATIONALE
═══════════════════════════════════════════════════════════════════════════════════

## Why This Architecture (Production, Not Research Demo)

Commercial try-on has two failure modes:
  1. Pure GAN systems: sharp but geometrically wrong on complex poses
  2. Pure diffusion: high quality but garment texture hallucinated, identity drift

This system combines:
  - EXPLICIT TPS WARPING → anatomically correct garment placement
  - LATENT DIFFUSION      → photorealistic synthesis, no GAN artifacts
  - IP-ADAPTER            → semantic garment identity via CLIP patch tokens
  - DENSEPOSE + OPENPOSE  → 3D surface + skeleton body understanding
  - SEMANTIC PARSE        → region-aware composition, 25-class future-proof space
  - WARP WARM-UP          → guarantees warp stability before diffusion trains
  - CONFIDENCE-WEIGHTED   → graceful DensePose degradation (not hard cutoff)
    DENSEPOSE

## Target Metrics (VITON-HD Test Set, 2032 pairs)

| Metric | Epoch 50 | Epoch 100 | Epoch 150 | IDM-VTON Reference |
|--------|----------|-----------|-----------|--------------------|
| FID ↓  | ≤ 9.0    | ≤ 7.0     | ≤ 6.0     | 6.29               |
| LPIPS↓ | ≤ 0.09   | ≤ 0.07    | ≤ 0.06    | 0.0692             |
| SSIM ↑ | ≥ 0.85   | ≥ 0.88    | ≥ 0.90    | 0.8896             |

═══════════════════════════════════════════════════════════════════════════════════
SECTION 2 — ACTUAL VITON-HD DATASET STRUCTURE (VERIFIED)
═══════════════════════════════════════════════════════════════════════════════════

## 2.1 Actual On-Disk Folder Names (Use These — Not Idealized Spec Names)

viton_hd/
├── train/
│   ├── image/                      # [MOD-1]  Person RGB photo, 1024×768, JPG
│   ├── image-parse-v3/             # [MOD-2]  LIP-20 semantic parse, palette PNG
│   ├── openpose_img/               # [MOD-3]  Skeleton heatmap, 1024×768, PNG
│   │                                          ← UNDERSCORE (not hyphen)
│   ├── openpose_json/              # [MOD-4]  18 keypoints + confidence, JSON
│   │                                          ← UNDERSCORE (not hyphen)
│   ├── cloth/                      # [MOD-5]  Garment flat-lay RGB, JPG
│   ├── cloth-mask/                 # [MOD-6]  Binary garment mask, PNG
│   ├── agnostic-v3.2/              # [MOD-7]  Body-masked person image, PNG
│   └── image-parse-agnostic-v3.2/ # [MOD-8]  Parse-based agnostic region
│       ├── image-densepose/        #           ← PALETTE PNG — MUST BINARIZE
│                                   # [MOD-9]  DensePose IUV map, PNG
│                                              [R=part_id, G=U_coord, B=V_coord]
│   [warp-cloth/ — ABSENT]          # [MOD-10] ← NOT PRESENT — handle as None
│   [warp-cloth-mask/ — ABSENT]     # [MOD-11] ← NOT PRESENT — handle as None
├── test/                           # Identical structure (same 9 present subdirs)
├── train_pairs.txt                 # Format: "{person_id} {cloth_id}" per line
└── test_pairs.txt

CRITICAL NAMING FACTS (propagate to ALL files that reference paths):
  1. openpose_img  ← underscore separator (not openpose-img)
  2. openpose_json ← underscore separator (not openpose-json)
  3. image-parse-agnostic-v3.2 ← full folder name for MOD-8
     (some datasets use shorter name — use the full one present in your data)
  4. MOD-10 (warp-cloth) and MOD-11 (warp-cloth-mask) DO NOT EXIST
     → All code paths for these return None and losses return 0.0 tensor
     → No FileNotFoundError may ever occur due to these missing folders

## 2.2 MOD-8 Binarization (Critical — image-parse-agnostic-v3.2 is a Parse Map)

The folder image-parse-agnostic-v3.2 contains PALETTE PNG files (LIP-20 format),
NOT binary masks. The model requires a binary agnostic mask [0,1] for:
  - UNet input channel 8 (inpainting target region)
  - RegionCompositor hard prior (alpha=0 outside garment region)

Binarization rule (applied in VITONHDDataset.__getitem__):

def _binarize_agnostic_parse(parse_array: np.ndarray) -> np.ndarray:
    """
    Convert LIP-20 agnostic parse map to binary garment-region mask.
    
    LIP-20 classes that constitute the try-on target region (upper body):
      5  = Upper-cloth
      10 = Torso-skin (exposed torso under garment, included for coverage)
    
    These classes define where the new garment will be placed.
    All other classes → 0 (background/preserve original).
    
    Input:  parse_array [H, W] int, values in [0, 19]
    Output: binary_mask [H, W] float32, values in {0.0, 1.0}
    
    NOTE: Do NOT use class 7 (coat) or 6 (dress) — this is upper-cloth only.
    NOTE: Do NOT use class 14/15 (arms) — compositing handles arms separately.
    """
    binary = ((parse_array == 5) | (parse_array == 10)).astype(np.float32)
    return binary

Output tensor: [1, 1024, 768] float32, values in {0.0, 1.0}
Stored as: batch['agnostic_mask']

## 2.3 Complete Modality Table (Actual Paths + Transformations)

| MOD  | On-Disk Folder              | File Format    | Load Method      | Output Tensor          |
|------|-----------------------------|----------------|------------------|------------------------|
| MOD-1| image/                      | RGB JPG        | PIL→Tensor→Norm  | [3,1024,768] f32 [-1,1]|
| MOD-2| image-parse-v3/             | Palette PNG    | PIL.P→np→remap   | [1,1024,768] i64 [0,24]|
| MOD-3| openpose_img/ (underscore)  | RGB PNG        | PIL→Tensor→Norm  | [3,1024,768] f32 [-1,1]|
| MOD-4| openpose_json/ (underscore) | JSON           | json.load→coords | [36] f32 [0,1]         |
| MOD-5| cloth/                      | RGB JPG        | PIL→Augment→Norm | [3,1024,768] f32 [-1,1]|
| MOD-6| cloth-mask/                 | Greyscale PNG  | PIL.L→Tensor→bin | [1,1024,768] f32 [0,1] |
| MOD-7| agnostic-v3.2/              | RGB PNG        | PIL→Tensor→Norm  | [3,1024,768] f32 [-1,1]|
| MOD-8| image-parse-agnostic-v3.2/  | Palette PNG    | PIL.P→np→binarize| [1,1024,768] f32 {0,1} |
| MOD-9| image-densepose/            | RGB PNG        | PIL→Tensor÷255   | [3,1024,768] f32 [0,1] |
|MOD-10| [ABSENT]                    | —              | return None      | None                   |
|MOD-11| [ABSENT]                    | —              | return None      | None                   |

═══════════════════════════════════════════════════════════════════════════════════
SECTION 3 — UNIFIED-25 LABEL SPACE (MANDATORY — NEVER SIMPLIFY)
═══════════════════════════════════════════════════════════════════════════════════

## 3.1 Class Table

UNIFIED25_CLASSES = {
    0:  "Background",
    1:  "Hat",
    2:  "Hair",
    3:  "Face",
    4:  "Neck-Scarf",
    5:  "Upper-Cloth",         # ← Phase 1 PRIMARY ACTIVE CLASS
    6:  "Kurta",               # Reserved (future Indian textiles)
    7:  "Dress",               # Reserved (future womenswear)
    8:  "Dupatta",             # Reserved (future Indian textiles)
    9:  "Pants-Salwar",        # Reserved (future lower-body)
    10: "Torso-Skin",
    11: "Coat",
    12: "Left-Arm",
    13: "Right-Arm",
    14: "Left-Leg",
    15: "Right-Leg",
    16: "Left-Shoe",
    17: "Right-Shoe",
    18: "Socks",
    19: "Skirt",               # Reserved
    20: "Sunglasses",
    21: "Gloves",
    22: "Left-Bag",
    23: "Right-Bag",
    24: "Belt",
}

GARMENT_CLASSES_UPPER = [5]    # Extend by config, never by code change

## 3.2 LIP-20 → UNIFIED-25 Mapping (Exact — Applied to MOD-2 Only)

LIP20_TO_UNIFIED25 = {
    0:  0,   # Background  → Background
    1:  1,   # Hat         → Hat
    2:  2,   # Hair        → Hair
    3:  21,  # Glove       → Gloves
    4:  20,  # Sunglasses  → Sunglasses
    5:  5,   # Upper-cloth → Upper-Cloth  ← CRITICAL: pixel count MUST be preserved
    6:  7,   # Dress       → Dress
    7:  11,  # Coat        → Coat
    8:  18,  # Socks       → Socks
    9:  9,   # Pants       → Pants-Salwar
    10: 10,  # Torso-skin  → Torso-Skin
    11: 4,   # Scarf       → Neck-Scarf
    12: 19,  # Skirt       → Skirt
    13: 3,   # Face        → Face
    14: 12,  # Left-arm    → Left-Arm
    15: 13,  # Right-arm   → Right-Arm
    16: 14,  # Left-leg    → Left-Leg
    17: 15,  # Right-leg   → Right-Leg
    18: 16,  # Left-shoe   → Left-Shoe
    19: 17,  # Right-shoe  → Right-Shoe
}
# Classes 6, 8, 22, 23, 24 in UNIFIED-25 are unused in Phase 1.
# They receive zero gradient — zero cost.

## 3.3 remap_labels Function (utils/label_mapper.py)

def remap_labels(
    parse_map: torch.Tensor,    # [H, W] int64, values [0, 19]
    mapping: dict,              # LIP20_TO_UNIFIED25
    target_vocab_size: int = 25
) -> torch.Tensor:
    """
    Remap segmentation map from LIP-20 to UNIFIED-25 label space.
    
    Guarantees:
      - Output dtype: torch.int64
      - Source class not in mapping → 0 (background)
      - All output values in [0, target_vocab_size)
      - Class 5 pixel count is IDENTICAL before and after mapping
        (enforced by DatasetValidator check #5)
    """
    max_src = max(mapping.keys()) + 1
    lut     = torch.zeros(max_src, dtype=torch.int64, device=parse_map.device)
    for src, tgt in mapping.items():
        lut[src] = tgt
    remapped = lut[parse_map.clamp(0, max_src - 1)]
    assert remapped.max() < target_vocab_size, (
        f"Remapped value {remapped.max().item()} ≥ vocab_size={target_vocab_size}"
    )
    return remapped

NOTE: remap_labels is applied to MOD-2 (image-parse-v3) ONLY.
      MOD-8 (image-parse-agnostic-v3.2) uses _binarize_agnostic_parse ONLY.
      These are two separate operations on two separate files. Never confuse them.

═══════════════════════════════════════════════════════════════════════════════════
SECTION 4 — COMPLETE ARCHITECTURE SPECIFICATION
═══════════════════════════════════════════════════════════════════════════════════

## 4.1 System Data Flow

INPUT BATCH
  (9 active modalities loaded from disk + 2 derived tensors)
       │
       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 1: BODY CONDITION ENCODING                                          │
│                                                                             │
│  Branch-A: SwinV2-Small(agnostic_img [MOD-7] + agnostic_mask [MOD-8])     │
│              → F_agn_4 [B,128,256,192], F_agn_8 [B,256,128,96]            │
│                                                                             │
│  Branch-B: PoseCNN(openpose_img [MOD-3]) +                                 │
│            KeypointMLP(keypoint_coords from [MOD-4])                       │
│              → F_pose_8 [B,256,128,96]                                     │
│                                                                             │
│  Branch-C: ParseEmbedCNN(parse_unified25 from [MOD-2], vocab=25)           │
│              → F_parse_8 [B,256,128,96]                                    │
│                                                                             │
│  Branch-D: DensePoseCNN(densepose_iuv [MOD-9]) × confidence_weight        │
│              → F_dense_8 [B,256,128,96]  (confidence-weighted, not binary) │
│                                                                             │
│  Cross-Attention Fusion → F_body = {F_b4, F_b8, F_b16}                    │
└──────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 2: GARMENT FEATURE EXTRACTION                                       │
│                                                                             │
│  TextureCNN: ConvNeXt-Tiny(cloth_image [MOD-5])                            │
│              → F_g4, F_g8, F_g16                                           │
│  ShapeCNN: LightCNN(cloth_mask [MOD-6])                                    │
│              → F_shape_8                                                   │
│  GlobalPool → z_cloth [B,512]                                              │
│  Fusion → F_garment_8 [B,256,128,96]                                       │
└──────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 3: PART-AWARE GEOMETRIC WARPING                                     │
│                                                                             │
│  PartSegmenter(F_b8) → 5 part masks (soft pseudo-label from parse)         │
│  LocalCorrelation(F_b8, F_g8, D=8) [BF16] → corr [B,289,128,96]           │
│  WarpFlowPredictor → flow_fields [B,5,2,128,96]                            │
│  DifferentiableTPS [FP32 ALWAYS, identity init] → 5 warp grids             │
│  WarpBlender → cloth_warped [B,3,1024,768], cloth_mask_warped [B,1,...]    │
│                                                                             │
│  AUX LOSS (MOD-10/11 absent → L_warp_pt = 0.0, L_warp_m = 0.0)           │
└──────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 4: LATENT SPACE                                                     │
│  FrozenVAE.encode(cloth_warped) → cloth_latent [B,4,128,96]               │
│  GarmentLatentAdapter(cloth_latent) → cloth_latent_adapted                │
│  FrozenVAE.encode(agnostic_image [MOD-7]) → masked_person_latent          │
│  FrozenVAE.encode(person_image [MOD-1]) → person_latent_clean (target)    │
└──────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 5: IP-ADAPTER (cloth_image_raw [MOD-5, unaugmented] → CLIP)        │
│  FrozenCLIP.encode(cloth_image_raw) → clip_features [B,257,1024]          │
│  ImageProjectMLP → ip_tokens [B,16,768]                                   │
│  ip_scale: init=0.1, clamp=[0,3.0]                                        │
└──────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 6: 17-CHANNEL DIFFUSION SYNTHESIS                                   │
│                                                                             │
│  Ch  0- 3: noise_latent          [B,4,128,96]                              │
│  Ch  4- 7: masked_person_latent  [B,4,128,96]                              │
│  Ch  8:    agnostic_mask_ds      [B,1,128,96]  ← from binarized MOD-8     │
│  Ch  9-12: cloth_latent_adapted  [B,4,128,96]                              │
│  Ch  13:   cloth_mask_warped_ds  [B,1,128,96]                              │
│  Ch 14-16: parse_embedded        [B,3,128,96]                              │
│                                                                             │
│  SD 1.5 Inpainting UNet (17-ch) + IPAdapterAttnProcessor                  │
│  EMA on ALL trainable params, decay=0.9999                                 │
└──────────────────────────────┬─────────────────────────────────────────────┘
                                │
                                ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  STAGE 7: REGION COMPOSITING                                               │
│  FrozenVAE.decode(denoised_latent) → I_synth [B,3,1024,768]               │
│  RegionCompositor(I_synth, person_image, agnostic_mask)                    │
│  Learned alpha × agnostic_mask (hard prior: 0 outside garment region)     │
│  Supervisor: softened-agnostic BCE with boundary upweighting              │
│  I_final = alpha × I_synth + (1-alpha) × person_image                     │
└────────────────────────────────────────────────────────────────────────────┘

## 4.2 Module Specifications

### MODULE A: BodyConditionEncoder (models/body_encoder.py)
Memory: ~2.1 GB

Branch-A: SwinV2-Small
  Input:  concat(agnostic_image [B,3,...], agnostic_mask [B,1,...]) → [B,4,1024,768]
          Note: agnostic_mask already binarized from image-parse-agnostic-v3.2
  Backbone: timm swinv2_small_window8_256, pretrained=True, fine-tune all layers
  Agnostic augmentation (train only): random cutout 1-3 patches, p=0.3
  Output: F_agn_4 [B,128,256,192], F_agn_8 [B,256,128,96]

Branch-B: PoseCNN + KeypointMLP
  Input A: openpose_img [B,3,1024,768] from openpose_img/ (underscore folder)
  Input B: keypoint_coords [B,36] extracted from openpose_json/ JSON files
  
  OpenPose JSON format (exact structure expected):
    {
      "people": [
        {
          "pose_keypoints_2d": [x0,y0,c0, x1,y1,c1, ..., x17,y17,c17]
        }
      ]
    }
    Extraction:
      joints_raw = people[0]['pose_keypoints_2d']  # length 54
      coords = []
      for i in range(18):
        x_norm = joints_raw[i*3+0] / W   # normalize by image width
        y_norm = joints_raw[i*3+1] / H   # normalize by image height
        coords.extend([x_norm, y_norm])   # confidence not used — only coords
      keypoint_coords = torch.tensor(coords, dtype=torch.float32)  # [36]
    
    If no person in JSON (people list empty): return torch.zeros(36)
    Augmentation: Gaussian noise σ=0.005 on all coords (p=0.5), clamp [0,1]
    Flip: x_new = 1.0 - x_old, swap L/R joints using OPENPOSE_FLIP_PAIRS below
  
  OPENPOSE_FLIP_PAIRS (18-joint model, left↔right symmetric pairs):
    OPENPOSE_FLIP_PAIRS = [
        (1, 2),   # left_eye ↔ right_eye
        (3, 4),   # left_ear ↔ right_ear
        (5, 6),   # left_shoulder ↔ right_shoulder
        (7, 8),   # left_elbow ↔ right_elbow
        (9, 10),  # left_wrist ↔ right_wrist
        (11, 12), # left_hip ↔ right_hip
        (13, 14), # left_knee ↔ right_knee
        (15, 16), # left_ankle ↔ right_ankle
    ]
    # Joint 0 = nose (no pair), 17 = neck (no pair)
  
  Heatmap stream: Conv(3→64,7,s2) → GN → GELU → Conv(64→128,3,s2) → GN → GELU
                  → Conv(128→256,3,s2) → GN → GELU → F_pose_heatmap [B,256,128,96]
  Keypoint MLP:   Linear(36→128) → GELU → Linear(128→256*12) → reshape → broadcast-add
  Output: F_pose_8 [B,256,128,96]

Branch-C: ParseMapEmbedCNN
  Input:  parse_unified25 [B,1,1024,768] int64 (MOD-2 after remap, vocab 25)
  nn.Embedding(25, 64) with weight init normal(0, 0.01)
  ChannelAttention gate: sigmoid(Linear(25→25)(class_frequencies)) per batch
  Strided CNN: stride-8 total → F_parse_8 [B,256,128,96]
  Output: F_parse_8 [B,256,128,96]

Branch-D: DensePoseCNN (confidence-weighted)
  Input:  densepose_iuv [B,3,1024,768] float [0,1] from image-densepose/
          (R=part_id normalized, G=U_coord, B=V_coord — all in [0,1])
  
  Coverage computation:
    # R channel × 255 gives raw part ID
    # part_id > 0 means a DensePose body part is detected
    raw_part = (densepose_iuv[:,0] * 255.0).round().long()   # [B,H,W]
    coverage  = (raw_part > 0).float().mean(dim=[1,2])        # [B] scalar per sample
  
  Confidence weight (soft, not binary):
    confidence = (coverage / DENSEPOSE_MIN_COVERAGE).clamp(0.0, 1.0)  # [B]
    # Coverage 0.0 → weight 0.0 (branch contributes nothing)
    # Coverage 0.15+ → weight 1.0 (full contribution)
    # Coverage 0.07 → weight 0.47 (partial contribution — uses partial info)
  
  Encoding:
    part_emb = nn.Embedding(25, 32)(raw_part.clamp(0,24))    # [B,32,H,W]
    uv_feats = Conv2d(2, 64)(densepose_iuv[:,1:])             # [B,64,H,W]
    combined = concat(part_emb, uv_feats, dim=1)              # [B,96,H,W]
    F_dense  = strided_cnn_s8(combined)                       # [B,256,128,96]
    F_dense_8 = F_dense * confidence.view(B,1,1,1)            # weighted
  
  Output: F_dense_8 [B,256,128,96]

Cross-Attention Fusion:
  Q from F_agn_8, KV from concat(F_pose_8, F_parse_8, F_dense_8)
  MultiheadAttention(256, 8 heads, dropout=0.1)
  Residual + LayerNorm → F_body_8

  Final outputs (ASSERT ALL):
    assert F_b4.shape  == (B, 128, 256, 192)
    assert F_b8.shape  == (B, 256, 128,  96)
    assert F_b16.shape == (B, 512,  64,  48)

### MODULE B: GarmentFeatureExtractor (models/garment_extractor.py)
Memory: ~1.4 GB

  TextureEncoder: timm convnext_tiny, pretrained=True, fine-tune all
  Input: cloth_image [B,3,1024,768] AUGMENTED version
  NOTE: cloth_image_raw (pre-augmentation) goes to CLIP — cloth_image goes here
  
  Cloth augmentations (train only, applied jointly to cloth_image + cloth_mask):
    1. Horizontal flip (same state as global flip) — see Section 6.1
    2. Random affine (p=0.5): rotation ±5°, scale 0.95–1.05, shear ±3°
       Interpolation: bilinear for cloth_image, nearest for cloth_mask
    3. Color jitter ON cloth_image ONLY (not cloth_mask, not cloth_image_raw):
       brightness=0.15, contrast=0.15, saturation=0.10, hue=0.05
  
  Output: F_g4 [B,96,256,192], F_g8 [B,192,128,96], F_g16 [B,384,64,48]

  ShapeEncoder: 1→16→32→64→128, stride-8, GN+GELU
  Input: cloth_mask [B,1,1024,768] (affine-transformed, same as cloth_image)
  Output: F_shape_8 [B,128,128,96]

  GlobalPool: F_g8 → AdaptiveAvgPool2d(1) → flatten → Linear(192,512) → GELU
  Output: z_cloth [B,512]

  Fusion: Concat(F_g8, F_shape_8) → Conv2d(320,256,1) → F_garment_8
  ASSERT: F_garment_8.shape == (B, 256, 128, 96)
  ASSERT: z_cloth.shape == (B, 512)

### MODULE C: DifferentiableTPS (models/tps.py)
Memory: ~0.3 GB

IDENTITY INITIALIZATION — CRITICAL FOR STABILITY:
  Control points initialized to a regular 5×5 grid in [-0.8, 0.8]
  Source and target start at identical positions → identity warp at epoch 0
  This anchors TPS to no-deformation before correlation features are meaningful.

FP32 SOLVE — MANDATORY:
  torch.linalg.solve ALWAYS called on .float() tensors, regardless of bf16 training
  Return value cast back to input dtype after solve

class DifferentiableTPS(nn.Module):
  def __init__(self, n_cp=25, lambda_reg=1e-5):
    # n_cp = 25 (5×5 control points per part)
    # lambda_reg = 1e-5 (K matrix regularizer)
    lin = torch.linspace(-0.8, 0.8, 5)
    gy, gx = torch.meshgrid(lin, lin, indexing='ij')
    self.register_buffer('identity_ctrl_pts',
        torch.stack([gx.flatten(), gy.flatten()], dim=-1))  # [25,2]
  
  def forward(self, ctrl_pts_src, ctrl_pts_tgt, output_size) -> torch.Tensor:
    # ctrl_pts_src: [B,25,2]  ctrl_pts_tgt: [B,25,2]  → returns [B,H,W,2]
    
    # Step 1: RBF kernel K [B,25,25]
    diff = ctrl_pts_src.unsqueeze(2) - ctrl_pts_src.unsqueeze(1)  # [B,25,25,2]
    dist = diff.norm(dim=-1)                                        # [B,25,25]
    K    = dist**2 * torch.log(dist + 1e-8)                        # [B,25,25]
    
    # Step 2: P matrix [B,25,3]
    ones = torch.ones(B, self.n_cp, 1, device=ctrl_pts_src.device,
                      dtype=ctrl_pts_src.dtype)
    P = torch.cat([ones, ctrl_pts_src], dim=-1)
    
    # Step 3: System L [B,28,28]
    zeros33 = torch.zeros(B,3,3, device=K.device, dtype=K.dtype)
    top    = torch.cat([K, P], dim=-1)
    bottom = torch.cat([P.transpose(1,2), zeros33], dim=-1)
    L      = torch.cat([top, bottom], dim=1)
    
    # Step 4: Regularize + FP32 solve
    I25  = torch.eye(self.n_cp, device=K.device, dtype=K.dtype).unsqueeze(0)
    Lreg = L.clone()
    Lreg[:, :self.n_cp, :self.n_cp] += self.lambda_reg * I25
    Y    = torch.cat([ctrl_pts_tgt,
                      torch.zeros(B,3,2, device=K.device, dtype=K.dtype)], dim=1)
    coeffs = torch.linalg.solve(Lreg.float(), Y.float()).to(ctrl_pts_src.dtype)
    
    # Step 5: Dense evaluation at all output grid points
    H, W = output_size
    gy, gx = torch.meshgrid(
        torch.linspace(-1,1,H,device=ctrl_pts_src.device),
        torch.linspace(-1,1,W,device=ctrl_pts_src.device), indexing='ij')
    pts = torch.stack([gx.flatten(), gy.flatten()], dim=1)  # [H*W,2]
    pts = pts.unsqueeze(0).expand(B,-1,-1)                  # [B,H*W,2]
    
    diff2 = pts.unsqueeze(2) - ctrl_pts_src.unsqueeze(1)    # [B,H*W,25,2]
    dist2 = diff2.norm(dim=-1)
    phi   = dist2**2 * torch.log(dist2 + 1e-8)              # [B,H*W,25]
    ones2 = torch.ones(B, H*W, 1, device=pts.device, dtype=pts.dtype)
    P2    = torch.cat([ones2, pts], dim=-1)                  # [B,H*W,3]
    basis = torch.cat([phi, P2], dim=-1)                     # [B,H*W,28]
    grid  = (basis @ coeffs).view(B, H, W, 2)               # [B,H,W,2]
    
    return grid.clamp(-1.1, 1.1)  # prevent extreme extrapolation artifacts
  
  def identity_penalty(self, ctrl_pts_src, ctrl_pts_tgt) -> torch.Tensor:
    """
    L2 penalty on displacement from identity.
    High early in training (lambda=5.0), linearly decayed to 0 by epoch 20.
    Anchors TPS when correlation features are still noisy.
    """
    return ((ctrl_pts_tgt - ctrl_pts_src) ** 2).mean()

### MODULE D: PartAwareWarpingModule (models/warping.py)
Memory: ~1.8 GB

Sub-module D.1: PartSegmenter
  Input: F_b8 [B,256,128,96] → 3-layer decoder → Conv(?,5,1) → softmax
  Output: part_masks [B,5,128,96]
  5 parts: [Torso-front, Left-sleeve, Right-sleeve, Lower-front, Lower-back]

Sub-module D.2: LocalCorrelationVolume (BF16 optimization)
  Inputs: F_b8, F_garment_8  both [B,256,128,96]
  D=8 (max_displacement, from config — reduce to 6 if OOM)
  
  # L2-normalize in FP32 for precision, compute correlation in BF16
  f1 = F.normalize(F_b8.float(), dim=1).to(F_b8.dtype)
  f2 = F.normalize(F_garment_8.float(), dim=1).to(F_garment_8.dtype)
  f2_pad = F.pad(f2, [D,D,D,D])
  f2_unfold = F.unfold(f2_pad, kernel_size=2*D+1, stride=1)
              .view(B, C, (2*D+1)**2, H*W)
  f1_flat   = f1.view(B, C, H*W)
  corr = torch.einsum('bcn,bcqn->bqn', f1_flat, f2_unfold).view(B,(2*D+1)**2,H,W)
  corr = corr / math.sqrt(C)
  Output: corr_vol [B,289,128,96] — ~284 MB at B=4 in BF16

Sub-module D.3: WarpFlowPredictor
  Inputs: corr_vol [B,289,128,96], part_masks [B,5,128,96], z_cloth [B,512]
  Conv(289+5→256→128) + residual + z_cloth broadcast-add + 5× per-part heads
  Output: flow_fields [B,5,2,128,96]

Sub-module D.4: TPS Warp + Blend
  ctrl_pts_src = identity_ctrl_pts.unsqueeze(0).expand(B*5,-1,-1)  # [B*5,25,2]
  ctrl_pts_tgt = ctrl_pts_src + flow_fields.view(B*5, -1, 2) scaled
  tps_grids = DifferentiableTPS(ctrl_pts_src, ctrl_pts_tgt, (128,96)) → upsample to (1024,768)
  
  cloth_warped = softmax-weighted blend of per-part warped cloths
  cloth_mask_warped = softmax-weighted blend of per-part warped masks

Full output dict (ASSERT ALL SHAPES):
  {
    "cloth_warped":       [B,3,1024,768],
    "cloth_mask_warped":  [B,1,1024,768],
    "deformation_field":  [B,2, 128,  96],
    "part_masks_full":    [B,5,1024, 768],
    "ctrl_pts_src":       [B,5,  25,   2],
    "ctrl_pts_tgt":       [B,5,  25,   2],
  }

### MODULE E: GarmentLatentAdapter (models/garment_adapter.py)
Memory: ~0.1 GB

  Input: cloth_warped [B,3,1024,768]
  FrozenVAE.encode (NO_GRAD always):
    latent = vae.encode(cloth_warped).latent_dist.sample() * 0.18215  # [B,4,128,96]
  Adapter (trainable):
    nn.Sequential(Conv2d(4,4,1), GroupNorm(4,4), GELU(), Conv2d(4,4,1))
  Output: cloth_latent_adapted [B,4,128,96]
  ASSERT: cloth_latent_adapted.shape == (B, 4, 128, 96)

### MODULE F: IPAdapterProjection (models/ip_adapter.py)
Memory: ~0.9 GB

  CRITICAL DETAILS:
    ip_scale = nn.Parameter(torch.tensor(0.1))  ← init 0.1 NOT 1.0
    null_emb = nn.Parameter(torch.zeros(1,16,768))
  
  FrozenCLIPEncoder:
    clip-vit-large-patch14, ALL params frozen (requires_grad=False)
    Input: cloth_image_raw [B,3,1024,768] — UNAUGMENTED version from dataset
    Bicubic resize to [B,3,224,224] with antialias=True BEFORE feeding to CLIP
    Output: last_hidden_state [B,257,1024]  (CLS + 256 patch tokens, use both)
  
  ImageProjectMLP (trainable):
    features_mean = clip_out.mean(dim=1)          # [B,1024]
    ip_tokens_flat = Linear(1024→768*16)(features_mean)   # [B,12288]
    ip_tokens = ip_tokens_flat.view(B, 16, 768)   # [B,16,768]
  
  CFG dropout (training only, p=0.1):
    drop_mask = torch.rand(B,1,1) < 0.1
    ip_tokens = where(drop_mask, null_emb.expand(B,-1,-1), ip_tokens)
  
  ip_to_k, ip_to_v: Linear(768,768) each (trainable)
  
  forward() returns: ip_keys [B,16,768], ip_values [B,16,768], ip_scale (clamped)
  
  IPAdapterAttnProcessor (used in diffusion_unet.py):
    Clamp BEFORE every use: scale = ip_scale.clamp(0.0, 3.0)
    output = attn_standard + scale * attn_ip

### MODULE G: ParseMapEmbedder (models/parse_embedder.py)
Memory: ~0.05 GB

  nn.Embedding(25, 64), init: normal(0, 0.01)
  Stride-8 CNN: 64→64→64→32→3 channels → [B,3,128,96]
  ChannelAttention gate on batch class frequencies
  ASSERT: output.shape == (B, 3, 128, 96)

### MODULE H: DiffusionSynthesisUNet (models/diffusion_unet.py)
Memory: ~6.5 GB

  Base: runwayml/stable-diffusion-inpainting
  conv_in: Conv2d(9→320,3,1,1) → Conv2d(17→320,3,1,1)
  
  Weight initialization:
    new_conv.weight.data[:, :9] = pretrained_state['conv_in.weight']
    new_conv.weight.data[:, 9:] = torch.randn(320,8,3,3) * 0.01
    new_conv.bias.data           = pretrained_state['conv_in.bias']
  
  17-channel input composition:
    Ch 0-3:   noise_latent [B,4,128,96]
    Ch 4-7:   masked_person_latent [B,4,128,96] (VAE encode of agnostic_image)
    Ch 8:     agnostic_mask_ds [B,1,128,96]  ← binarized MOD-8, 8× bilinear downsample
    Ch 9-12:  cloth_latent_adapted [B,4,128,96]
    Ch 13:    cloth_mask_warped_ds [B,1,128,96]  ← 8× nearest downsample
    Ch 14-16: parse_embedded [B,3,128,96]
    TOTAL:    [B,17,128,96]
    ASSERT shape before UNet call
  
  Warp warm-up freeze (managed by LightningModule, NOT in this file):
    epochs 0-1: only conv_in channels 9-16 gradient active (via hook)
    epoch 2+: all UNet parameters trainable
  
  EMA: covers all trainable UNet params + all other trainable params in system
  Inference sampler: DPMSolverMultistepScheduler, 50 steps, guidance_scale=2.5

### MODULE I: RegionCompositor (models/compositor.py)
Memory: ~0.3 GB

  Input: concat(I_synth[B,3], person_image[B,3], agnostic_mask[B,1]) → [B,7,H,W]
  fusion_net: Conv(7→32,3,p1)→GN→GELU → Conv(32→32,3,p1)→GN→GELU → Conv(32→1,1)
  alpha_logit: [B,1,1024,768]
  alpha = sigmoid(alpha_logit) * agnostic_mask  ← hard prior: zero outside garment
  I_final = alpha * I_synth + (1-alpha) * person_image
  
  Returns: (I_final [B,3,H,W], alpha [B,1,H,W], alpha_logit [B,1,H,W])
  
  Compositor loss (L_comp):
    soft_mask = gaussian_blur(agnostic_mask, sigma=3.0).clamp(0,1)
    boundary_weight = 1.0 + 2.0 * sobel_edge(agnostic_mask)  # upweight edges
    L_comp = (boundary_weight * BCE_with_logits(alpha_logit, soft_mask)).mean()

═══════════════════════════════════════════════════════════════════════════════════
SECTION 5 — LOSS FUNCTIONS
═══════════════════════════════════════════════════════════════════════════════════

## 5.1 Loss Taxonomy

Total = λ_denoise   * L_denoise    # SNR-weighted (Min-SNR, γ=5.0)
      + λ_x0_perc   * L_x0_perc   # VGG-19 perceptual on predicted x0
      + λ_ssim      * L_ssim      # 1 - SSIM(pred_x0, person_image)
      + λ_warp_s    * L_warp_s    # Laplacian 2nd-order warp smoothness
      + λ_warp_m    * L_warp_m    # Warp mask BCE — RETURNS 0.0 (MOD-11 absent)
      + λ_warp_pt   * L_warp_pt   # Pre-warp L1 — RETURNS 0.0 (MOD-10 absent)
      + λ_identity  * L_identity  # TPS identity penalty (decays to 0 by ep 20)
      + λ_part_seg  * L_part_seg  # Part-seg soft pseudo-supervision
      + λ_comp      * L_comp      # Compositor boundary BCE

## 5.2 MOD-10/11 Absent: Graceful Zero Returns (losses/warp_losses.py)

def compute_warp_pretrain_loss(cloth_warped, warp_cloth_gt, warp_mask_gt):
    """Returns 0.0 tensor (not Python 0) when MOD-10 is absent."""
    if warp_cloth_gt is None:
        return torch.tensor(0.0, device=cloth_warped.device,
                            requires_grad=False)
    mask = (warp_mask_gt > 0.5).float()
    return (F.l1_loss(cloth_warped, warp_cloth_gt, reduction='none') * mask).mean()

def compute_warp_mask_loss(cloth_mask_warped, warp_mask_gt):
    """Returns 0.0 tensor when MOD-11 is absent."""
    if warp_mask_gt is None:
        return torch.tensor(0.0, device=cloth_mask_warped.device,
                            requires_grad=False)
    return F.binary_cross_entropy_with_logits(cloth_mask_warped, warp_mask_gt)

IMPORTANT: The loss weights λ_warp_m and λ_warp_pt remain in the schedule
as normal. When these losses return 0.0, multiplying by any λ is still 0.0.
No special-casing in the schedule needed.

## 5.3 Dynamic Loss Weight Schedule

def get_loss_weights(epoch: int) -> dict:
    if epoch <= 1:             # WARM-UP (warp learning, UNet new channels only)
        identity_w = 5.0
        return {
            'lambda_denoise':  0.2,
            'lambda_x0_perc':  0.0,
            'lambda_ssim':     0.0,
            'lambda_warp_s':   80.0,
            'lambda_warp_m':   3.0,   # will be multiplied by 0.0 loss
            'lambda_warp_pt':  3.0,   # will be multiplied by 0.0 loss
            'lambda_identity': identity_w,
            'lambda_part_seg': 1.0,
            'lambda_comp':     0.1,
        }
    elif epoch <= 20:          # STABILIZATION (identity + warp_pt decay)
        t          = (epoch - 2) / 18.0
        identity_w = 5.0 * max(0.0, 1.0 - t)
        return {
            'lambda_denoise':  0.5 + 0.5 * t,
            'lambda_x0_perc':  0.02,
            'lambda_ssim':     0.02,
            'lambda_warp_s':   60.0,
            'lambda_warp_m':   2.0,
            'lambda_warp_pt':  0.0,   # MOD-10 absent anyway
            'lambda_identity': identity_w,
            'lambda_part_seg': 0.5,
            'lambda_comp':     0.3,
        }
    elif epoch <= 80:          # BALANCED
        return {
            'lambda_denoise':  1.0,
            'lambda_x0_perc':  0.05,
            'lambda_ssim':     0.05,
            'lambda_warp_s':   40.0,
            'lambda_warp_m':   1.0,
            'lambda_warp_pt':  0.0,
            'lambda_identity': 0.0,
            'lambda_part_seg': 0.5,
            'lambda_comp':     0.5,
        }
    else:                      # QUALITY (diffusion dominant)
        return {
            'lambda_denoise':  1.2,
            'lambda_x0_perc':  0.08,
            'lambda_ssim':     0.08,
            'lambda_warp_s':   25.0,
            'lambda_warp_m':   0.5,
            'lambda_warp_pt':  0.0,
            'lambda_identity': 0.0,
            'lambda_part_seg': 0.3,
            'lambda_comp':     0.5,
        }

═══════════════════════════════════════════════════════════════════════════════════
SECTION 6 — DATASET LOADING (ACTUAL FOLDER NAMES INTEGRATED)
═══════════════════════════════════════════════════════════════════════════════════

## 6.1 VITONHDDataset (data/dataset_vitonhd.py) — Complete Spec

ALL paths sourced from cfg.data.paths — NEVER hardcoded.

class VITONHDDataset(Dataset):
  
  def __init__(self, cfg, split='train'):
    self.root  = Path(cfg.data.data_root) / split
    self.split = split
    self.cfg   = cfg
    
    # Path map sourced entirely from cfg — NO hardcoded strings
    paths = cfg.data.paths  # OmegaConf DictConfig
    self.dir_person       = self.root / paths.image
    self.dir_parse        = self.root / paths.parse
    self.dir_openpose_img = self.root / paths.openpose_img    # underscore folder
    self.dir_openpose_json= self.root / paths.openpose_json   # underscore folder
    self.dir_cloth        = self.root / paths.cloth
    self.dir_cloth_mask   = self.root / paths.cloth_mask
    self.dir_agnostic     = self.root / paths.agnostic
    self.dir_agn_parse    = self.root / paths.agnostic_mask   # palette parse file
    self.dir_densepose    = self.root / paths.densepose
    # Optional paths — may be None in config
    wc  = getattr(paths, 'warp_cloth',      None)
    wcm = getattr(paths, 'warp_cloth_mask', None)
    self.dir_warp_cloth      = (self.root / wc)  if wc  else None  # → None
    self.dir_warp_cloth_mask = (self.root / wcm) if wcm else None  # → None
    
    # Load pair list
    pair_file = Path(cfg.data.data_root) / f"{split}_pairs.txt"
    self.samples = []
    with open(pair_file) as f:
      for line in f:
        parts = line.strip().split()
        if len(parts) == 2:
          self.samples.append({'person_id': parts[0], 'cloth_id': parts[1]})
    
    # Menswear filter
    if cfg.data.get('apply_menswear_filter', True) and split == 'train':
      self.samples = self._apply_menswear_filter(self.samples)
      
  def __len__(self):
    return len(self.samples)
  
  def __getitem__(self, idx) -> dict:
    s = self.samples[idx]
    pid, cid = s['person_id'], s['cloth_id']
    
    # ── Load all modalities ──────────────────────────────────────────────
    
    # MOD-1: Person image
    person_img = self._load_rgb(self.dir_person / f"{pid}.jpg")
    
    # MOD-2: LIP-20 parse → remap to UNIFIED-25
    parse_lip20 = self._load_palette_png(self.dir_parse / f"{pid}.png")  # [H,W] int
    parse_u25   = remap_labels(
        torch.from_numpy(parse_lip20).long(),
        LIP20_TO_UNIFIED25, target_vocab_size=25
    )  # [H,W] int64
    
    # MOD-3: OpenPose skeleton heatmap (from openpose_img/ — underscore)
    openpose_img = self._load_rgb(self.dir_openpose_img / f"{pid}_rendered.png")
    # Note: filename pattern may vary — check actual filenames in your dataset
    # Common patterns: {pid}.png, {pid}_rendered.png, {pid}_keypoints.png
    
    # MOD-4: OpenPose JSON (from openpose_json/ — underscore)
    kp_coords = self._load_keypoints(self.dir_openpose_json / f"{pid}_keypoints.json")
    
    # MOD-5: Cloth image (augmented version + raw version for CLIP)
    cloth_img_pil = Image.open(self.dir_cloth / f"{cid}.jpg").convert("RGB")
    cloth_img_raw = self._pil_to_tensor_norm(cloth_img_pil)  # unaugmented [3,H,W]
    
    # MOD-6: Cloth mask
    cloth_mask_pil = Image.open(self.dir_cloth_mask / f"{cid}.png").convert("L")
    
    # Apply cloth augmentations (jointly to MOD-5 + MOD-6)
    cloth_img_aug, cloth_mask_aug = self._augment_cloth(cloth_img_pil, cloth_mask_pil)
    
    # MOD-7: Agnostic image
    agnostic_img = self._load_rgb(self.dir_agnostic / f"{pid}.png")
    
    # MOD-8: Agnostic mask — BINARIZE from palette parse file
    agn_parse_array = self._load_palette_png(self.dir_agn_parse / f"{pid}.png")
    agnostic_mask_np = self._binarize_agnostic_parse(agn_parse_array)  # [H,W] float32
    agnostic_mask    = torch.from_numpy(agnostic_mask_np).unsqueeze(0)  # [1,H,W]
    
    # MOD-9: DensePose IUV
    densepose_iuv = self._load_densepose(self.dir_densepose / f"{pid}_iuv.png")
    coverage      = self._compute_densepose_coverage(densepose_iuv)
    
    # MOD-10/11: ABSENT — always None
    warp_cloth      = None
    warp_cloth_mask = None
    
    # ── Apply joint horizontal flip ──────────────────────────────────────
    if self.split == 'train' and torch.rand(1).item() < 0.5:
      # Flip ALL spatial tensors with same state
      person_img    = TF.hflip(person_img)
      parse_u25     = torch.flip(parse_u25, dims=[-1])  # flip W dimension
      openpose_img  = TF.hflip(openpose_img)
      agnostic_img  = TF.hflip(agnostic_img)
      agnostic_mask = TF.hflip(agnostic_mask)
      densepose_iuv = TF.hflip(densepose_iuv)
      cloth_img_aug = TF.hflip(cloth_img_aug)
      cloth_mask_aug= TF.hflip(cloth_mask_aug)
      kp_coords     = self._flip_keypoints(kp_coords)   # x=1-x, swap L/R pairs
    
    # ── Apply agnostic cutout augmentation ──────────────────────────────
    if self.split == 'train':
      agnostic_img = self._random_cutout(agnostic_img, n_patches=2, p=0.3)
    
    # ── Build output dict ────────────────────────────────────────────────
    return {
        'person_image':      person_img,             # [3,1024,768] f32 [-1,1]
        'parse_lip20':       torch.from_numpy(parse_lip20).long().unsqueeze(0),
        'parse_unified25':   parse_u25.unsqueeze(0), # [1,1024,768] i64 [0,24]
        'openpose_img':      openpose_img,            # [3,1024,768] f32 [-1,1]
        'keypoint_coords':   kp_coords,               # [36] f32 [0,1]
        'cloth_image':       cloth_img_aug,           # [3,1024,768] f32 [-1,1]
        'cloth_image_raw':   cloth_img_raw,           # [3,1024,768] f32 [-1,1]
        'cloth_mask':        cloth_mask_aug,          # [1,1024,768] f32 [0,1]
        'agnostic_image':    agnostic_img,            # [3,1024,768] f32 [-1,1]
        'agnostic_mask':     agnostic_mask,           # [1,1024,768] f32 {0,1}
        'densepose_iuv':     densepose_iuv,           # [3,1024,768] f32 [0,1]
        'densepose_coverage':torch.tensor(coverage),  # scalar f32
        'warp_cloth':        warp_cloth,              # None (MOD-10 absent)
        'warp_cloth_mask':   warp_cloth_mask,         # None (MOD-11 absent)
        'person_id':         pid,
        'cloth_id':          cid,
    }
  
  def _load_palette_png(self, path: Path) -> np.ndarray:
    """Load palette PNG as integer array. Returns [H,W] int values."""
    img = Image.open(path)
    return np.array(img.convert("P") if img.mode != "P" else img, dtype=np.int64)
  
  def _binarize_agnostic_parse(self, parse_array: np.ndarray) -> np.ndarray:
    """
    Binarize LIP-20 agnostic parse map to upper-body garment region mask.
    Classes 5 (Upper-cloth) and 10 (Torso-skin) → 1.0, all others → 0.0
    """
    return ((parse_array == 5) | (parse_array == 10)).astype(np.float32)
  
  def _load_keypoints(self, path: Path) -> torch.Tensor:
    """
    Load OpenPose JSON, extract 18-joint normalized coordinates.
    Returns [36] float32 tensor. Returns zeros if no person detected.
    """
    if not path.exists():
      return torch.zeros(36, dtype=torch.float32)
    with open(path) as f:
      data = json.load(f)
    if not data.get('people'):
      return torch.zeros(36, dtype=torch.float32)
    raw = data['people'][0]['pose_keypoints_2d']  # length 54: x,y,c per joint
    W, H = 768, 1024
    coords = []
    for i in range(18):
      x_norm = float(raw[i*3+0]) / W
      y_norm = float(raw[i*3+1]) / H
      coords.extend([x_norm, y_norm])
    return torch.tensor(coords, dtype=torch.float32).clamp(0.0, 1.0)
  
  def _flip_keypoints(self, kp: torch.Tensor) -> torch.Tensor:
    """Flip keypoint x-coordinates and swap L/R symmetric joint pairs."""
    kp = kp.clone()
    # Flip x: x_new = 1 - x_old (y unchanged)
    kp[0::2] = 1.0 - kp[0::2]
    # Swap L/R pairs
    FLIP_PAIRS = [(1,2),(3,4),(5,6),(7,8),(9,10),(11,12),(13,14),(15,16)]
    for l, r in FLIP_PAIRS:
      kp[[l*2, l*2+1]], kp[[r*2, r*2+1]] = \
          kp[[r*2, r*2+1]].clone(), kp[[l*2, l*2+1]].clone()
    return kp
  
  def _compute_densepose_coverage(self, densepose_iuv: torch.Tensor) -> float:
    """
    Compute fraction of pixels with a detected DensePose body part.
    DensePose PNG stores part_id in R channel, normalized to [0,1].
    Part ID 0 = background. Raw ID > 0 = body surface.
    """
    raw_part = (densepose_iuv[0] * 255.0).round().long()  # R channel → [0,24]
    return (raw_part > 0).float().mean().item()
  
  def _is_menswear_candidate(self, parse_lip20: np.ndarray) -> bool:
    upper_freq = (parse_lip20 == 5).mean()
    dress_freq  = (parse_lip20 == 6).mean()
    return bool(upper_freq > 0.20 and dress_freq < 0.05)
  
  def _apply_menswear_filter(self, samples: list) -> list:
    kept = []
    for s in samples:
      parse_path = self.dir_parse / f"{s['person_id']}.png"
      if parse_path.exists():
        parse_arr = self._load_palette_png(parse_path)
        if self._is_menswear_candidate(parse_arr):
          kept.append(s)
      else:
        kept.append(s)  # keep if parse missing to avoid data loss
    logger.info(f"Menswear filter: {len(kept)}/{len(samples)} kept "
                f"({len(kept)/max(1,len(samples)):.1%})")
    return kept

## 6.2 DatasetValidator (data/validators.py) — Complete Spec

class VITONHDValidator:
  """
  Validates the actual VITON-HD dataset structure before training.
  Uses cfg.data.paths for all directory names — no hardcoded strings.
  """
  
  # ACTUAL folder names for your dataset (sourced from config, not hardcoded)
  # The following shows the expected config values:
  #   paths.image          = "image"
  #   paths.parse          = "image-parse-v3"
  #   paths.openpose_img   = "openpose_img"       ← underscore
  #   paths.openpose_json  = "openpose_json"       ← underscore
  #   paths.cloth          = "cloth"
  #   paths.cloth_mask     = "cloth-mask"
  #   paths.agnostic       = "agnostic-v3.2"
  #   paths.agnostic_mask  = "image-parse-agnostic-v3.2"
  #   paths.densepose      = "image-densepose"
  
  def validate(self, cfg, split='train') -> ValidationReport:
    self.cfg    = cfg
    self.root   = Path(cfg.data.data_root) / split
    self.paths  = cfg.data.paths
    self.failures = []
    self.warnings = []
    self.info     = []
    
    checks = [
      self._check_directory_structure(),
      self._check_pair_lists(cfg, split),
      self._check_image_dimensions(),
      self._check_parse_class_distribution(),
      self._check_label_mapping_correctness(),
      self._check_densepose_coverage(),
      self._check_openpose_quality(),
      self._check_agnostic_mask_coverage(),
      self._check_warp_cloth_availability(),   # expects None — documents it
      self._check_cloth_mask_quality(),
    ]
    
    # Save report JSON, print colored summary
    return self._build_report(checks)
  
  def _check_directory_structure(self) -> CheckResult:
    """
    Check #1 [CRITICAL]: All required folders exist under split root.
    Uses cfg.data.paths — no hardcoded names.
    """
    required = [
      self.paths.image,
      self.paths.parse,
      self.paths.openpose_img,     # "openpose_img" — underscore
      self.paths.openpose_json,    # "openpose_json" — underscore
      self.paths.cloth,
      self.paths.cloth_mask,
      self.paths.agnostic,
      self.paths.agnostic_mask,    # "image-parse-agnostic-v3.2"
      self.paths.densepose,
    ]
    optional = []
    # MOD-10/11 paths are None in config — expected absent, do NOT add to required
    wc  = getattr(self.paths, 'warp_cloth',      None)
    wcm = getattr(self.paths, 'warp_cloth_mask', None)
    if wc:  optional.append(wc)
    if wcm: optional.append(wcm)
    
    missing_required = [d for d in required if not (self.root / d).exists()]
    missing_optional = [d for d in optional if not (self.root / d).exists()]
    
    for d in missing_optional:
      self.info.append(f"Optional folder absent (OK): {d} — L_warp_pt/m will be 0.0")
    
    if missing_required:
      return CheckResult('FAIL', f"Missing required: {missing_required}")
    return CheckResult('PASS', f"All {len(required)} required folders present")
  
  def _check_parse_class_distribution(self) -> CheckResult:
    """
    Check #4 [CRITICAL]: MOD-2 parse maps have valid LIP-20 class distribution.
    Also checks MOD-8 (agnostic parse) for valid binarization input.
    """
    # ... (sample 500 parse maps, compute histogram, assert class 5 in >80%)
  
  def _check_label_mapping_correctness(self) -> CheckResult:
    """
    Check #5 [CRITICAL]: LIP20→UNIFIED25 mapping preserves class-5 pixel count.
    Also verifies MOD-8 binarization produces valid binary output.
    
    MOD-2 mapping check:
      raw5_count = (parse_lip20 == 5).sum()
      map5_count = (parse_u25   == 5).sum()
      assert raw5_count == map5_count
    
    MOD-8 binarization check:
      agn_parse = load_palette_png(agnostic_parse_path)
      binary    = binarize_agnostic_parse(agn_parse)
      assert binary.min() >= 0.0 and binary.max() <= 1.0
      assert set(binary.flatten().tolist()).issubset({0.0, 1.0})
      assert binary.mean() > 0.05  # garment region must be visible
    """
  
  def _check_warp_cloth_availability(self) -> CheckResult:
    """
    Check #9 [INFO]: Documents that MOD-10/11 are absent (expected for your data).
    Training continues normally — L_warp_pt and L_warp_m return 0.0.
    """
    wc_path  = getattr(self.paths, 'warp_cloth',      None)
    wcm_path = getattr(self.paths, 'warp_cloth_mask', None)
    if wc_path is None and wcm_path is None:
      msg = ("MOD-10 (warp-cloth) and MOD-11 (warp-cloth-mask) are absent "
             "(paths.warp_cloth=null in config). L_warp_pt and L_warp_m will "
             "return 0.0 tensors. Training proceeds normally.")
      self.info.append(msg)
      return CheckResult('PASS', msg)
    # If paths configured but folders don't exist → check and warn

═══════════════════════════════════════════════════════════════════════════════════
SECTION 7 — CONFIGURATION FILE (configs/default.yaml)
═══════════════════════════════════════════════════════════════════════════════════

project:
  name: "vitonhd_tryon_v1"
  version: "1.1.0"
  seed: 42

data:
  data_root: "./viton_hd"
  batch_size: 4
  num_workers: 8
  pin_memory: true
  apply_menswear_filter: true
  densepose_min_coverage: 0.15

  # ACTUAL FOLDER NAMES — sourced from your verified VITON-HD structure
  # ALL code uses cfg.data.paths.{key} — nothing hardcoded
  paths:
    image:         "image"                       # MOD-1  RGB JPG
    parse:         "image-parse-v3"              # MOD-2  LIP-20 palette PNG
    openpose_img:  "openpose_img"                # MOD-3  ← UNDERSCORE (critical)
    openpose_json: "openpose_json"               # MOD-4  ← UNDERSCORE (critical)
    cloth:         "cloth"                       # MOD-5  RGB JPG
    cloth_mask:    "cloth-mask"                  # MOD-6  binary PNG
    agnostic:      "agnostic-v3.2"               # MOD-7  RGB PNG
    agnostic_mask: "image-parse-agnostic-v3.2"  # MOD-8  palette PNG → binarize
    densepose:     "image-densepose"             # MOD-9  IUV PNG
    warp_cloth:    null                          # MOD-10 ABSENT — graceful None
    warp_cloth_mask: null                        # MOD-11 ABSENT — graceful None

model:
  unified_parse_classes: 25
  active_garment_classes: [5]
  
  body_encoder:
    backbone: "swinv2_small_window8_256"
    pretrained: true

  garment_extractor:
    backbone: "convnext_tiny"
    pretrained: true

  warping:
    num_parts: 5
    tps_control_points: 25
    tps_reg_lambda: 1.0e-5
    correlation_max_displacement: 8   # reduce to 6 if OOM

  ip_adapter:
    clip_model: "openai/clip-vit-large-patch14"
    num_tokens: 16
    unet_dim: 768
    cfg_dropout: 0.1
    ip_scale_init: 0.1
    ip_scale_max: 3.0

  parse_embedder:
    vocab_size: 25
    embed_dim: 64
    output_channels: 3

  diffusion:
    base_model: "runwayml/stable-diffusion-inpainting"
    unet_in_channels: 17
    vae_scaling_factor: 0.18215
    num_inference_steps: 50
    guidance_scale: 2.5
    ema_decay: 0.9999
    ema_update_every: 10
    ema_scope: "all"
    snr_gamma: 5.0
    warp_warmup_epochs: 2

  compositor:
    in_channels: 7
    hidden_channels: 32

training:
  max_epochs: 150
  optimizer: "AdamW"
  lr_warp: 1.0e-4
  lr_diffusion: 5.0e-5
  lr_body_encoder: 5.0e-5
  lr_garment_extractor: 5.0e-5
  lr_ip_adapter: 1.0e-4
  lr_parse_embedder: 1.0e-4
  lr_compositor: 1.0e-4
  lr_garment_adapter: 1.0e-4
  weight_decay: 1.0e-2
  grad_clip_warp: 1.0
  grad_clip_diffusion: 1.0
  grad_clip_body_encoder: 2.0
  grad_clip_global: 5.0
  scheduler: "cosine_with_warmup"
  warmup_steps: 500
  accumulate_grad_batches: 4
  val_check_interval: 0.5
  num_val_inference_steps: 50
  log_images_every_n_val_steps: 5
  save_top_k: 5
  monitor_metric: "val/lpips"
  monitor_mode: "min"

hardware:
  precision: "bf16-mixed"
  accelerator: "gpu"
  devices: 1
  compile: false
  xformers: true

logging:
  log_dir: "./logs"
  checkpoint_dir: "./checkpoints"
  tensorboard: true
  num_images_to_log: 8

═══════════════════════════════════════════════════════════════════════════════════
SECTION 8 — TRAINING SYSTEM (LightningModule Key Sections)
═══════════════════════════════════════════════════════════════════════════════════

## Warp Warm-Up Implementation (training/lightning_module.py)

class VirtualTryOnLightningModule(LightningModule):
  
  def __init__(self, cfg):
    self.model = VirtualTryOnSystem(cfg)  # imports from models/tryon_system.py
    self.cfg   = cfg
    self._warmup_done = False
    
    # EMA: ALL trainable params (not just UNet)
    self.ema = ExponentialMovingAverage(
        [p for p in self.model.parameters() if p.requires_grad],
        decay=cfg.model.diffusion.ema_decay
    )
    
    self.perceptual_loss = VGGPerceptualLoss()
    self.lpips_fn = lpips.LPIPS(net='vgg')
    self.ssim_fn  = StructuralSimilarityIndexMeasure(data_range=2.0)
  
  def on_train_epoch_start(self):
    epoch = self.current_epoch
    
    if epoch < self.cfg.model.diffusion.warp_warmup_epochs:
      if not self._warmup_done:
        self._freeze_for_warp_warmup()
    
    elif not self._warmup_done:
      self._unfreeze_all()
      self._warmup_done = True
      self.print(f"[Epoch {epoch}] Warp warm-up complete. Full joint training begins.")
    
    # Log loss weights for current epoch
    weights = get_loss_weights(epoch)
    for k, v in weights.items():
      self.log(f"loss_weights/{k}", float(v))
  
  def _freeze_for_warp_warmup(self):
    """
    Epochs 0-1: Only warping module and UNet conv_in new channels train.
    All other parameters frozen.
    """
    for name, param in self.model.named_parameters():
      if 'warping' in name or 'garment_adapter' in name:
        param.requires_grad = True
      elif 'unet.conv_in.weight' in name:
        param.requires_grad = True
        # Gradient hook: zero pretrained channels 0-8
        param.register_hook(lambda g: torch.cat([
            torch.zeros_like(g[:, :9]),  # channels 0-8: frozen (pretrained)
            g[:, 9:]                      # channels 9-16: train (new)
        ], dim=1))
      else:
        param.requires_grad = False
  
  def _unfreeze_all(self):
    """Remove all freezing. From epoch 2: full joint training forever."""
    for param in self.model.parameters():
      param.requires_grad = True
    # Clear all backward hooks (gradient masks from warm-up)
    for module in self.model.modules():
      if hasattr(module, '_backward_hooks'):
        module._backward_hooks.clear()
    # Reconstruct EMA with all parameters now that they're all trainable
    self.ema = ExponentialMovingAverage(
        [p for p in self.model.parameters() if p.requires_grad],
        decay=self.cfg.model.diffusion.ema_decay
    )
  
  def training_step(self, batch, batch_idx):
    B = batch['person_image'].shape[0]
    t = torch.randint(0, 1000, (B,), device=self.device)
    
    outputs = self.model(batch, t)
    weights = get_loss_weights(self.current_epoch)
    losses  = self._compute_all_losses(outputs, batch, weights)
    
    for k, v in losses.items():
      self.log(f"train/{k}", v, on_step=True, on_epoch=True,
               prog_bar=(k == 'total'), sync_dist=True)
    
    # Monitor ip_scale every 100 steps
    if batch_idx % 100 == 0:
      self.log("model/ip_scale", self.model.ip_adapter.ip_scale.item())
    
    # Monitor warp convergence at epoch 10
    if self.current_epoch == 10 and batch_idx == 0:
      std = outputs['deformation_field'].std().item()
      if std < 0.01:
        self.print(f"WARNING: deformation_field.std()={std:.4f} — warp may not "
                   "be learning. Consider reducing lr_diffusion.")
    
    return losses['total']
  
  def _compute_all_losses(self, outputs, batch, weights) -> dict:
    losses = {}
    
    # Primary: SNR-weighted denoising
    losses['denoise'] = compute_denoise_loss(
        outputs['eps_pred'], outputs['eps_target'], outputs['timesteps'],
        self.model.unet.noise_scheduler, snr_gamma=self.cfg.model.diffusion.snr_gamma
    )
    
    # Quality on x0 prediction
    losses['x0_perceptual'] = (
        self.perceptual_loss(outputs['x0_pred_image'], batch['person_image'])
        if weights['lambda_x0_perc'] > 0 else torch.tensor(0.0, device=self.device)
    )
    losses['ssim'] = compute_ssim_loss(outputs['x0_pred_image'], batch['person_image'])
    
    # Warp
    losses['warp_smooth']   = compute_tps_smoothness_loss(outputs['deformation_field'])
    losses['warp_mask']     = compute_warp_mask_loss(
        outputs['cloth_mask_warped'],
        batch['warp_cloth_mask']   # None → returns 0.0 tensor
    )
    losses['warp_pretrain'] = compute_warp_pretrain_loss(
        outputs['cloth_warped'],
        batch['warp_cloth'],       # None → returns 0.0 tensor
        batch['warp_cloth_mask']   # None → returns 0.0 tensor
    )
    
    # Identity penalty (decays with epoch via weight schedule)
    losses['identity'] = compute_identity_penalty_loss(
        outputs['ctrl_pts_src'], outputs['ctrl_pts_tgt']
    )
    
    # Part segmentation pseudo-supervision
    losses['part_seg'] = compute_part_segmentation_loss(
        outputs['part_masks_full'], batch['parse_unified25']
    )
    
    # Compositor boundary loss
    losses['compositor'] = compute_compositor_loss(
        outputs['alpha_logit'], batch['agnostic_mask']
    )
    
    losses['total'] = (
        weights['lambda_denoise']  * losses['denoise'] +
        weights['lambda_x0_perc'] * losses['x0_perceptual'] +
        weights['lambda_ssim']    * losses['ssim'] +
        weights['lambda_warp_s']  * losses['warp_smooth'] +
        weights['lambda_warp_m']  * losses['warp_mask'] +     # × 0.0 (MOD-11 absent)
        weights['lambda_warp_pt'] * losses['warp_pretrain'] + # × 0.0 (MOD-10 absent)
        weights['lambda_identity']* losses['identity'] +
        weights['lambda_part_seg']* losses['part_seg'] +
        weights['lambda_comp']    * losses['compositor']
    )
    
    return losses
  
  def on_train_batch_end(self, outputs, batch, batch_idx):
    if batch_idx % self.cfg.model.diffusion.ema_update_every == 0:
      self.ema.update()
  
  def validation_step(self, batch, batch_idx):
    with self.ema.average_parameters():
      I_final = self.model.generate(batch, num_steps=self.cfg.training.num_val_inference_steps)
    I_n = (I_final + 1) / 2
    target_n = (batch['person_image'] + 1) / 2
    self.log('val/lpips', self.lpips_fn(I_final, batch['person_image']).mean())
    self.log('val/ssim', self.ssim_fn(I_n, target_n))
    if batch_idx < self.cfg.logging.num_images_to_log:
      self._log_image_grid(batch, I_final, batch_idx)
  
  def configure_optimizers(self):
    # 8 separate param groups with per-module LRs
    param_groups = [
      {'params': list(self.model.warping.parameters()),           'lr': self.cfg.training.lr_warp,             'name': 'warp'},
      {'params': list(self.model.unet.parameters()),              'lr': self.cfg.training.lr_diffusion,        'name': 'diffusion'},
      {'params': list(self.model.body_encoder.parameters()),      'lr': self.cfg.training.lr_body_encoder,     'name': 'body_enc'},
      {'params': list(self.model.garment_extractor.parameters()), 'lr': self.cfg.training.lr_garment_extractor,'name': 'garment_ext'},
      {'params': list(self.model.ip_adapter.image_proj.parameters()) +
                 list(self.model.ip_adapter.ip_to_k.parameters()) +
                 list(self.model.ip_adapter.ip_to_v.parameters()),
                                                                  'lr': self.cfg.training.lr_ip_adapter,       'name': 'ip_adapter'},
      {'params': list(self.model.parse_embedder.parameters()),    'lr': self.cfg.training.lr_parse_embedder,   'name': 'parse_emb'},
      {'params': list(self.model.compositor.parameters()),        'lr': self.cfg.training.lr_compositor,       'name': 'compositor'},
      {'params': list(self.model.garment_adapter.parameters()),   'lr': self.cfg.training.lr_garment_adapter,  'name': 'garment_adp'},
    ]
    optimizer = torch.optim.AdamW(param_groups, weight_decay=self.cfg.training.weight_decay)
    scheduler = get_cosine_schedule_with_warmup(
        optimizer, num_warmup_steps=self.cfg.training.warmup_steps,
        num_training_steps=self._estimate_total_steps()
    )
    return {'optimizer': optimizer, 'lr_scheduler': {'scheduler': scheduler, 'interval': 'step'}}

═══════════════════════════════════════════════════════════════════════════════════
SECTION 9 — INTEGRATION VERIFICATION MATRIX
═══════════════════════════════════════════════════════════════════════════════════

This matrix verifies that every dataset-path-sensitive code location uses
consistent names. Claude MUST cross-check each cell before generating each file.

## 9.1 Path Propagation Verification

| Dataset Path       | Actual Folder          | Config Key          | Files That Use It                          | Correct? |
|--------------------|------------------------|---------------------|--------------------------------------------|----------|
| MOD-1 person       | image/                 | paths.image         | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-2 parse        | image-parse-v3/        | paths.parse         | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-3 skeleton     | openpose_img/          | paths.openpose_img  | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-4 keypoints    | openpose_json/         | paths.openpose_json | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-5 cloth        | cloth/                 | paths.cloth         | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-6 cloth mask   | cloth-mask/            | paths.cloth_mask    | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-7 agnostic img | agnostic-v3.2/         | paths.agnostic      | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-8 agn parse    | image-parse-agnostic-v3.2/ | paths.agnostic_mask | dataset_vitonhd.py, validators.py     | VERIFY   |
| MOD-9 densepose    | image-densepose/       | paths.densepose     | dataset_vitonhd.py, validators.py          | VERIFY   |
| MOD-10 warp-cloth  | ABSENT                 | paths.warp_cloth=null | dataset_vitonhd.py, validators.py, losses | VERIFY   |
| MOD-11 warp-mask   | ABSENT                 | paths.warp_cloth_mask=null | same                              | VERIFY   |

## 9.2 MOD-8 Binarization Propagation

MOD-8 is loaded as a palette PNG from image-parse-agnostic-v3.2/ and binarized.
The SAME binary mask flows through to:

| Destination            | File                  | Key in batch dict    | Expected dtype/range |
|------------------------|-----------------------|----------------------|----------------------|
| BodyConditionEncoder   | models/body_encoder.py| batch['agnostic_mask']| [B,1,1024,768] f32 {0,1} |
| Branch-A concat input  | body_encoder.py       | channel concat        | joined with agnostic_image |
| UNet ch 8 (downsample) | models/tryon_system.py| agnostic_mask_ds      | [B,1,128,96] f32 {0,1} via bilinear |
| RegionCompositor       | models/compositor.py  | agnostic_mask         | [B,1,1024,768] hard prior |
| L_comp supervision     | losses/warp_losses.py | agnostic_mask         | softened version |

VERIFICATION RULE: If agnostic_mask has values other than {0.0, 1.0}
  (before compositing), it means binarization failed. Assert in dataset:
    assert set(agnostic_mask.unique().tolist()).issubset({0.0, 1.0}), \
        "agnostic_mask must be binary after binarize_agnostic_parse"

## 9.3 None-Handling Propagation for MOD-10/11

MOD-10/11 are always None. Verify None handling in each consumer:

| Code Location                              | None Check Method           | Returns     |
|--------------------------------------------|-----------------------------|-------------|
| dataset_vitonhd.py __getitem__             | hardcoded None              | batch key=None |
| tryon_system.py forward() output dict      | batch.get('warp_cloth',None)| None in outputs |
| losses/warp_losses.py compute_warp_pretrain| if warp_cloth_gt is None    | 0.0 tensor  |
| losses/warp_losses.py compute_warp_mask    | if warp_mask_gt is None     | 0.0 tensor  |
| training/lightning_module.py               | passes None to loss fns     | 0.0 scalar  |
| DataLoader collate_fn                      | custom collate handles None | None stays None |

CRITICAL: The DataLoader default collate_fn will CRASH if batch items are None.
          Implement a custom collate function in data/datamodule.py:

def custom_collate_fn(batch: list) -> dict:
    """Handle None values for absent optional modalities (MOD-10, MOD-11)."""
    out = {}
    for key in batch[0].keys():
        vals = [b[key] for b in batch]
        if all(v is None for v in vals):
            out[key] = None                       # All None → keep None
        elif any(v is None for v in vals):
            # Partial None — treat all as None (optional modality partially missing)
            out[key] = None
        elif isinstance(vals[0], torch.Tensor):
            out[key] = torch.stack(vals, dim=0)  # Normal stack
        elif isinstance(vals[0], str):
            out[key] = vals                       # Keep as list of strings
        else:
            out[key] = torch.tensor(vals)
    return out

This custom_collate_fn MUST be passed to both train and val DataLoaders:
  DataLoader(dataset, collate_fn=custom_collate_fn, ...)

## 9.4 cloth_image vs cloth_image_raw Routing

Two versions of the cloth image exist. Routing MUST be correct in every file:

| Signal           | Source       | Goes To                         | Why                          |
|------------------|--------------|---------------------------------|------------------------------|
| cloth_image_raw  | Unaugmented  | models/ip_adapter.py CLIP       | CLIP needs clean, unaugmented |
| cloth_image      | Augmented    | models/garment_extractor.py     | Extractor learns augmentation-invariant |
| cloth_image      | Augmented    | models/warping.py (warp input)  | Warp cloth with augmented version |
| cloth_image_raw  | Unaugmented  | Notebook visualization cells    | Show original garment         |

In models/tryon_system.py forward(), explicitly separate:
  ip_keys, ip_values, ip_scale = self.ip_adapter(batch['cloth_image_raw'])  # RAW
  garment_features = self.garment_extractor(batch['cloth_image'], ...)       # AUGMENTED

## 9.5 VirtualTryOnSystem.forward() Output Dict (Full Spec)

The following keys MUST be present in outputs dict for loss computation:

  Required keys (always present):
    'eps_pred'          [B,4,128,96]   noise prediction from UNet
    'eps_target'        [B,4,128,96]   ground-truth noise
    'timesteps'         [B]            diffusion timesteps
    'x0_pred_image'     [B,3,1024,768] decoded x0 prediction (for perceptual/SSIM)
    'cloth_warped'      [B,3,1024,768]
    'cloth_mask_warped' [B,1,1024,768]
    'deformation_field' [B,2,128,96]
    'part_masks_full'   [B,5,1024,768]
    'ctrl_pts_src'      [B,5,25,2]     for identity penalty loss
    'ctrl_pts_tgt'      [B,5,25,2]     for identity penalty loss
    'alpha_logit'       [B,1,1024,768] raw compositor output (for L_comp)
    'I_final'           [B,3,1024,768] final composed image
  
  Optional keys (may be None when MOD-10/11 absent):
    'cloth_warped_target' None (batch['warp_cloth'] is None)
    'warp_mask_target'    None (batch['warp_cloth_mask'] is None)

═══════════════════════════════════════════════════════════════════════════════════
SECTION 10 — TEST SUITE SPECIFICATION
═══════════════════════════════════════════════════════════════════════════════════

### tests/test_dataset.py (12 tests)

  test_1_directory_structure_valid
    VITONHDValidator check #1 passes with actual folder names from cfg

  test_2_all_output_keys_present
    Load 1 sample, assert all required keys in output dict

  test_3_all_output_shapes_correct
    Assert each tensor shape matches Section 2.3 spec table

  test_4_parse_u25_values_in_range
    Assert parse_unified25.max() < 25, .min() >= 0, dtype=int64

  test_5_class5_pixel_count_preserved_after_remap
    raw5  = (parse_lip20 == 5).sum()
    map5  = (parse_unified25 == 5).sum()
    assert raw5 == map5  ← MUST PASS EXACTLY

  test_6_agnostic_mask_is_binary
    vals = batch['agnostic_mask'].unique().tolist()
    assert set(vals).issubset({0.0, 1.0})

  test_7_agnostic_mask_from_parse_not_agnostic_image
    # Verify binarization: agnostic_mask is derived from image-parse-agnostic-v3.2/
    # NOT from agnostic-v3.2/ (the RGB image)
    # Check: agnostic_mask is binary (RGB image would never be binary)

  test_8_warp_cloth_is_none
    assert batch['warp_cloth'] is None         # MOD-10 absent
    assert batch['warp_cloth_mask'] is None    # MOD-11 absent

  test_9_cloth_image_raw_is_unaugmented
    # Load same sample twice with training augmentation
    s1 = dataset[0]; s2 = dataset[0]
    # cloth_image may differ (augmented); cloth_image_raw must be deterministic
    assert torch.allclose(s1['cloth_image_raw'], s2['cloth_image_raw'])

  test_10_openpose_underscore_folder_loaded
    # Verify openpose data comes from openpose_img/ not openpose-img/
    assert (Path(cfg.data.data_root) / 'train' / 'openpose_img').exists()
    assert openpose_img.shape == (3, 1024, 768)

  test_11_menswear_filter_reduces_dataset
    full_len   = len(VITONHDDataset(cfg_no_filter, split='train'))
    filter_len = len(VITONHDDataset(cfg_filter,    split='train'))
    assert filter_len <= full_len

  test_12_custom_collate_handles_none
    batch = [dataset[i] for i in range(4)]
    collated = custom_collate_fn(batch)
    assert collated['warp_cloth'] is None      # Must not crash
    assert collated['warp_cloth_mask'] is None

### tests/test_model_shapes.py (10 tests)
  test_1_full_forward_pass_shapes (B=2 synthetic batch)
  test_2_body_encoder_outputs
  test_3_garment_extractor_outputs
  test_4_warping_module_outputs
  test_5_tps_identity_at_init (ctrl_pts_src == ctrl_pts_tgt → near-identity warp)
  test_6_ip_adapter_outputs
  test_7_parse_embedder_output
  test_8_17ch_unet_input_composition
  test_9_densepose_confidence_weighting (coverage=0 → F_dense_8 all zeros)
  test_10_compositor_alpha_hard_prior (alpha zero outside agnostic_mask)

### tests/test_training_step.py (10 tests)
  test_1_training_step_finite_loss
  test_2_all_loss_components_finite
  test_3_warp_pretrain_is_zero (MOD-10 absent → 0.0 exactly)
  test_4_warp_mask_is_zero (MOD-11 absent → 0.0 exactly)
  test_5_gradients_computed_for_trainable_params
  test_6_frozen_params_have_no_gradient (epoch < warmup_epochs)
  test_7_ema_updates_without_error
  test_8_loss_weights_correct_at_epochs (0, 10, 20, 80, 150)
  test_9_ip_scale_clamped_to_max (manually set ip_scale=5.0, verify clamped)
  test_10_custom_collate_in_dataloader (no crash with None batch items)

═══════════════════════════════════════════════════════════════════════════════════
SECTION 11 — NOTEBOOK SPECIFICATION (20 CELLS)
═══════════════════════════════════════════════════════════════════════════════════

Cell 1:  Environment Check
  torch, diffusers, transformers, timm, lightning versions + GPU info

Cell 2:  Dataset Validation
  VITONHDValidator with cfg — display 10-check pass/fail table
  Verify check #1 shows openpose_img (underscore) and image-parse-agnostic-v3.2

Cell 3:  All 11 Modality Visualization
  Load one training sample
  3×4 subplot (11 images + label noting MOD-10/11 absent)
  Title each: "MOD-N: [folder_name]" using actual folder name from cfg
  Print all tensor shapes, dtypes, value ranges
  Highlight: "agnostic_mask is BINARY (binarized from image-parse-agnostic-v3.2)"

Cell 4:  MOD-8 Binarization Verification
  Load raw palette PNG from image-parse-agnostic-v3.2/
  Show: raw parse array | binarized mask (side by side)
  Print: unique values before (LIP-20 classes) and after (only {0.0, 1.0})
  Assert: class-5 + class-10 regions form the garment area

Cell 5:  MOD-2 Label Mapping Verification (separate from MOD-8)
  Load image-parse-v3/ parse, apply remap_labels
  Side-by-side: LIP-20 colors | UNIFIED-25 colors
  Print: class-5 count before vs after (must be identical)
  Confirm these are TWO SEPARATE operations on TWO SEPARATE files

Cell 6:  Custom Collate Function Test
  Create batch of 4 samples
  Apply custom_collate_fn
  Verify warp_cloth=None, warp_cloth_mask=None → no crash
  Verify all tensor keys stacked correctly

Cell 7:  Model Instantiation & Parameter Count
  VirtualTryOnSystem(cfg) — print per-module params (trainable / frozen)

Cell 8:  Shape Verification (Synthetic B=2 Batch)
  Run forward() with zeros batch
  Assert all output dict shapes per Section 9.5

Cell 9:  Warp Warm-Up Demo
  Show frozen/unfrozen params at epoch 0 vs epoch 2
  Verify conv_in gradient hook zeros channels 0-8

Cell 10: DensePose Coverage Analysis
  500-sample histogram with 0.15 confidence threshold line
  Print: mean, % below threshold

Cell 11: TPS Visualization (Identity → Learned)
  cloth | warped_cloth | deformation_field | 5 part masks
  Print: ctrl_pts displacement stats at epoch 0 (should be ~0)

Cell 12: IP-Scale Monitoring Demo
  Simulate 200 steps, plot ip_scale evolution
  Demonstrate clamp at 3.0

Cell 13: Loss Verification
  All 9 loss components with None MOD-10/11 batch → verify warp_pretrain=0, warp_mask=0
  Print full 150-epoch weight schedule as dataframe

Cell 14: Per-Module Gradient Norms
  One training step + backward
  Print per-param-group gradient norms
  Show PerModuleGradientClipCallback in action

Cell 15: Training Launch
  trainer.fit(module, datamodule)

Cell 16: Training Curves
  Total + all 9 component losses vs epoch
  val/lpips, val/ssim vs epoch
  ip_scale vs steps
  Loss weight schedule overlay

Cell 17: Load Best Checkpoint (EMA weights)
  Verify EMA ≠ live weights

Cell 18: Inference Visualization (8 test pairs)
  3-column: Person | Garment | Try-On Result

Cell 19: Quantitative Metrics
  Full test set: LPIPS, SSIM, FID
  Table vs IDM-VTON benchmarks

Cell 20: Deployment Benchmarks
  Latency at 50/20/10 steps
  Peak GPU memory at inference
  Throughput estimate

═══════════════════════════════════════════════════════════════════════════════════
SECTION 12 — REQUIREMENTS (PINNED)
═══════════════════════════════════════════════════════════════════════════════════

# requirements.txt
torch==2.3.0
torchvision==0.18.0
torchaudio==2.3.0
diffusers==0.27.2
transformers==4.40.2
accelerate==0.30.0
lightning==2.2.5
torchmetrics==1.4.0
timm==1.0.3
lpips==0.1.4
clean-fid==0.1.35
piq==0.8.0
omegaconf==2.3.0
hydra-core==1.3.2
Pillow==10.3.0
numpy==1.26.4
scipy==1.13.0
opencv-python==4.9.0.80
matplotlib==3.8.4
tensorboard==2.17.0
torch_ema==0.3
tqdm==4.66.4
rich==13.7.1
einops==0.8.0

═══════════════════════════════════════════════════════════════════════════════════
SECTION 13 — MEMORY BUDGET (A100 80GB)
═══════════════════════════════════════════════════════════════════════════════════

Module                              | VRAM (Train B=4, BF16)
------------------------------------|------------------------
Frozen VAE (FP16, no_grad)          |  1.2 GB
Frozen CLIP (FP16, no_grad)         |  0.9 GB
SwinV2-Small body encoder           |  2.1 GB
ConvNeXt-Tiny garment extractor     |  1.4 GB
TPS + warping modules               |  0.3 GB
Correlation volume (BF16)           |  0.3 GB  (halved vs FP32)
GarmentLatentAdapter                |  0.1 GB
ParseMapEmbedder                    |  0.1 GB
IP-Adapter projection               |  0.2 GB
SD 1.5 UNet (17-ch)                 |  6.5 GB
RegionCompositor                    |  0.3 GB
Activations (BF16, B=4)             |  7.5 GB
Gradients                           |  8.5 GB
AdamW optimizer states              |  6.0 GB
EMA shadow (ALL trainable params)   |  3.0 GB
──────────────────────────────────────────────
TOTAL (estimated peak)              | ~38.4 GB  ← within 80 GB

═══════════════════════════════════════════════════════════════════════════════════
SECTION 14 — FILE GENERATION ORDER (37 FILES)
═══════════════════════════════════════════════════════════════════════════════════

Generate ALL files in order. Complete each fully before starting the next.

BATCH 1 — Foundation:
  [FILE-01] configs/default.yaml         ← MUST have paths section with actual names
  [FILE-02] configs/constants.py         ← UNIFIED25, LIP20_TO_UNIFIED25, FLIP_PAIRS
  [FILE-30] utils/__init__.py
  [FILE-31] utils/label_mapper.py        ← remap_labels + binarize_agnostic_parse
  [FILE-32] utils/visualization.py

BATCH 2 — Data:
  [FILE-03] data/__init__.py
  [FILE-04] data/dataset_vitonhd.py      ← all actual folder names via cfg.data.paths
  [FILE-05] data/datamodule.py           ← custom_collate_fn (handles None)
  [FILE-06] data/validators.py           ← checks use cfg.data.paths (no hardcoded names)

BATCH 3 — Models (dependency order):
  [FILE-08] models/tps.py
  [FILE-13] models/parse_embedder.py
  [FILE-12] models/garment_adapter.py
  [FILE-09] models/body_encoder.py
  [FILE-10] models/garment_extractor.py
  [FILE-11] models/warping.py
  [FILE-14] models/ip_adapter.py
  [FILE-15] models/diffusion_unet.py
  [FILE-16] models/compositor.py
  [FILE-17] models/tryon_system.py       ← routes cloth_image_raw to CLIP
  [FILE-07] models/__init__.py

BATCH 4 — Losses:
  [FILE-19] losses/diffusion_loss.py
  [FILE-20] losses/perceptual.py
  [FILE-21] losses/ssim_loss.py
  [FILE-22] losses/warp_losses.py        ← None-safe compute_warp_pretrain_loss etc.
  [FILE-18] losses/__init__.py

BATCH 5 — Training:
  [FILE-27] training/ema.py
  [FILE-26] training/callbacks.py        ← PerModuleGradientClipCallback
  [FILE-24] training/lightning_module.py ← warm-up, EMA all params, None-safe losses
  [FILE-25] training/trainer_setup.py
  [FILE-23] training/__init__.py

BATCH 6 — Inference + Tests + Entry:
  [FILE-29] inference/infer.py
  [FILE-28] inference/__init__.py
  [FILE-33] tests/test_dataset.py        ← 12 tests incl. None/binarize/collate
  [FILE-34] tests/test_model_shapes.py   ← 10 tests
  [FILE-35] tests/test_training_step.py  ← 10 tests
  [FILE-36] train.py

BATCH 7 — Notebook:
  [FILE-37] VirtualTryOn_Notebook.ipynb  ← 20 cells, all executable

═══════════════════════════════════════════════════════════════════════════════════
SECTION 15 — CRITICAL SELF-CHECK BEFORE EACH FILE
═══════════════════════════════════════════════════════════════════════════════════

Before writing each file, answer these questions internally:

For data/dataset_vitonhd.py:
  □ Do I use cfg.data.paths.openpose_img (not "openpose-img")?
  □ Do I load MOD-8 from cfg.data.paths.agnostic_mask and binarize it?
  □ Do I store warp_cloth=None and warp_cloth_mask=None?
  □ Do I store cloth_image_raw (unaugmented) separately from cloth_image?
  □ Do I apply flip to keypoint_coords using OPENPOSE_FLIP_PAIRS?

For data/validators.py:
  □ Do I build REQUIRED_SUBDIRS from cfg.data.paths (not hardcoded)?
  □ Does check #9 note MOD-10/11 absent as expected (INFO, not FAIL)?
  □ Does check #5 verify both MOD-2 remap AND MOD-8 binarization?

For models/tryon_system.py:
  □ Do I pass batch['cloth_image_raw'] to ip_adapter?
  □ Do I pass batch['cloth_image'] (augmented) to garment_extractor?
  □ Does my output dict include all keys in Section 9.5?
  □ Do I handle batch['warp_cloth'] being None without crashing?

For data/datamodule.py:
  □ Is custom_collate_fn passed to BOTH train and val DataLoaders?
  □ Does custom_collate_fn handle None without crashing?
  □ Does it correctly stack all tensor keys while keeping None as None?

For losses/warp_losses.py:
  □ Does compute_warp_pretrain_loss return torch.tensor(0.0, device=...) when None?
  □ Does compute_warp_mask_loss return torch.tensor(0.0, device=...) when None?
  □ Are these 0.0 TENSORS (not Python float 0) with correct device?

For configs/default.yaml:
  □ Is paths.openpose_img = "openpose_img" (underscore)?
  □ Is paths.agnostic_mask = "image-parse-agnostic-v3.2"?
  □ Is paths.warp_cloth = null (not a folder name)?
  □ Is paths.warp_cloth_mask = null?

═══════════════════════════════════════════════════════════════════════════════════
SECTION 16 — THE FINAL MANDATE
═══════════════════════════════════════════════════════════════════════════════════

Every line of code you write must run on the first attempt.

This means:
  - All imports at top of every file — no circular imports
  - All config keys referenced in code exist in configs/default.yaml exactly
  - All file paths accessed via cfg.data.paths.{key} — never hardcoded
  - All tensor shape assertions in every forward() method
  - custom_collate_fn prevents DataLoader crash on None values
  - requirements.txt versions mutually compatible
  - Notebook cells run sequentially without manual intervention

When uncertain: implement the simpler, more conservative version.
A working simple system beats a broken complex one.

Integration completeness oath:
  I verify that the dataset structure modifications are reflected in:
  ✓ configs/default.yaml             (paths section with actual names)
  ✓ data/dataset_vitonhd.py         (all paths from cfg.data.paths)
  ✓ data/datamodule.py              (custom_collate_fn for None)
  ✓ data/validators.py              (REQUIRED_SUBDIRS from cfg)
  ✓ models/tryon_system.py          (cloth_image_raw routing)
  ✓ losses/warp_losses.py           (None-safe return 0.0 tensor)
  ✓ training/lightning_module.py    (passes None to None-safe losses)
  ✓ tests/test_dataset.py           (12 tests including None/binary/collate)
  ✓ VirtualTryOn_Notebook.ipynb     (cells 3-6 verify actual folder names)

CONTINUATION PROTOCOL:
  "=== CONTINUE: {filename} line {line_number} ===" → resume exactly there
  "=== NEXT: {filename} ===" → between files, list completed files

═══════════════════════════════════════════════════════════════════════════════════

BEGIN GENERATION NOW. Start with [FILE-01] configs/default.yaml.
```
