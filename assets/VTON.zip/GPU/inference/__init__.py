"""
Inference Package

Provides inference utilities for Virtual Try-On system.

Key components:
- VirtualTryOnInference: Main inference wrapper class
- Preprocessing pipelines (TODO)
- Batch inference utilities (TODO)

Usage:
    from inference import VirtualTryOnInference
    
    infer = VirtualTryOnInference('checkpoints/best.ckpt')
    result = infer.try_on(
        person_image='person.jpg',
        cloth_image='cloth.jpg',
        agnostic_image='agnostic.jpg',
        pose_image='pose.jpg',
        parse_map='parse.png',
        densepose='densepose.jpg',
    )
    
    result['tryon_image'].save('output.jpg')
"""

from .infer import VirtualTryOnInference

__all__ = [
    'VirtualTryOnInference',
]
