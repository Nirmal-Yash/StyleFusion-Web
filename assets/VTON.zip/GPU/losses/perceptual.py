"""
Perceptual Loss - VGG-19 Features

Computes perceptual loss using VGG-19 features.
Uses LPIPS (Learned Perceptual Image Patch Similarity) metric.

LPIPS is better than raw VGG features as it's learned to match human perception.

Reference: "The Unreasonable Effectiveness of Deep Features as a Perceptual Metric" (Zhang et al., 2018)
"""

import torch
import torch.nn as nn
import lpips


class PerceptualLoss(nn.Module):
    """
    Perceptual loss using LPIPS.
    
    Compares high-level features between predicted and target images.
    Works on RGB images in [0, 1] or [-1, 1] range.
    """
    
    def __init__(self, net_type: str = 'vgg', spatial: bool = False):
        """
        Args:
            net_type: 'vgg', 'alex', or 'squeeze' backbone
            spatial: if True, returns spatial map; if False, returns scalar
        """
        super().__init__()
        
        # Initialize LPIPS network
        self.lpips_net = lpips.LPIPS(net=net_type, spatial=spatial)
        
        # Freeze parameters
        for param in self.lpips_net.parameters():
            param.requires_grad = False
        
        self.lpips_net.eval()
    
    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Compute perceptual loss.
        
        Args:
            pred: [B, 3, H, W] predicted image in [0, 1]
            target: [B, 3, H, W] target image in [0, 1]
        
        Returns:
            loss: scalar tensor (mean over batch)
        """
        assert pred.shape == target.shape
        assert pred.shape[1] == 3, "Expected RGB images"
        
        # LPIPS expects inputs in [-1, 1]
        if pred.min() >= 0.0:
            pred = pred * 2.0 - 1.0
        if target.min() >= 0.0:
            target = target * 2.0 - 1.0
        
        # Compute LPIPS
        with torch.cuda.amp.autocast(enabled=False):
            loss = self.lpips_net(pred.float(), target.float())
        
        # Mean over batch
        loss = loss.mean()
        
        return loss


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_perceptual_loss():
    """Test perceptual loss with synthetic inputs."""
    print("Testing perceptual loss...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create loss module
    loss_fn = PerceptualLoss(net_type='alex').to(device)  # alex is faster than vgg
    
    print(f"LPIPS parameters: {sum(p.numel() for p in loss_fn.parameters()) / 1e6:.2f}M")
    
    # Test Case 1: Identical images (loss should be ~0)
    print("\nTest Case 1: Identical images")
    img = torch.rand(B, 3, 256, 256).to(device)
    
    with torch.no_grad():
        loss_identical = loss_fn(img, img)
    
    print(f"  Loss (identical): {loss_identical.item():.6f}")
    assert loss_identical.item() < 0.01, "Loss should be near 0 for identical images"
    
    # Test Case 2: Different images (loss should be > 0)
    print("\nTest Case 2: Different images")
    img1 = torch.rand(B, 3, 256, 256).to(device)
    img2 = torch.rand(B, 3, 256, 256).to(device)
    
    with torch.no_grad():
        loss_different = loss_fn(img1, img2)
    
    print(f"  Loss (different): {loss_different.item():.6f}")
    assert loss_different.item() > 0.0, "Loss should be positive for different images"
    
    # Test Case 3: Full resolution
    print("\nTest Case 3: Full resolution (1024x768)")
    img_full1 = torch.rand(B, 3, 1024, 768).to(device)
    img_full2 = torch.rand(B, 3, 1024, 768).to(device)
    
    with torch.no_grad():
        loss_full = loss_fn(img_full1, img_full2)
    
    print(f"  Loss (full res): {loss_full.item():.6f}")
    
    print("\n✅ Perceptual loss test passed!")


if __name__ == '__main__':
    test_perceptual_loss()
