"""
Warp Losses - None-Safe Implementation

CRITICAL: These losses must handle None values for MOD-10/11 gracefully.
When warp_cloth_gt or warp_mask_gt is None, returns torch.tensor(0.0).

Losses:
1. L_warp_pt: Pretrain warp loss (L1 + perceptual on warped vs GT cloth)
2. L_warp_m: Warp mask loss (BCE on warped mask vs GT mask)
3. L_identity: TPS identity penalty (L2 displacement from identity grid)

Returns:
- torch.tensor(0.0, requires_grad=False) when GT is None
- Computed loss tensor when GT is available

This ensures training continues smoothly even when MOD-10/11 are absent.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional
import lpips


def compute_warp_pretrain_loss(
    cloth_warped: torch.Tensor,
    warp_cloth_gt: Optional[torch.Tensor],
    warp_mask_gt: Optional[torch.Tensor],
    perceptual_net: Optional[nn.Module] = None,
    l1_weight: float = 1.0,
    perceptual_weight: float = 0.1,
) -> torch.Tensor:
    """
    Warp pretrain loss: L1 + perceptual between warped cloth and GT.
    
    CRITICAL: Returns torch.tensor(0.0) if warp_cloth_gt is None.
    
    Args:
        cloth_warped: [B, 3, 1024, 768] predicted warped garment
        warp_cloth_gt: [B, 3, 1024, 768] ground truth warped garment OR None
        warp_mask_gt: [B, 1, 1024, 768] ground truth warp mask OR None
        perceptual_net: LPIPS network (optional)
        l1_weight: weight for L1 loss
        perceptual_weight: weight for perceptual loss
    
    Returns:
        loss: scalar tensor (0.0 if GT is None, else computed loss)
    """
    # CRITICAL: Handle None case
    if warp_cloth_gt is None:
        return torch.tensor(0.0, device=cloth_warped.device, requires_grad=False)
    
    # Ensure shapes match
    assert cloth_warped.shape == warp_cloth_gt.shape, \
        f"Shape mismatch: {cloth_warped.shape} vs {warp_cloth_gt.shape}"
    
    # L1 loss (masked if mask is provided)
    if warp_mask_gt is not None:
        # Only compute loss in valid regions
        l1_loss = F.l1_loss(cloth_warped * warp_mask_gt, warp_cloth_gt * warp_mask_gt, reduction='sum')
        num_valid = warp_mask_gt.sum() * 3  # 3 channels
        l1_loss = l1_loss / (num_valid + 1e-6)
    else:
        l1_loss = F.l1_loss(cloth_warped, warp_cloth_gt, reduction='mean')
    
    # Perceptual loss (if network provided)
    perceptual_loss = 0.0
    if perceptual_net is not None:
        # LPIPS expects inputs in [-1, 1]
        cloth_warped_norm = cloth_warped * 2.0 - 1.0
        warp_cloth_gt_norm = warp_cloth_gt * 2.0 - 1.0
        
        with torch.cuda.amp.autocast(enabled=False):
            perceptual_loss = perceptual_net(
                cloth_warped_norm.float(),
                warp_cloth_gt_norm.float(),
            ).mean()
    
    # Total loss
    total_loss = l1_weight * l1_loss + perceptual_weight * perceptual_loss
    
    return total_loss


def compute_warp_mask_loss(
    cloth_mask_warped: torch.Tensor,
    warp_mask_gt: Optional[torch.Tensor],
) -> torch.Tensor:
    """
    Warp mask loss: BCE between warped mask and GT mask.
    
    CRITICAL: Returns torch.tensor(0.0) if warp_mask_gt is None.
    
    Args:
        cloth_mask_warped: [B, 1, 1024, 768] predicted warped mask
        warp_mask_gt: [B, 1, 1024, 768] ground truth warp mask OR None
    
    Returns:
        loss: scalar tensor (0.0 if GT is None, else BCE loss)
    """
    # CRITICAL: Handle None case
    if warp_mask_gt is None:
        return torch.tensor(0.0, device=cloth_mask_warped.device, requires_grad=False)
    
    # Ensure shapes match
    assert cloth_mask_warped.shape == warp_mask_gt.shape, \
        f"Shape mismatch: {cloth_mask_warped.shape} vs {warp_mask_gt.shape}"
    
    # BCE loss
    bce_loss = F.binary_cross_entropy(cloth_mask_warped, warp_mask_gt, reduction='mean')
    
    return bce_loss


def compute_identity_penalty(
    ctrl_pts_src: torch.Tensor,
    ctrl_pts_tgt: torch.Tensor,
) -> torch.Tensor:
    """
    Identity penalty: encourages TPS to stay close to identity transformation.
    
    Computes L2 distance between source and target control points.
    
    Args:
        ctrl_pts_src: [B, 25, 2] source control points
        ctrl_pts_tgt: [B, 25, 2] target control points
    
    Returns:
        loss: scalar tensor, L2 displacement from identity
    """
    # L2 distance between corresponding points
    displacement = ctrl_pts_tgt - ctrl_pts_src  # [B, 25, 2]
    
    # Mean squared distance
    identity_loss = (displacement ** 2).mean()
    
    return identity_loss


def compute_tps_smoothness_loss(deformation_field: torch.Tensor) -> torch.Tensor:
    """
    Laplacian 2nd-order warp smoothness loss.
    
    Penalizes the discrete Laplacian of the deformation field to
    encourage spatially smooth warping.
    
    Args:
        deformation_field: [B, 2, H, W] predicted deformation/flow field
    
    Returns:
        loss: scalar tensor, mean absolute Laplacian
    """
    # Discrete 2nd-order derivative in x: f(x-1) - 2*f(x) + f(x+1)
    lap_x = deformation_field[:, :, :, :-2] - 2 * deformation_field[:, :, :, 1:-1] + deformation_field[:, :, :, 2:]
    # Discrete 2nd-order derivative in y
    lap_y = deformation_field[:, :, :-2, :] - 2 * deformation_field[:, :, 1:-1, :] + deformation_field[:, :, 2:, :]
    
    return lap_x.abs().mean() + lap_y.abs().mean()


class WarpLossComputer(nn.Module):
    """
    Complete warp loss computation with None-safe handling.
    
    Combines:
        - L_warp_pt: Pretrain warp loss (L1 + perceptual)
        - L_warp_m: Warp mask loss (BCE)
        - L_warp_s: Laplacian 2nd-order warp smoothness
        - L_identity: TPS identity penalty (decayed over epochs)
    
    Automatically handles None values for MOD-10/11 absent data.
    """
    
    def __init__(
        self,
        perceptual_net_type: str = 'alex',
        l1_weight: float = 1.0,
        perceptual_weight: float = 0.1,
    ):
        super().__init__()
        
        self.l1_weight = l1_weight
        self.perceptual_weight = perceptual_weight
        
        # Initialize LPIPS perceptual network
        self.perceptual_net = lpips.LPIPS(net=perceptual_net_type)
        for param in self.perceptual_net.parameters():
            param.requires_grad = False
        self.perceptual_net.eval()
    
    def forward(
        self,
        cloth_warped: torch.Tensor,
        cloth_mask_warped: torch.Tensor,
        ctrl_pts_src: torch.Tensor,
        ctrl_pts_tgt: torch.Tensor,
        warp_cloth_gt: Optional[torch.Tensor],
        warp_mask_gt: Optional[torch.Tensor],
        identity_penalty_weight: float = 0.1,
    ) -> dict:
        """
        Compute all warp losses.
        
        Args:
            cloth_warped: [B, 3, 1024, 768] predicted warped cloth
            cloth_mask_warped: [B, 1, 1024, 768] predicted warped mask
            ctrl_pts_src: [B, 25, 2] TPS source points
            ctrl_pts_tgt: [B, 25, 2] TPS target points
            warp_cloth_gt: [B, 3, 1024, 768] GT warped cloth OR None
            warp_mask_gt: [B, 1, 1024, 768] GT warp mask OR None
            identity_penalty_weight: weight for identity regularization
        
        Returns:
            dict with keys:
                - 'L_warp_pt': pretrain loss (0.0 if None)
                - 'L_warp_m': mask loss (0.0 if None)
                - 'L_identity': identity penalty
                - 'L_warp_total': sum of all warp losses
        """
        # Pretrain warp loss (None-safe)
        L_warp_pt = compute_warp_pretrain_loss(
            cloth_warped=cloth_warped,
            warp_cloth_gt=warp_cloth_gt,
            warp_mask_gt=warp_mask_gt,
            perceptual_net=self.perceptual_net,
            l1_weight=self.l1_weight,
            perceptual_weight=self.perceptual_weight,
        )
        
        # Warp mask loss (None-safe)
        L_warp_m = compute_warp_mask_loss(
            cloth_mask_warped=cloth_mask_warped,
            warp_mask_gt=warp_mask_gt,
        )
        
        # Identity penalty (always computed)
        L_identity = compute_identity_penalty(
            ctrl_pts_src=ctrl_pts_src,
            ctrl_pts_tgt=ctrl_pts_tgt,
        )
        
        # Total warp loss
        L_warp_total = L_warp_pt + L_warp_m + identity_penalty_weight * L_identity
        
        return {
            'L_warp_pt': L_warp_pt,
            'L_warp_m': L_warp_m,
            'L_identity': L_identity,
            'L_warp_total': L_warp_total,
        }


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_warp_losses():
    """Test warp losses with both valid GT and None GT."""
    print("Testing warp losses...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create synthetic inputs
    cloth_warped = torch.rand(B, 3, 1024, 768).to(device)
    cloth_mask_warped = torch.rand(B, 1, 1024, 768).to(device)
    ctrl_pts_src = torch.randn(B, 25, 2).to(device)
    ctrl_pts_tgt = torch.randn(B, 25, 2).to(device)
    
    # Test Case 1: Valid GT (loss should be non-zero)
    print("\nTest Case 1: Valid GT")
    warp_cloth_gt = torch.rand(B, 3, 1024, 768).to(device)
    warp_mask_gt = torch.rand(B, 1, 1024, 768).to(device)
    
    loss_computer = WarpLossComputer().to(device)
    
    with torch.no_grad():
        losses = loss_computer(
            cloth_warped=cloth_warped,
            cloth_mask_warped=cloth_mask_warped,
            ctrl_pts_src=ctrl_pts_src,
            ctrl_pts_tgt=ctrl_pts_tgt,
            warp_cloth_gt=warp_cloth_gt,
            warp_mask_gt=warp_mask_gt,
            identity_penalty_weight=0.1,
        )
    
    print("Losses with valid GT:")
    for key, val in losses.items():
        print(f"  {key}: {val.item():.6f}")
    
    assert losses['L_warp_pt'].item() > 0.0, "Pretrain loss should be > 0 with valid GT"
    assert losses['L_warp_m'].item() > 0.0, "Mask loss should be > 0 with valid GT"
    
    # Test Case 2: None GT (loss should be 0.0)
    print("\nTest Case 2: None GT (MOD-10/11 absent)")
    
    with torch.no_grad():
        losses_none = loss_computer(
            cloth_warped=cloth_warped,
            cloth_mask_warped=cloth_mask_warped,
            ctrl_pts_src=ctrl_pts_src,
            ctrl_pts_tgt=ctrl_pts_tgt,
            warp_cloth_gt=None,  # ABSENT
            warp_mask_gt=None,   # ABSENT
            identity_penalty_weight=0.1,
        )
    
    print("Losses with None GT:")
    for key, val in losses_none.items():
        print(f"  {key}: {val.item():.6f}")
    
    assert losses_none['L_warp_pt'].item() == 0.0, "Pretrain loss should be 0.0 with None GT"
    assert losses_none['L_warp_m'].item() == 0.0, "Mask loss should be 0.0 with None GT"
    assert losses_none['L_identity'].item() > 0.0, "Identity penalty should still be computed"
    
    print("\n✓ None-safe warp losses verified!")
    
    # Test Case 3: Individual functions
    print("\nTest Case 3: Individual functions")
    
    # Pretrain loss with None
    loss_pt_none = compute_warp_pretrain_loss(cloth_warped, None, None)
    assert loss_pt_none.item() == 0.0
    assert not loss_pt_none.requires_grad
    print("✓ compute_warp_pretrain_loss handles None")
    
    # Mask loss with None
    loss_m_none = compute_warp_mask_loss(cloth_mask_warped, None)
    assert loss_m_none.item() == 0.0
    assert not loss_m_none.requires_grad
    print("✓ compute_warp_mask_loss handles None")
    
    # Identity penalty (always computed)
    loss_id = compute_identity_penalty(ctrl_pts_src, ctrl_pts_tgt)
    assert loss_id.item() > 0.0
    print("✓ compute_identity_penalty always computed")
    
    print("\n✅ All warp loss tests passed!")


if __name__ == '__main__':
    test_warp_losses()
