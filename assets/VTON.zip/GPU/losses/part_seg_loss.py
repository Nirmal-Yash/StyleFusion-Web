"""
Part Segmentation Pseudo-Supervision Loss

Soft cross-entropy between predicted 5-part body masks from the warping module
and pseudo ground-truth derived from UNIFIED-25 semantic parse maps.

5 parts: [Torso-front, Left-sleeve, Right-sleeve, Lower-front, Lower-back]

The parse map provides noisy but useful supervision signal to help the
PartSegmenter learn meaningful body-region decomposition for garment warping.
"""

import torch
import torch.nn.functional as F


# UNIFIED-25 label → part index mapping
# Part 0: Torso-front (upper body center)
# Part 1: Left-sleeve (left arm region)
# Part 2: Right-sleeve (right arm region)
# Part 3: Lower-front (lower body)
# Part 4: Lower-back / other (remaining body)
_LABEL_TO_PART = {
    5: 0,   # Upper-Cloth → Torso-front
    10: 0,  # Torso-Skin → Torso-front
    11: 0,  # Coat → Torso-front
    12: 1,  # Left-Arm → Left-sleeve
    13: 2,  # Right-Arm → Right-sleeve
    9: 3,   # Pants-Salwar → Lower-front
    14: 3,  # Left-Leg → Lower-front
    15: 3,  # Right-Leg → Lower-front
    19: 3,  # Skirt → Lower-front
    16: 3,  # Left-Shoe → Lower-front
    17: 3,  # Right-Shoe → Lower-front
    18: 3,  # Socks → Lower-front
    3: 4,   # Face → Lower-back/other
    2: 4,   # Hair → Lower-back/other
    1: 4,   # Hat → Lower-back/other
    4: 4,   # Neck-Scarf → Lower-back/other
    21: 4,  # Gloves → Lower-back/other
}


def compute_part_segmentation_loss(
    part_masks_full: torch.Tensor,
    parse_unified25: torch.Tensor,
) -> torch.Tensor:
    """
    Compute soft pseudo-supervision loss for 5-part body segmentation.

    Args:
        part_masks_full: [B, 5, H, W] predicted soft part masks (logits or probs)
        parse_unified25: [B, H, W] or [B, 1, H, W] int64 UNIFIED-25 labels [0..24]

    Returns:
        loss: scalar tensor, cross-entropy between predicted parts and pseudo GT
    """
    if parse_unified25.dim() == 4:
        parse_unified25 = parse_unified25.squeeze(1)  # [B, H, W]

    B, C, H, W = part_masks_full.shape
    pH, pW = parse_unified25.shape[1], parse_unified25.shape[2]

    # Resize part_masks to parse resolution if they differ
    if (H, W) != (pH, pW):
        part_masks_full = F.interpolate(
            part_masks_full, size=(pH, pW), mode='bilinear', align_corners=False,
        )

    # Build pseudo GT: [B, H, W] long tensor with part indices (0-4), 255=ignore
    pseudo_gt = torch.full(
        (B, pH, pW), fill_value=255, dtype=torch.long, device=parse_unified25.device,
    )
    for label, part_idx in _LABEL_TO_PART.items():
        pseudo_gt[parse_unified25 == label] = part_idx

    # Cross-entropy with ignore_index=255 (background/unlabeled pixels ignored)
    loss = F.cross_entropy(part_masks_full, pseudo_gt, ignore_index=255)

    return loss
