"""
Losses Package - Dynamic Loss Weight Scheduling

Provides all loss functions and dynamic weight scheduling based on training epoch.

Loss Components (9 per spec Section 5.1):
1. L_denoise:  Diffusion loss (Min-SNR weighted, γ=5.0)
2. L_x0_perc:  VGG-19 perceptual on x0_pred_image (NOT I_final)
3. L_ssim:     1 - SSIM(x0_pred_image, person_image)
4. L_warp_s:   Laplacian 2nd-order warp smoothness
5. L_warp_m:   Warp mask BCE — returns 0.0 (MOD-11 absent)
6. L_warp_pt:  Pre-warp L1 — returns 0.0 (MOD-10 absent)
7. L_identity: TPS identity penalty (decays to 0 by epoch 20)
8. L_part_seg: Part-seg soft pseudo-supervision
9. L_comp:     Compositor boundary BCE

Dynamic Scheduling (Section 5.3, 4 phases):
- Phase 1 (epochs 0-1):  Warp warm-up
- Phase 2 (epochs 2-20): Stabilization (identity + warp_pt decay)
- Phase 3 (epochs 21-80): Balanced
- Phase 4 (epochs 81+):  Quality refinement

get_loss_weights(epoch) returns dict of lambda_ weights for each loss component.
"""

import torch
import torch.nn as nn
import torchvision.transforms.functional as TF_v
from typing import Dict

from .diffusion_loss import DiffusionLoss, compute_diffusion_loss
from .warp_losses import (
    WarpLossComputer,
    compute_warp_pretrain_loss,
    compute_warp_mask_loss,
    compute_identity_penalty,
    compute_tps_smoothness_loss,
)
from .perceptual import PerceptualLoss
from .ssim_loss import SSIMLoss
from .compositor_loss import CompositorLoss, compute_boundary_weighted_bce, compute_alpha_smoothness
from .part_seg_loss import compute_part_segmentation_loss


def get_loss_weights(epoch: int, cfg=None) -> Dict[str, float]:
    """
    Get dynamic loss weights for current epoch (spec Section 5.3).
    
    Args:
        epoch: current training epoch (0-indexed)
        cfg: optional config object (for custom schedules)
    
    Returns:
        dict with lambda_ loss weights (9 components)
    """
    
    if epoch < 2:
        # Phase 1: Warp warm-up (epochs 0-1)
        return {
            'lambda_denoise': 0.2,
            'lambda_x0_perc': 0.0,
            'lambda_ssim': 0.0,
            'lambda_warp_s': 80.0,
            'lambda_warp_m': 3.0,
            'lambda_warp_pt': 3.0,
            'lambda_identity': 5.0,
            'lambda_part_seg': 1.0,
            'lambda_comp': 0.1,
        }
    
    elif epoch <= 20:
        # Phase 2: Stabilization (epochs 2-20)
        t = (epoch - 2) / 18.0  # 0 to 1
        return {
            'lambda_denoise': 0.5 + 0.5 * t,            # 0.5 → 1.0
            'lambda_x0_perc': 0.02,
            'lambda_ssim': 0.02,
            'lambda_warp_s': 60.0,
            'lambda_warp_m': 2.0,
            'lambda_warp_pt': 0.0,
            'lambda_identity': 5.0 * max(0.0, 1.0 - t),  # 5.0 → 0.0
            'lambda_part_seg': 0.5,
            'lambda_comp': 0.3,
        }
    
    elif epoch <= 80:
        # Phase 3: Balanced (epochs 21-80)
        return {
            'lambda_denoise': 1.0,
            'lambda_x0_perc': 0.05,
            'lambda_ssim': 0.05,
            'lambda_warp_s': 40.0,
            'lambda_warp_m': 1.0,
            'lambda_warp_pt': 0.0,
            'lambda_identity': 0.0,
            'lambda_part_seg': 0.5,
            'lambda_comp': 0.5,
        }
    
    else:
        # Phase 4: Quality refinement (epochs 81+)
        return {
            'lambda_denoise': 1.2,
            'lambda_x0_perc': 0.08,
            'lambda_ssim': 0.08,
            'lambda_warp_s': 25.0,
            'lambda_warp_m': 0.5,
            'lambda_warp_pt': 0.0,
            'lambda_identity': 0.0,
            'lambda_part_seg': 0.3,
            'lambda_comp': 0.5,
        }


class TryOnLossComputer(nn.Module):
    """
    Complete loss computer for Virtual Try-On system.
    
    Combines all 9 loss components with dynamic weighting per spec Section 5.
    """
    
    def __init__(self, scheduler, cfg):
        super().__init__()
        
        self.cfg = cfg
        
        # Initialize all loss modules
        self.diffusion_loss = DiffusionLoss(scheduler)
        self.warp_loss = WarpLossComputer(
            perceptual_net_type='alex',
            l1_weight=1.0,
            perceptual_weight=0.1,
        )
        self.perceptual_loss = PerceptualLoss(net_type='alex')
        self.ssim_loss = SSIMLoss()
        self.compositor_loss = CompositorLoss(
            boundary_width=5,
            boundary_weight=5.0,
            smoothness_weight=0.01,
        )
    
    def forward(
        self,
        outputs: dict,
        batch: dict,
        epoch: int,
    ) -> dict:
        """
        Compute all 9 losses with dynamic weighting.
        
        Args:
            outputs: dict from VirtualTryOnSystem.forward_train()
            batch: original batch dict (for agnostic_mask, parse_unified25)
            epoch: current training epoch
        
        Returns:
            dict with individual losses, total loss, and weights
        """
        device = outputs['eps_pred'].device
        weights = get_loss_weights(epoch, self.cfg)
        
        # 1. L_denoise — Min-SNR weighted diffusion loss
        L_denoise = self.diffusion_loss(
            eps_pred=outputs['eps_pred'],
            eps_target=outputs['eps_target'],
            timesteps=outputs['timesteps'],
        )
        
        # 2. L_x0_perc — VGG perceptual on x0_pred_image (NOT I_final)
        if weights['lambda_x0_perc'] > 0:
            L_x0_perc = self.perceptual_loss(
                pred=outputs['x0_pred_image'],
                target=outputs['person_image'],
            )
        else:
            L_x0_perc = torch.tensor(0.0, device=device)
        
        # 3. L_ssim — 1 - SSIM on x0_pred_image
        if weights['lambda_ssim'] > 0:
            L_ssim = self.ssim_loss(
                pred=outputs['x0_pred_image'],
                target=outputs['person_image'],
            )
        else:
            L_ssim = torch.tensor(0.0, device=device)
        
        # 4. L_warp_s — Laplacian 2nd-order warp smoothness
        L_warp_s = compute_tps_smoothness_loss(outputs['deformation_field'])
        
        # 5. L_warp_m — Warp mask BCE (returns 0.0 if MOD-11 absent)
        L_warp_m = compute_warp_mask_loss(
            cloth_mask_warped=outputs['cloth_mask_warped'],
            warp_mask_gt=outputs.get('warp_mask_gt', None),
        )
        
        # 6. L_warp_pt — Pre-warp L1 (returns 0.0 if MOD-10 absent)
        L_warp_pt = compute_warp_pretrain_loss(
            cloth_warped=outputs['cloth_warped'],
            warp_cloth_gt=outputs.get('warp_cloth_gt', None),
            warp_mask_gt=outputs.get('warp_mask_gt', None),
            perceptual_net=self.warp_loss.perceptual_net,
        )
        
        # 7. L_identity — TPS identity penalty
        L_identity = compute_identity_penalty(
            ctrl_pts_src=outputs['ctrl_pts_src'],
            ctrl_pts_tgt=outputs['ctrl_pts_tgt'],
        )
        
        # 8. L_part_seg — Part segmentation pseudo-supervision
        if weights['lambda_part_seg'] > 0:
            L_part_seg = compute_part_segmentation_loss(
                part_masks_full=outputs['part_masks_full'],
                parse_unified25=batch['parse_unified25'],
            )
        else:
            L_part_seg = torch.tensor(0.0, device=device)
        
        # 9. L_comp — Compositor boundary BCE per spec Section 4.2 MODULE I
        # Target: soft_mask = gaussian_blur(agnostic_mask, sigma=3.0).clamp(0,1)
        # Weight: boundary_weight = 1.0 + 2.0 * sobel_edge(agnostic_mask)
        agnostic_mask = batch['agnostic_mask']
        # Gaussian blur for soft target per spec
        soft_mask = TF_v.gaussian_blur(agnostic_mask, kernel_size=19, sigma=3.0).clamp(0, 1)
        L_comp = compute_boundary_weighted_bce(
            alpha_logit=outputs['alpha_logit'],
            target_alpha=soft_mask,
            agnostic_mask=agnostic_mask,
            boundary_width=self.compositor_loss.boundary_width,
            boundary_weight=self.compositor_loss.boundary_weight,
        )
        
        # Weighted total loss
        loss_total = (
            weights['lambda_denoise'] * L_denoise +
            weights['lambda_x0_perc'] * L_x0_perc +
            weights['lambda_ssim'] * L_ssim +
            weights['lambda_warp_s'] * L_warp_s +
            weights['lambda_warp_m'] * L_warp_m +
            weights['lambda_warp_pt'] * L_warp_pt +
            weights['lambda_identity'] * L_identity +
            weights['lambda_part_seg'] * L_part_seg +
            weights['lambda_comp'] * L_comp
        )
        
        return {
            # Individual losses (9 components)
            'L_denoise': L_denoise,
            'L_x0_perc': L_x0_perc,
            'L_ssim': L_ssim,
            'L_warp_s': L_warp_s,
            'L_warp_m': L_warp_m,
            'L_warp_pt': L_warp_pt,
            'L_identity': L_identity,
            'L_part_seg': L_part_seg,
            'L_comp': L_comp,
            
            # Total loss
            'loss': loss_total,
            
            # Weights (for logging)
            'weights': weights,
        }


# Export all functions and classes
__all__ = [
    # Functions
    'get_loss_weights',
    'compute_diffusion_loss',
    'compute_warp_pretrain_loss',
    'compute_warp_mask_loss',
    'compute_identity_penalty',
    'compute_tps_smoothness_loss',
    'compute_part_segmentation_loss',
    'compute_boundary_weighted_bce',
    'compute_alpha_smoothness',
    
    # Classes
    'DiffusionLoss',
    'WarpLossComputer',
    'PerceptualLoss',
    'SSIMLoss',
    'CompositorLoss',
    'TryOnLossComputer',
]


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_loss_weights():
    """Test dynamic loss weight scheduling."""
    print("Testing dynamic loss weight scheduling...")
    
    print("\nLoss weights by epoch:")
    print("=" * 80)
    
    test_epochs = [0, 1, 2, 5, 10, 20, 40, 80, 100]
    
    for epoch in test_epochs:
        weights = get_loss_weights(epoch)
        print(f"\nEpoch {epoch:3d}:")
        for key, val in weights.items():
            print(f"  {key:20s}: {val:.3f}")
    
    print("\n" + "=" * 80)
    
    # Verify key properties
    print("\nVerifying schedule properties...")
    
    # Warm-up phase (epochs 0-1)
    w0 = get_loss_weights(0)
    assert w0['lambda_denoise'] == 0.2, "Denoise weight should be 0.2 during warm-up"
    assert w0['lambda_warp_s'] == 80.0, "Warp smoothness should be 80.0 during warm-up"
    assert w0['lambda_identity'] == 5.0, "Identity weight should be 5.0 during warm-up"
    print("✓ Warm-up phase correct (9 components)")
    
    # Stabilization (epoch 20)
    w20 = get_loss_weights(20)
    assert w20['lambda_identity'] == 0.0, "Identity weight should decay to 0 by epoch 20"
    print("✓ Stabilization phase correct")
    
    # Balanced (epoch 50)
    w50 = get_loss_weights(50)
    assert w50['lambda_denoise'] == 1.0, "Denoise weight should be 1.0"
    assert w50['lambda_warp_s'] == 40.0, "Warp smoothness should be 40.0"
    print("✓ Balanced phase correct")
    
    # Refinement (epoch 90)
    w90 = get_loss_weights(90)
    assert w90['lambda_denoise'] == 1.2, "Denoise weight should be 1.2 in refinement"
    assert w90['lambda_identity'] == 0.0, "Identity should stay 0"
    print("✓ Refinement phase correct")
    
    print("\n✅ Loss weight scheduling test passed!")


if __name__ == '__main__':
    test_loss_weights()
