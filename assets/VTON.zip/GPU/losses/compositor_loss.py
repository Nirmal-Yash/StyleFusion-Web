"""
Compositor Loss - Boundary-Weighted BCE

Computes boundary-aware loss for alpha mask prediction in compositor.
Higher weights near mask boundaries encourage smooth transitions.

Losses:
1. BCE on alpha_logit (before sigmoid)
2. Boundary-weighted BCE (higher weight near edges)
3. Alpha smoothness regularization

This ensures seamless compositing between diffusion output and original person image.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def compute_boundary_mask(
    mask: torch.Tensor,
    boundary_width: int = 5,
) -> torch.Tensor:
    """
    Compute binary boundary mask via dilation - erosion.
    
    Args:
        mask: [B, 1, H, W] binary mask {0, 1}
        boundary_width: width of boundary region in pixels
    
    Returns:
        boundary: [B, 1, H, W] binary boundary mask {0, 1}
    """
    kernel_size = boundary_width * 2 + 1
    kernel = torch.ones(1, 1, kernel_size, kernel_size).to(mask.device)
    
    # Dilate
    mask_dilated = F.conv2d(mask, kernel, padding=boundary_width)
    mask_dilated = (mask_dilated > 0.5).float()
    
    # Erode
    mask_eroded = F.conv2d(mask, kernel, padding=boundary_width)
    mask_eroded = (mask_eroded >= (kernel_size * kernel_size - 0.5)).float()
    
    # Boundary = dilated - eroded
    boundary = mask_dilated - mask_eroded
    
    return boundary


def compute_boundary_weighted_bce(
    alpha_logit: torch.Tensor,
    target_alpha: torch.Tensor,
    agnostic_mask: torch.Tensor,
    boundary_width: int = 5,
    boundary_weight: float = 5.0,
) -> torch.Tensor:
    """
    Compute boundary-weighted BCE loss for alpha prediction.
    
    Args:
        alpha_logit: [B, 1, H, W] predicted alpha (before sigmoid)
        target_alpha: [B, 1, H, W] target alpha in [0, 1]
        agnostic_mask: [B, 1, H, W] binary mask for boundary detection
        boundary_width: width of boundary region
        boundary_weight: weight multiplier for boundary pixels
    
    Returns:
        loss: scalar tensor
    """
    # Compute binary boundary mask
    boundary = compute_boundary_mask(agnostic_mask, boundary_width)  # [B, 1, H, W]
    
    # Create weight map (1.0 everywhere, boundary_weight at boundaries)
    weight_map = torch.ones_like(boundary)
    weight_map = weight_map + boundary * (boundary_weight - 1.0)
    
    # Compute BCE with logits (numerically stable)
    bce = F.binary_cross_entropy_with_logits(
        alpha_logit,
        target_alpha,
        reduction='none',
    )  # [B, 1, H, W]
    
    # Apply weights
    weighted_bce = (bce * weight_map).mean()
    
    return weighted_bce


def compute_alpha_smoothness(alpha: torch.Tensor) -> torch.Tensor:
    """
    Compute smoothness regularization for alpha mask.
    
    Encourages spatially smooth alpha transitions.
    
    Args:
        alpha: [B, 1, H, W] alpha mask in [0, 1]
    
    Returns:
        loss: scalar tensor, L1 norm of gradients
    """
    # Compute gradients
    grad_x = torch.abs(alpha[:, :, :, 1:] - alpha[:, :, :, :-1])
    grad_y = torch.abs(alpha[:, :, 1:, :] - alpha[:, :, :-1, :])
    
    # L1 smoothness
    smoothness = grad_x.mean() + grad_y.mean()
    
    return smoothness


class CompositorLoss(nn.Module):
    """
    Complete compositor loss combining BCE and smoothness.
    
    Losses:
        - Boundary-weighted BCE (main loss)
        - Alpha smoothness regularization
    """
    
    def __init__(
        self,
        boundary_width: int = 5,
        boundary_weight: float = 5.0,
        smoothness_weight: float = 0.01,
    ):
        super().__init__()
        
        self.boundary_width = boundary_width
        self.boundary_weight = boundary_weight
        self.smoothness_weight = smoothness_weight
    
    def forward(
        self,
        alpha_logit: torch.Tensor,
        target_alpha: torch.Tensor,
        agnostic_mask: torch.Tensor,
    ) -> dict:
        """
        Compute compositor losses.
        
        Args:
            alpha_logit: [B, 1, H, W] predicted alpha logits
            target_alpha: [B, 1, H, W] target alpha in [0, 1]
            agnostic_mask: [B, 1, H, W] binary mask
        
        Returns:
            dict with keys:
                - 'L_comp_bce': boundary-weighted BCE
                - 'L_comp_smooth': alpha smoothness
                - 'L_comp_total': total compositor loss
        """
        # Boundary-weighted BCE
        L_comp_bce = compute_boundary_weighted_bce(
            alpha_logit=alpha_logit,
            target_alpha=target_alpha,
            agnostic_mask=agnostic_mask,
            boundary_width=self.boundary_width,
            boundary_weight=self.boundary_weight,
        )
        
        # Alpha smoothness
        alpha = torch.sigmoid(alpha_logit)
        L_comp_smooth = compute_alpha_smoothness(alpha)
        
        # Total compositor loss
        L_comp_total = L_comp_bce + self.smoothness_weight * L_comp_smooth
        
        return {
            'L_comp_bce': L_comp_bce,
            'L_comp_smooth': L_comp_smooth,
            'L_comp_total': L_comp_total,
        }


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_compositor_loss():
    """Test compositor loss with synthetic inputs."""
    print("Testing compositor loss...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create loss module
    loss_fn = CompositorLoss(
        boundary_width=5,
        boundary_weight=5.0,
        smoothness_weight=0.01,
    ).to(device)
    
    # Create synthetic inputs
    alpha_logit = torch.randn(B, 1, 1024, 768).to(device)
    target_alpha = torch.rand(B, 1, 1024, 768).to(device)
    agnostic_mask = torch.rand(B, 1, 1024, 768).to(device)
    agnostic_mask = (agnostic_mask > 0.5).float()
    
    # Compute losses
    with torch.no_grad():
        losses = loss_fn(alpha_logit, target_alpha, agnostic_mask)
    
    print("\nLosses:")
    for key, val in losses.items():
        print(f"  {key}: {val.item():.6f}")
    
    assert losses['L_comp_bce'].item() > 0.0
    assert losses['L_comp_smooth'].item() > 0.0
    assert losses['L_comp_total'].item() > 0.0
    
    # Test boundary detection
    print("\nTesting boundary detection...")
    boundary = compute_boundary_mask(agnostic_mask, boundary_width=5)
    
    print(f"  Boundary pixels: {boundary.sum().item() / boundary.numel() * 100:.2f}%")
    assert boundary.sum() > 0, "Should detect some boundary pixels"
    
    # Test alpha smoothness
    print("\nTesting alpha smoothness...")
    
    # Smooth alpha (should have low smoothness loss)
    alpha_smooth = torch.ones(B, 1, 100, 100).to(device) * 0.5
    smoothness_smooth = compute_alpha_smoothness(alpha_smooth)
    print(f"  Smoothness (constant): {smoothness_smooth.item():.6f}")
    assert smoothness_smooth.item() < 0.01, "Constant alpha should be very smooth"
    
    # Noisy alpha (should have high smoothness loss)
    alpha_noisy = torch.rand(B, 1, 100, 100).to(device)
    smoothness_noisy = compute_alpha_smoothness(alpha_noisy)
    print(f"  Smoothness (noisy): {smoothness_noisy.item():.6f}")
    assert smoothness_noisy.item() > smoothness_smooth.item(), "Noisy alpha should be less smooth"
    
    print("\n✅ Compositor loss test passed!")


if __name__ == '__main__':
    test_compositor_loss()
