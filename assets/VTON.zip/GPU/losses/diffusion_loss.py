"""
Diffusion Loss - SNR-Weighted Denoising Loss

Computes MSE loss between predicted and target noise with SNR weighting.

SNR (Signal-to-Noise Ratio) weighting:
- High timesteps (more noise): lower SNR → lower weight
- Low timesteps (less noise): higher SNR → higher weight

This prioritizes learning clean image reconstruction over pure noise prediction.

Reference: "Elucidating the Design Space of Diffusion-Based Generative Models" (Karras et al., 2022)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def compute_snr(timesteps: torch.Tensor, alphas_cumprod: torch.Tensor) -> torch.Tensor:
    """
    Compute Signal-to-Noise Ratio for given timesteps.
    
    SNR(t) = alpha_t / (1 - alpha_t)
    
    Args:
        timesteps: [B] timestep indices
        alphas_cumprod: [T] cumulative product of alphas
    
    Returns:
        snr: [B] signal-to-noise ratios
    """
    alpha_t = alphas_cumprod[timesteps]
    snr = alpha_t / (1.0 - alpha_t + 1e-8)
    
    return snr


def compute_diffusion_loss(
    eps_pred: torch.Tensor,
    eps_target: torch.Tensor,
    timesteps: torch.Tensor,
    alphas_cumprod: torch.Tensor,
    snr_clip_min: float = 0.01,
    snr_clip_max: float = 100.0,
) -> torch.Tensor:
    """
    Compute SNR-weighted diffusion loss.
    
    Args:
        eps_pred: [B, 4, H, W] predicted noise
        eps_target: [B, 4, H, W] target noise
        timesteps: [B] timestep indices
        alphas_cumprod: [T] cumulative product of alphas from scheduler
        snr_clip_min: minimum SNR value (prevents inf weights)
        snr_clip_max: maximum SNR value (prevents zero weights)
    
    Returns:
        loss: scalar tensor, SNR-weighted MSE
    """
    B = eps_pred.shape[0]
    
    # Compute MSE per sample
    mse = F.mse_loss(eps_pred, eps_target, reduction='none')  # [B, 4, H, W]
    mse = mse.mean(dim=[1, 2, 3])  # [B]
    
    # Compute SNR weights
    snr = compute_snr(timesteps, alphas_cumprod)  # [B]
    snr = torch.clamp(snr, min=snr_clip_min, max=snr_clip_max)
    
    # SNR weighting: weight = snr / (snr + 1)
    # This gives more weight to low-noise timesteps
    weights = snr / (snr + 1.0)  # [B]
    
    # Weighted MSE
    weighted_mse = (mse * weights).mean()
    
    return weighted_mse


class DiffusionLoss(nn.Module):
    """
    Diffusion loss module with SNR weighting.
    
    Stores alphas_cumprod from scheduler for SNR computation.
    """
    
    def __init__(
        self,
        scheduler,
        snr_clip_min: float = 0.01,
        snr_clip_max: float = 100.0,
    ):
        super().__init__()
        
        # Register alphas_cumprod as buffer (moved to device with model)
        self.register_buffer('alphas_cumprod', scheduler.alphas_cumprod)
        
        self.snr_clip_min = snr_clip_min
        self.snr_clip_max = snr_clip_max
    
    def forward(
        self,
        eps_pred: torch.Tensor,
        eps_target: torch.Tensor,
        timesteps: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute SNR-weighted diffusion loss.
        
        Args:
            eps_pred: [B, 4, H, W] predicted noise
            eps_target: [B, 4, H, W] target noise
            timesteps: [B] timestep indices
        
        Returns:
            loss: scalar tensor
        """
        return compute_diffusion_loss(
            eps_pred=eps_pred,
            eps_target=eps_target,
            timesteps=timesteps,
            alphas_cumprod=self.alphas_cumprod,
            snr_clip_min=self.snr_clip_min,
            snr_clip_max=self.snr_clip_max,
        )


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_diffusion_loss():
    """Test diffusion loss with synthetic inputs."""
    print("Testing diffusion loss...")
    
    from diffusers import DDIMScheduler
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 4
    
    # Create scheduler
    scheduler = DDIMScheduler(
        num_train_timesteps=1000,
        beta_start=0.00085,
        beta_end=0.012,
        beta_schedule="scaled_linear",
    )
    
    # Create loss module
    loss_fn = DiffusionLoss(scheduler).to(device)
    
    # Create synthetic inputs
    eps_pred = torch.randn(B, 4, 128, 96).to(device)
    eps_target = torch.randn(B, 4, 128, 96).to(device)
    timesteps = torch.randint(0, 1000, (B,)).to(device)
    
    # Compute loss
    loss = loss_fn(eps_pred, eps_target, timesteps)
    
    print(f"Loss: {loss.item():.6f}")
    assert loss.item() > 0.0, "Loss should be positive"
    
    # Test SNR computation
    snr = compute_snr(timesteps, scheduler.alphas_cumprod.to(device))
    print(f"SNR range: [{snr.min():.4f}, {snr.max():.4f}]")
    
    # Test different timesteps
    print("\nTesting SNR at different timesteps:")
    for t in [0, 250, 500, 750, 999]:
        t_tensor = torch.tensor([t]).to(device)
        snr_t = compute_snr(t_tensor, scheduler.alphas_cumprod.to(device))
        weight_t = snr_t / (snr_t + 1.0)
        print(f"  t={t:4d}: SNR={snr_t.item():8.4f}, weight={weight_t.item():.4f}")
    
    print("\n✅ Diffusion loss test passed!")


if __name__ == '__main__':
    test_diffusion_loss()
