"""
SSIM Loss - Structural Similarity Index

Computes SSIM (Structural Similarity Index Measure) loss between images.
SSIM measures perceptual similarity based on luminance, contrast, and structure.

Returns 1 - SSIM to convert similarity metric to loss (lower is better).

Reference: "Image Quality Assessment: From Error Visibility to Structural Similarity" (Wang et al., 2004)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


def gaussian_kernel(kernel_size: int = 11, sigma: float = 1.5, channels: int = 3) -> torch.Tensor:
    """
    Create 2D Gaussian kernel for SSIM computation.
    
    Args:
        kernel_size: size of Gaussian kernel (should be odd)
        sigma: standard deviation of Gaussian
        channels: number of channels
    
    Returns:
        kernel: [channels, 1, kernel_size, kernel_size]
    """
    # Create 1D Gaussian
    x = torch.arange(kernel_size) - kernel_size // 2
    gauss = torch.exp(-x ** 2 / (2 * sigma ** 2))
    gauss = gauss / gauss.sum()
    
    # Create 2D Gaussian
    gauss_2d = gauss.unsqueeze(1) * gauss.unsqueeze(0)
    
    # Expand to multiple channels
    kernel = gauss_2d.unsqueeze(0).unsqueeze(0)
    kernel = kernel.repeat(channels, 1, 1, 1)
    
    return kernel


def compute_ssim(
    img1: torch.Tensor,
    img2: torch.Tensor,
    kernel_size: int = 11,
    sigma: float = 1.5,
    k1: float = 0.01,
    k2: float = 0.03,
    data_range: float = 1.0,
) -> torch.Tensor:
    """
    Compute SSIM between two images.
    
    Args:
        img1: [B, C, H, W] first image
        img2: [B, C, H, W] second image
        kernel_size: size of Gaussian kernel
        sigma: standard deviation of Gaussian
        k1, k2: stability constants
        data_range: dynamic range of pixel values (1.0 for [0,1], 255 for [0,255])
    
    Returns:
        ssim: scalar tensor, SSIM value in [0, 1]
    """
    B, C, H, W = img1.shape
    
    # Create Gaussian kernel
    kernel = gaussian_kernel(kernel_size, sigma, C).to(img1.device)
    
    # Constants for stability
    C1 = (k1 * data_range) ** 2
    C2 = (k2 * data_range) ** 2
    
    # Compute means
    mu1 = F.conv2d(img1, kernel, padding=kernel_size // 2, groups=C)
    mu2 = F.conv2d(img2, kernel, padding=kernel_size // 2, groups=C)
    
    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2
    
    # Compute variances and covariance
    sigma1_sq = F.conv2d(img1 * img1, kernel, padding=kernel_size // 2, groups=C) - mu1_sq
    sigma2_sq = F.conv2d(img2 * img2, kernel, padding=kernel_size // 2, groups=C) - mu2_sq
    sigma12 = F.conv2d(img1 * img2, kernel, padding=kernel_size // 2, groups=C) - mu1_mu2
    
    # SSIM formula
    numerator = (2 * mu1_mu2 + C1) * (2 * sigma12 + C2)
    denominator = (mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2)
    
    ssim_map = numerator / (denominator + 1e-8)
    
    # Mean over spatial dimensions and channels
    ssim = ssim_map.mean()
    
    return ssim


class SSIMLoss(nn.Module):
    """
    SSIM loss module (1 - SSIM).
    
    Higher SSIM = more similar = lower loss.
    """
    
    def __init__(
        self,
        kernel_size: int = 11,
        sigma: float = 1.5,
        k1: float = 0.01,
        k2: float = 0.03,
        data_range: float = 1.0,
    ):
        super().__init__()
        
        self.kernel_size = kernel_size
        self.sigma = sigma
        self.k1 = k1
        self.k2 = k2
        self.data_range = data_range
    
    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """
        Compute SSIM loss.
        
        Args:
            pred: [B, 3, H, W] predicted image in [0, 1]
            target: [B, 3, H, W] target image in [0, 1]
        
        Returns:
            loss: scalar tensor (1 - SSIM)
        """
        ssim = compute_ssim(
            img1=pred,
            img2=target,
            kernel_size=self.kernel_size,
            sigma=self.sigma,
            k1=self.k1,
            k2=self.k2,
            data_range=self.data_range,
        )
        
        # Convert to loss (lower SSIM = higher loss)
        loss = 1.0 - ssim
        
        return loss


# =============================================================================
# TEST FUNCTION
# =============================================================================

def test_ssim_loss():
    """Test SSIM loss with synthetic inputs."""
    print("Testing SSIM loss...")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    B = 2
    
    # Create loss module
    loss_fn = SSIMLoss(kernel_size=11, sigma=1.5).to(device)
    
    # Test Case 1: Identical images (loss should be ~0)
    print("\nTest Case 1: Identical images")
    img = torch.rand(B, 3, 256, 256).to(device)
    
    with torch.no_grad():
        loss_identical = loss_fn(img, img)
    
    print(f"  Loss (identical): {loss_identical.item():.6f}")
    assert loss_identical.item() < 0.01, "Loss should be near 0 for identical images"
    
    # Test Case 2: Different images (loss should be > 0)
    print("\nTest Case 2: Different images")
    img1 = torch.rand(B, 3, 256, 256).to(device)
    img2 = torch.rand(B, 3, 256, 256).to(device)
    
    with torch.no_grad():
        loss_different = loss_fn(img1, img2)
    
    print(f"  Loss (different): {loss_different.item():.6f}")
    assert loss_different.item() > 0.0, "Loss should be positive for different images"
    assert loss_different.item() < 1.0, "Loss should be < 1.0 (SSIM range)"
    
    # Test Case 3: Slightly perturbed (loss should be small but > 0)
    print("\nTest Case 3: Slightly perturbed")
    img_base = torch.rand(B, 3, 256, 256).to(device)
    img_perturbed = img_base + torch.randn_like(img_base) * 0.05
    img_perturbed = torch.clamp(img_perturbed, 0.0, 1.0)
    
    with torch.no_grad():
        loss_perturbed = loss_fn(img_base, img_perturbed)
    
    print(f"  Loss (perturbed): {loss_perturbed.item():.6f}")
    assert 0.0 < loss_perturbed.item() < 0.5, "Small perturbation should give small loss"
    
    # Test Case 4: Full resolution
    print("\nTest Case 4: Full resolution (1024x768)")
    img_full1 = torch.rand(B, 3, 1024, 768).to(device)
    img_full2 = torch.rand(B, 3, 1024, 768).to(device)
    
    with torch.no_grad():
        loss_full = loss_fn(img_full1, img_full2)
    
    print(f"  Loss (full res): {loss_full.item():.6f}")
    
    print("\n✅ SSIM loss test passed!")


if __name__ == '__main__':
    test_ssim_loss()
